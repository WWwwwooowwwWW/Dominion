import assert from 'node:assert/strict';
import WebSocket from 'ws';
import { generateWorld } from '../src/engine/worldGen';
import { GameState } from '../src/types/game';

const BASE = 'http://127.0.0.1:3000';

async function waitForMsg(
  queue: Array<Record<string, unknown>>,
  predicate: (m: Record<string, unknown>) => boolean,
  timeoutMs = 5000
): Promise<Record<string, unknown>> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const idx = queue.findIndex(predicate);
    if (idx !== -1) {
      return queue.splice(idx, 1)[0];
    }
    await new Promise((r) => setTimeout(r, 40));
  }
  throw new Error('Timed out waiting for WebSocket message');
}

async function runLiveTests() {
  console.log('--- Testing Live HTTP Endpoints & HTML Delivery ---');
  const htmlRes = await fetch(`${BASE}/`);
  assert.equal(htmlRes.status, 200);
  const htmlText = await htmlRes.text();
  assert(htmlText.includes('DOMINION'), 'HTML must include DOMINION title');

  const health = await (await fetch(`${BASE}/api/health`)).json();
  assert.equal(health.ok, true);

  console.log('--- Testing Account Registration, Login & SQLite Save/Load ---');
  const aliceAuth = await (
    await fetch(`${BASE}/api/auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'Commander_Alice', password: 'secret' }),
    })
  ).json();
  assert.equal(aliceAuth.ok, true);
  assert.equal(aliceAuth.account.username, 'Commander_Alice');

  const bobAuth = await (
    await fetch(`${BASE}/api/auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'Admiral_Bob', password: 'secret' }),
    })
  ).json();
  assert.equal(bobAuth.ok, true);

  const sampleWorld = generateWorld({
    mode: 'singleplayer',
    seed: 9911,
    mapSize: 'small',
    aiCount: 3,
    aiDifficulty: 'easy',
    startingEra: 'ancient',
    resourceAbundance: 'standard',
    terrainStyle: 'continents',
    startingResourcesMultiplier: 1,
    playerNationName: 'SaveTest Empire',
    playerLeaderName: 'Tester',
    playerColor: '#2dd4bf',
    playerEmblem: 'eagle',
    speedMultiplier: 1,
  });

  const saveRes = await (
    await fetch(`${BASE}/api/saves`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: 'test_slot_1',
        name: 'Integration Save Slot',
        nationName: 'SaveTest Empire',
        era: 'ancient',
        year: -4000,
        territoriesOwned: 1,
        totalLandTerritories: 75,
        difficulty: 'easy',
        isAutosave: false,
        state: sampleWorld,
      }),
    })
  ).json();
  assert.equal(saveRes.ok, true);

  const loadedRes = await (await fetch(`${BASE}/api/saves/test_slot_1`)).json();
  assert.equal(loadedRes.ok, true);
  assert.equal(loadedRes.state.config.playerNationName, 'SaveTest Empire');

  await fetch(`${BASE}/api/saves/test_slot_1`, { method: 'DELETE' });
  console.log('✓ HTTP API, Auth & SQLite Save/Load persistence verified');

  console.log('--- Testing Real 2-Player WebSocket Multiplayer ---');
  const wsAlice = new WebSocket('ws://127.0.0.1:3000/ws');
  const wsBob = new WebSocket('ws://127.0.0.1:3000/ws');
  const qAlice: Array<Record<string, unknown>> = [];
  const qBob: Array<Record<string, unknown>> = [];

  wsAlice.on('message', (d) => qAlice.push(JSON.parse(d.toString())));
  wsBob.on('message', (d) => qBob.push(JSON.parse(d.toString())));

  await Promise.all([
    new Promise((res) => wsAlice.once('open', res)),
    new Promise((res) => wsBob.once('open', res)),
  ]);

  wsAlice.send(JSON.stringify({ type: 'identify', username: 'Commander_Alice' }));
  wsBob.send(JSON.stringify({ type: 'identify', username: 'Admiral_Bob' }));
  await waitForMsg(qAlice, (m) => m.type === 'identified');
  await waitForMsg(qBob, (m) => m.type === 'identified');

  wsAlice.send(
    JSON.stringify({
      type: 'create_lobby',
      name: 'Atlantic Supremacy',
      isPublic: false,
      mapSize: 'small',
      aiCount: 2,
      startingEra: 'ancient',
      nationName: 'Alice Republic',
    })
  );
  const created = await waitForMsg(qAlice, (m) => m.type === 'lobby_joined');
  const inviteCode = (created.lobby as { inviteCode: string }).inviteCode;
  assert(inviteCode.startsWith('DOM-'), 'Invite code generated');

  wsBob.send(
    JSON.stringify({
      type: 'join_lobby',
      inviteCode,
      nationName: 'Bob Armada',
    })
  );
  await waitForMsg(qBob, (m) => m.type === 'lobby_joined');
  const updatedForAlice = await waitForMsg(qAlice, (m) => m.type === 'lobby_updated');
  assert.equal((updatedForAlice.lobby as { players: unknown[] }).players.length, 2, 'Both human players in room');

  // Chat test
  wsBob.send(JSON.stringify({ type: 'chat', message: 'Ready for conquest!' }));
  const chatSeen = await waitForMsg(qAlice, (m) => m.type === 'lobby_chat');
  assert.equal((chatSeen.chat as { message: string }).message, 'Ready for conquest!');

  // Start authoritative match
  wsAlice.send(JSON.stringify({ type: 'start_match' }));
  const aliceStart = await waitForMsg(qAlice, (m) => m.type === 'match_started');
  const bobStart = await waitForMsg(qBob, (m) => m.type === 'match_started');

  const aliceState = aliceStart.state as GameState;
  const bobState = bobStart.state as GameState;
  assert.notEqual(aliceState.playerNationId, bobState.playerNationId, 'Each human controls a distinct nation');
  assert.equal(aliceState.nations[aliceState.playerNationId].name, 'Alice Republic');
  assert.equal(bobState.nations[bobState.playerNationId].name, 'Bob Armada');

  // Alice issues a real game command (research Agriculture) over WebSocket
  wsAlice.send(
    JSON.stringify({
      type: 'game_command',
      action: 'select_tech',
      payload: { techId: 'agriculture' },
    })
  );
  const aliceSync = await waitForMsg(qAlice, (m) => m.type === 'match_state');
  const bobSync = await waitForMsg(qBob, (m) => m.type === 'match_state');
  assert.equal(
    (aliceSync.state as GameState).nations[aliceState.playerNationId].currentTechId,
    'agriculture',
    'Server accepted and synced Alice tech command'
  );
  assert.equal(
    (bobSync.state as GameState).nations[aliceState.playerNationId].currentTechId,
    'agriculture',
    'Bob sees updated authoritative world state'
  );

  wsAlice.close();
  wsBob.close();
  console.log('✓ Real 2-player WebSocket Multiplayer lobby, invite code, chat & authoritative state sync verified!');
}

runLiveTests()
  .then(() => {
    console.log('ALL LIVE SERVER & MULTIPLAYER TESTS PASSED!');
    process.exit(0);
  })
  .catch((err) => {
    console.error('TEST FAILED:', err);
    process.exit(1);
  });
