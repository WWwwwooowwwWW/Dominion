import assert from 'node:assert/strict';
import { TECH_BY_ID, TECHNOLOGIES } from '../src/data/technologies';
import {
  computeTerritoryDefenseMultiplier,
  estimateCombatOdds,
  transferTerritoryOwnership,
} from '../src/engine/combat';
import { getTerritoryScalingFactor } from '../src/engine/economy';
import { findLandPath, findNavalPath } from '../src/engine/pathfinding';
import {
  cmdAttackOrMoveArmy,
  cmdBuildStructure,
  cmdChangeGovernment,
  cmdDiplomacyAction,
  cmdEmbarkArmy,
  cmdEstablishCity,
  cmdLaunchAmphibiousInvasion,
  cmdMarketTrade,
  cmdMoveFleet,
  cmdRecruitUnits,
  cmdSelectTech,
  cmdTogglePolicy,
  cmdUpdateBudget,
  getEffectiveTechCost,
  getTechRequirementsStatus,
  stepSimulation,
} from '../src/engine/simulation';
import { generateWorld } from '../src/engine/worldGen';
import { GameConfig } from '../src/types/game';

function testStages1to4() {
  console.log('--- Testing Stage 1: World Generation & Expansion ---');
  const config: GameConfig = {
    mode: 'singleplayer',
    seed: 424242,
    mapSize: 'medium',
    aiCount: 5,
    aiDifficulty: 'easy',
    startingEra: 'ancient',
    resourceAbundance: 'standard',
    terrainStyle: 'continents',
    startingResourcesMultiplier: 1.5,
    playerNationName: 'Test Imperium',
    playerLeaderName: 'Consul Test',
    playerColor: '#2dd4bf',
    playerEmblem: 'eagle',
    speedMultiplier: 1.0,
  };
  const state = generateWorld(config);
  const lands = state.territoryIds.filter((id) => !state.territories[id].isWater);
  const waters = state.territoryIds.filter((id) => state.territories[id].isWater);
  assert(lands.length >= 80, `Expected >= 80 land territories, got ${lands.length}`);
  assert(waters.length >= 50, `Expected >= 50 ocean sea zones, got ${waters.length}`);
  assert(state.rivers.length >= 3, 'Expected generated rivers');

  // Verify irregular organic polygons (> 4 vertices after edge subdivision)
  const polyLens = lands.slice(0, 10).map((id) => state.territories[id].polygon.length);
  assert(polyLens.some((len) => len > 8), 'Expected irregular subdivided polygons, not plain grids');

  // Verify gradual resource scaling curve
  assert.equal(getTerritoryScalingFactor(1), 1.0);
  assert.equal(getTerritoryScalingFactor(10), 1.0);
  assert.equal(getTerritoryScalingFactor(11), 0.75);
  assert.equal(getTerritoryScalingFactor(26), 0.55);
  assert.equal(getTerritoryScalingFactor(55), 0.38);

  // Player starts with 1 territory, 1 capital city, 1 army
  const player = state.nations[state.playerNationId];
  assert(player.capitalTerritoryId, 'Player must have capital territory');
  const capTerr = state.territories[player.capitalTerritoryId!];
  assert.equal(capTerr.ownerId, player.id);

  // Manual conquest of adjacent wilderness
  const adjWildId = capTerr.landNeighbors.find((id) => !state.territories[id].ownerId);
  assert(adjWildId, 'Capital should border unclaimed wilderness');
  const playerArmy = Object.values(state.armies).find((a) => a.nationId === player.id)!;
  assert(playerArmy, 'Player starts with an army');

  const atkRes = cmdAttackOrMoveArmy(state, player.id, playerArmy.id, adjWildId!);
  assert(atkRes.ok, `Attack wilderness failed: ${atkRes.error}`);
  assert(Object.keys(state.battles).length >= 1, 'Battle should start manually');

  // Step simulation until battle resolves
  for (let i = 0; i < 40; i++) {
    stepSimulation(state, 0.5);
    if (state.territories[adjWildId!].ownerId === player.id) break;
  }
  assert.equal(state.territories[adjWildId!].ownerId, player.id, 'Player should conquer adjacent wilderness');
  console.log('✓ Stage 1 verified (worldgen, irregular polygons, rivers, scaling, wilderness conquest)');

  console.log('--- Testing Stage 2: Terrain Combat, Nation Elimination & Naval/Amphibious Warfare ---');
  // Terrain defense check: mountains vs plains
  const mtn = lands.map((id) => state.territories[id]).find((t) => t.terrain === 'mountains');
  const pln = lands.map((id) => state.territories[id]).find((t) => t.terrain === 'plains');
  if (mtn && pln) {
    const mDef = computeTerritoryDefenseMultiplier(mtn, playerArmy.units, null, state);
    const pDef = computeTerritoryDefenseMultiplier(pln, playerArmy.units, null, state);
    assert(mDef.totalDefenseMult > pDef.totalDefenseMult * 1.4, 'Mountains must provide significantly stronger defense than plains');
  }

  // Nation elimination check
  const aiNation = Object.values(state.nations).find((n) => !n.isPlayer)!;
  const aiLands = lands.filter((id) => state.territories[id].ownerId === aiNation.id);
  for (const tid of aiLands) {
    transferTerritoryOwnership(state, tid, player.id);
  }
  assert.equal(aiNation.eliminated, true, 'AI nation should be eliminated when losing all territories');
  assert(player.stats.nationsEliminated >= 1, 'Player elimination stat must increment');

  // Naval pathfinding strictly through water (never land!)
  const wA = waters[0];
  const wB = waters[Math.min(waters.length - 1, 15)];
  const seaPath = findNavalPath(state, wA, wB, false);
  if (seaPath) {
    assert(seaPath.every((id) => state.territories[id].isWater), 'Naval path must only traverse water territories');
  }

  // Build Naval Base + Transport Ship + Trireme, Embark Army, Sail & Launch Amphibious Invasion
  player.resources.gold += 5000;
  player.resources.wood += 5000;
  player.resources.stone += 5000;
  player.resources.iron += 5000;
  player.unlockedTechs.push('navigation', 'bronze_working', 'masonry', 'writing', 'currency');

  // Find or assign coastal city for naval test
  const coastalLand = lands.map((id) => state.territories[id]).find((t) => t.isCoastal && t.ownerId !== player.id)!;
  transferTerritoryOwnership(state, coastalLand.id, player.id);
  const estRes = cmdEstablishCity(state, player.id, coastalLand.id);
  assert(estRes.ok, 'Establish city on conquered coastal territory should succeed');
  const coastalCity = state.cities[coastalLand.cityId!];
  assert(coastalCity, 'Coastal city created');

  const nbRes = cmdBuildStructure(state, player.id, coastalCity.id, 'naval_bases');
  assert(nbRes.ok, `Build Naval Base failed: ${nbRes.error}`);
  for (let i = 0; i < 60; i++) stepSimulation(state, 0.5);
  assert(coastalCity.buildings.some((b) => b.buildingId === 'naval_bases'), 'Naval base construction completes');

  assert(cmdRecruitUnits(state, player.id, coastalCity.id, 'transport_ships', 2).ok);
  assert(cmdRecruitUnits(state, player.id, coastalCity.id, 'triremes', 1).ok);
  assert(cmdRecruitUnits(state, player.id, coastalCity.id, 'ancient_infantry', 4).ok);
  for (let i = 0; i < 45; i++) stepSimulation(state, 0.5);

  const fleet = Object.values(state.fleets).find((f) => f.nationId === player.id)!;
  assert(fleet, 'Fleet must spawn at coastal harbor');
  const coastArmy = Object.values(state.armies).find(
    (a) => a.nationId === player.id && a.territoryId === coastalLand.id && !a.embarkedFleetId
  )!;
  assert(coastArmy, 'Army must spawn at coastal city');

  const embRes = cmdEmbarkArmy(state, player.id, coastArmy.id, fleet.id);
  assert(embRes.ok, `Embark failed: ${embRes.error}`);
  assert(fleet.carriedArmyIds.includes(coastArmy.id), 'Fleet carries embarked army');

  // Sail fleet to a water zone touching another coastal target
  const seaAdj = coastalLand.seaNeighbors[0];
  assert(seaAdj, 'Coastal territory has adjacent sea zone');
  const targetEnemyCoast = state.territories[seaAdj].landNeighbors.find(
    (nid) => nid !== coastalLand.id && state.territories[nid].ownerId !== player.id
  ) ?? lands.map((id) => state.territories[id]).find((t) => t.isCoastal && t.ownerId !== player.id)!.id;

  const targetCoastSea = state.territories[targetEnemyCoast].seaNeighbors[0];
  assert(cmdMoveFleet(state, player.id, fleet.id, targetCoastSea, 'blockade').ok);
  for (let i = 0; i < 120; i++) {
    stepSimulation(state, 0.5);
    if (fleet.territoryId === targetCoastSea && fleet.path.length === 0) break;
  }
  assert.equal(fleet.territoryId, targetCoastSea, 'Fleet must arrive at target coastal waters');

  const amphRes = cmdLaunchAmphibiousInvasion(state, player.id, fleet.id, targetEnemyCoast);
  assert(amphRes.ok, `Amphibious invasion failed: ${amphRes.error}`);
  for (let i = 0; i < 60; i++) {
    stepSimulation(state, 0.5);
    if (state.territories[targetEnemyCoast].ownerId === player.id) break;
  }
  assert.equal(state.territories[targetEnemyCoast].ownerId, player.id, 'Amphibious invasion must capture overseas coastal province!');
  console.log('✓ Stage 2 verified (terrain modifiers, elimination, naval A*, embarkation, amphibious invasion)');

  console.log('--- Testing Stage 3 & 4: Tech Difficulty Scaling, Resource/Building Requirements, Diplomacy, Market, Government & Policies ---');
  // Tech progression steepness across eras
  const avgByEra = (era: string) => {
    const list = TECHNOLOGIES.filter((t) => t.era === era);
    return list.reduce((s, t) => s + t.cost, 0) / list.length;
  };
  assert(avgByEra('classical') > avgByEra('ancient') * 2.2, 'Classical tech costs must scale steeply over Ancient');
  assert(avgByEra('medieval') > avgByEra('classical') * 2.0, 'Medieval tech costs must scale steeply over Classical');
  assert(avgByEra('industrial') > avgByEra('renaissance') * 2.0, 'Industrial tech costs must scale steeply over Renaissance');
  assert(avgByEra('future') > avgByEra('modern') * 2.0, 'Future tech costs must scale steeply over Modern');
  assert(TECHNOLOGIES.every((t) => t.resourceCost && Object.keys(t.resourceCost).length >= 2), 'Every tech must require strategic resources');

  // Knowledge complexity scaling: more unlocked techs => higher effective Science cost
  const effCostBefore = getEffectiveTechCost(TECH_BY_ID['agriculture'], player);
  player.unlockedTechs.push('dummy_tech_1', 'dummy_tech_2', 'dummy_tech_3', 'dummy_tech_4', 'dummy_tech_5');
  const effCostAfter = getEffectiveTechCost(TECH_BY_ID['agriculture'], player);
  assert(effCostAfter > effCostBefore, 'Effective tech cost must increase as civilization unlocks more technologies');
  player.unlockedTechs = player.unlockedTechs.filter((id) => !id.startsWith('dummy_tech_'));

  // Resource gating & spending
  const savedGold = player.resources.gold;
  player.resources.gold = 5;
  const failAgRes = cmdSelectTech(state, player.id, 'agriculture');
  assert.equal(failAgRes.ok, false, 'Should reject agriculture research when Gold is insufficient');
  player.resources.gold = savedGold;

  const goldBeforeAg = player.resources.gold;
  const foodBeforeAg = player.resources.food;
  assert(cmdSelectTech(state, player.id, 'agriculture').ok, 'Research agriculture succeeds with resources');
  assert(player.resources.gold < goldBeforeAg && player.resources.food < foodBeforeAg, 'Starting agriculture must deduct required Gold & Food');

  // Step progress, switch to mining, then resume agriculture without double-paying
  stepSimulation(state, 1.0);
  const progressAfterStep = player.techProgress;
  assert(progressAfterStep > 0, 'Research progress should accumulate');
  assert(cmdSelectTech(state, player.id, 'mining').ok, 'Switch research to mining');
  const goldBeforeResume = player.resources.gold;
  assert(cmdSelectTech(state, player.id, 'agriculture').ok, 'Resume agriculture');
  assert.equal(player.resources.gold, goldBeforeResume, 'Resuming already-funded tech must not double-charge resources');
  assert.equal(player.techProgress, progressAfterStep, 'Resuming tech must restore saved science progress');

  // Building requirement gating: philosophy requires a Library
  player.resources.gold += 1000;
  player.resources.culture += 200;
  player.resources.influence += 200;
  const philStatusNoLib = getTechRequirementsStatus(state, player, TECH_BY_ID['philosophy']);
  assert.equal(philStatusNoLib.missingBuilding, 'libraries', 'Philosophy must report missing Library building');
  assert.equal(cmdSelectTech(state, player.id, 'philosophy').ok, false, 'Philosophy must fail without a Library');

  const capCity = Object.values(state.cities).find((c) => c.nationId === player.id && c.isCapital)!;
  capCity.buildings.push({ buildingId: 'libraries', level: 1 });
  assert(cmdSelectTech(state, player.id, 'philosophy').ok, 'Philosophy must succeed once a Library is built');

  // Modern starting era sanity check (has required infrastructure & resources)
  const modernWorld = generateWorld({ ...config, startingEra: 'modern', seed: 999111 });
  const modPlayer = modernWorld.nations[modernWorld.playerNationId];
  const telecomStatus = getTechRequirementsStatus(modernWorld, modPlayer, TECH_BY_ID['telecommunications']);
  assert(telecomStatus.canStart, `Modern start should allow starting Telecommunications: missing=${JSON.stringify(telecomStatus)}`);
  const autoStatus = getTechRequirementsStatus(modernWorld, modPlayer, TECH_BY_ID['automobiles']);
  assert(autoStatus.canStart, `Modern start should allow starting Automobiles: missing=${JSON.stringify(autoStatus)}`);

  const otherAlive = Object.values(state.nations).find((n) => !n.isPlayer && !n.eliminated)!;
  assert(cmdDiplomacyAction(state, player.id, otherAlive.id, 'gift', 'gold', 100).ok);
  assert(cmdDiplomacyAction(state, player.id, otherAlive.id, 'trade').ok);
  assert(cmdMarketTrade(state, player.id, 'iron', 'buy', 50).ok);

  player.resources.influence += 200;
  player.unlockedTechs.push('philosophy');
  assert(cmdChangeGovernment(state, player.id, 'republic').ok);
  assert.equal(player.government, 'republic');
  assert(cmdTogglePolicy(state, player.id, 'free_trade_charter').ok);
  cmdUpdateBudget(state, player.id, { taxRate: 22, educationFunding: 80 });
  assert.equal(player.budget.taxRate, 22);

  // Verify speed 2x and 4x run cleanly
  state.speed = 2;
  stepSimulation(state, 0.5);
  state.speed = 4;
  stepSimulation(state, 0.5);
  state.speed = 0;
  const tBeforePause = state.tick;
  stepSimulation(state, 0.5);
  assert.equal(state.tick, tBeforePause, 'Paused simulation must not advance ticks');
  console.log('✓ Stage 3 & 4 verified (tech, diplomacy, market, government, budget, speed/pause)');
}

testStages1to4();
console.log('ALL CORE ENGINE STAGE TESTS PASSED!');
