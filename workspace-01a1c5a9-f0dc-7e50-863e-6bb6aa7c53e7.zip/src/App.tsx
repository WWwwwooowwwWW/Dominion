import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BottomPanel } from './components/BottomPanel';
import { EncyclopediaModal } from './components/EncyclopediaModal';
import { LeftNavPanel } from './components/LeftNavPanel';
import { MainMenu } from './components/MainMenu';
import { MultiplayerLobby } from './components/MultiplayerLobby';
import { NewGameModal } from './components/NewGameModal';
import { RightInfoPanel } from './components/RightInfoPanel';
import { SaveLoadModal } from './components/SaveLoadModal';
import { SettingsModal } from './components/SettingsModal';
import { TopResourceBar } from './components/TopResourceBar';
import { WorldMapCanvas } from './components/WorldMapCanvas';
import { CityManagerView } from './components/views/CityManagerView';
import { DiplomacyView } from './components/views/DiplomacyView';
import { EconomyView } from './components/views/EconomyView';
import { EventModal } from './components/views/EventModal';
import { GovernmentView } from './components/views/GovernmentView';
import { MilitaryView } from './components/views/MilitaryView';
import { NavyView } from './components/views/NavyView';
import { StatisticsView } from './components/views/StatisticsView';
import { TechTreeModal } from './components/views/TechTreeModal';
import { TutorialModal } from './components/views/TutorialModal';
import { VictoryModal } from './components/views/VictoryModal';
import { soundEngine } from './engine/sound';
import {
  cmdAdjustCityOccupation,
  cmdAttackEnemyFleet,
  cmdAttackOrMoveArmy,
  cmdBuildStructure,
  cmdChangeGovernment,
  cmdDiplomacyAction,
  cmdEmbarkArmy,
  cmdEstablishCity,
  cmdLaunchAmphibiousInvasion,
  cmdMarketTrade,
  cmdMoveFleet,
  cmdRecruitUnits,
  cmdResolveEvent,
  cmdSelectTech,
  cmdTogglePolicy,
  cmdUpdateBudget,
  stepSimulation,
} from './engine/simulation';
import { generateWorld } from './engine/worldGen';
import { apiRecordMatchHistory, apiSaveGame } from './services/api';
import { wsClient } from './services/wsClient';
import {
  BudgetSettings,
  Fleet,
  GameConfig,
  GameSettings,
  GameSpeed,
  GameState,
  GovernmentType,
  LeftNavTab,
  MapOverlayMode,
  OccupationKey,
  ResourceKey,
} from './types/game';

const DEFAULT_SETTINGS: GameSettings = {
  sfxEnabled: true,
  sfxVolume: 0.3,
  showTerritoryLabels: true,
  showResourceBadges: true,
  showUnitBanners: true,
  showTradeRoutes: true,
  autosaveMinutes: 2,
  uiScale: 'standard',
};

export const App: React.FC = () => {
  const [screen, setScreen] = useState<'menu' | 'game'>('menu');
  const [gameState, setGameState] = useState<GameState | null>(null);
  const stateRef = useRef<GameState | null>(null);
  stateRef.current = gameState;

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('dominion_settings_v1');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [overlay, setOverlay] = useState<MapOverlayMode>('political');
  const [activeTab, setActiveTab] = useState<LeftNavTab | null>(null);
  const [selectedTerritoryId, setSelectedTerritoryId] = useState<string | null>(null);
  const [selectedArmyId, setSelectedArmyId] = useState<string | null>(null);
  const [selectedFleetId, setSelectedFleetId] = useState<string | null>(null);
  const [focusCityId, setFocusCityId] = useState<string | null>(null);

  // Modals
  const [newGameMode, setNewGameMode] = useState<'singleplayer' | 'custom' | null>(null);
  const [showSaveLoad, setShowSaveLoad] = useState(false);
  const [showMultiplayer, setShowMultiplayer] = useState(false);
  const [showEncyclopedia, setShowEncyclopedia] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [toast, setToast] = useState<{ text: string; kind: 'ok' | 'err' } | null>(null);

  const showToast = useCallback((text: string, kind: 'ok' | 'err' = 'ok') => {
    setToast({ text, kind });
    setTimeout(() => {
      setToast((cur) => (cur?.text === text ? null : cur));
    }, 3200);
  }, []);

  useEffect(() => {
    soundEngine.enabled = settings.sfxEnabled;
    soundEngine.volume = settings.sfxVolume;
    try {
      localStorage.setItem('dominion_settings_v1', JSON.stringify(settings));
    } catch {
      // ignore
    }
  }, [settings]);

  // Real-time Simulation Loop for Single Player / Custom Game
  useEffect(() => {
    if (screen !== 'game' || !gameState || gameState.config.mode === 'multiplayer') return;
    const timer = setInterval(() => {
      setGameState((prev) => {
        if (!prev || prev.speed === 0) return prev;
        const next: GameState = structuredClone(prev);
        const hadWinner = Boolean(next.victory.winnerNationId);
        stepSimulation(next, 0.5);
        if (!hadWinner && next.victory.winnerNationId) {
          const w = next.nations[next.victory.winnerNationId];
          if (w) {
            soundEngine.playConquest();
            apiRecordMatchHistory({
              winnerName: w.name,
              victoryType: next.victory.victoryType ?? 'territorial',
              era: w.era,
              year: next.year,
              mode: next.config.mode,
              mapSize: next.config.mapSize,
              durationTicks: next.tick,
            });
          }
        }
        return next;
      });
    }, 500);
    return () => clearInterval(timer);
  }, [screen, gameState?.id, gameState?.config.mode]);

  // Periodic Autosave in Single Player
  useEffect(() => {
    if (screen !== 'game' || !gameState || gameState.config.mode === 'multiplayer') return;
    const ms = Math.max(45000, settings.autosaveMinutes * 60000);
    const id = setInterval(() => {
      if (stateRef.current) {
        apiSaveGame(stateRef.current, `${stateRef.current.nations[stateRef.current.playerNationId]?.name} (Autosave)`, 'autosave_latest', true);
      }
    }, ms);
    return () => clearInterval(id);
  }, [screen, gameState?.id, settings.autosaveMinutes]);

  // Multiplayer WebSocket state updates listener
  useEffect(() => {
    const unsub = wsClient.subscribe((msg) => {
      if (msg.type === 'match_state' && msg.state) {
        setGameState(msg.state);
      } else if (msg.type === 'error' && msg.message) {
        showToast(msg.message, 'err');
      }
    });
    return unsub;
  }, [showToast]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (screen !== 'game' || !stateRef.current) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) return;
      if (e.key === 'Escape') {
        setActiveTab(null);
      } else if (e.key === ' ') {
        e.preventDefault();
        handleSetSpeed(stateRef.current.speed === 0 ? 1 : 0);
      } else if (e.key === '1') handleSetSpeed(1);
      else if (e.key === '2') handleSetSpeed(2);
      else if (e.key === '4') handleSetSpeed(4);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [screen]);

  const startNewGame = (config: GameConfig) => {
    const world = generateWorld(config);
    stepSimulation(world, 0.1);
    world.tick = 0;
    const capId = world.nations[world.playerNationId]?.capitalTerritoryId ?? null;
    setGameState(world);
    setSelectedTerritoryId(capId);
    const firstArmy = Object.values(world.armies).find((a) => a.nationId === world.playerNationId);
    setSelectedArmyId(firstArmy?.id ?? null);
    setSelectedFleetId(null);
    setActiveTab(null);
    setNewGameMode(null);
    setScreen('game');
    soundEngine.playConquest();
    apiSaveGame(world, `${world.nations[world.playerNationId]?.name} (Autosave)`, 'autosave_latest', true);
  };

  const quickNewGame = () => {
    startNewGame({
      mode: 'singleplayer',
      seed: Math.floor(100000 + Math.random() * 899999),
      mapSize: 'medium',
      aiCount: 6,
      aiDifficulty: 'easy',
      startingEra: 'ancient',
      resourceAbundance: 'standard',
      terrainStyle: 'continents',
      startingResourcesMultiplier: 1.0,
      playerNationName: 'Dominion Empire',
      playerLeaderName: 'Sovereign Valen',
      playerColor: '#2dd4bf',
      playerEmblem: 'eagle',
      speedMultiplier: 1.0,
    });
  };

  const handleLoadedGame = (loaded: GameState) => {
    setGameState(loaded);
    setSelectedTerritoryId(loaded.nations[loaded.playerNationId]?.capitalTerritoryId ?? null);
    setSelectedArmyId(null);
    setSelectedFleetId(null);
    setActiveTab(null);
    setScreen('game');
    showToast(`Loaded campaign: ${loaded.nations[loaded.playerNationId]?.name}`, 'ok');
  };

  const mutateGame = useCallback(
    (
      fn: (draft: GameState) => { ok?: boolean; error?: string; message?: string } | void,
      mpAction?: { action: string; payload: Record<string, unknown> }
    ) => {
      if (!stateRef.current) return;
      if (stateRef.current.config.mode === 'multiplayer' && mpAction) {
        wsClient.sendCommand(mpAction.action, mpAction.payload);
        soundEngine.playClick();
        return;
      }
      const next: GameState = structuredClone(stateRef.current);
      const res = fn(next);
      if (res && res.ok === false) {
        showToast(res.error || res.message || 'Action unavailable.', 'err');
        return;
      }
      if (res?.message) showToast(res.message, 'ok');
      soundEngine.playClick();
      setGameState(next);
    },
    [showToast]
  );

  const handleSetSpeed = (speed: GameSpeed) => {
    mutateGame(
      (draft) => {
        draft.speed = speed;
      },
      { action: 'set_speed', payload: { speed } }
    );
  };

  const handleQuickSave = async () => {
    if (!gameState) return;
    await apiSaveGame(gameState, `${gameState.nations[gameState.playerNationId]?.name} QuickSave`, 'quicksave_slot', false);
    showToast('Campaign saved successfully!', 'ok');
  };

  const scaleClass =
    settings.uiScale === 'compact'
      ? 'dom-scale-compact'
      : settings.uiScale === 'large'
        ? 'dom-scale-large'
        : 'dom-scale-standard';

  return (
    <div className={scaleClass} style={{ width: '100vw', height: '100vh' }}>
      {screen === 'menu' || !gameState ? (
        <MainMenu
          hasActiveSession={Boolean(gameState)}
          onResumeActiveSession={() => setScreen('game')}
          onOpenNewGame={(m) => setNewGameMode(m)}
          onQuickNewGame={quickNewGame}
          onOpenLoad={() => setShowSaveLoad(true)}
          onLoadedGame={handleLoadedGame}
          onOpenMultiplayer={() => setShowMultiplayer(true)}
          onOpenEncyclopedia={() => setShowEncyclopedia(true)}
          onOpenSettings={() => setShowSettings(true)}
        />
      ) : (
        <div className="dom-game-shell">
          <TopResourceBar
            state={gameState}
            onSetSpeed={handleSetSpeed}
            onQuickSave={handleQuickSave}
            onOpenMenu={() => setScreen('menu')}
            onOpenTechTree={() => setActiveTab('technology')}
          />

          <LeftNavPanel
            state={gameState}
            activeTab={activeTab}
            onSelectTab={(tab) => {
              soundEngine.playClick();
              setActiveTab(tab);
            }}
            onOpenEncyclopedia={() => setShowEncyclopedia(true)}
            onOpenSaveLoad={() => setShowSaveLoad(true)}
            onOpenTutorial={() => setShowTutorial(true)}
          />

          <WorldMapCanvas
            state={gameState}
            overlay={overlay}
            onChangeOverlay={setOverlay}
            selectedTerritoryId={selectedTerritoryId}
            selectedArmyId={selectedArmyId}
            selectedFleetId={selectedFleetId}
            onSelectTerritory={(tid) => setSelectedTerritoryId(tid)}
            onSelectArmy={(aid) => setSelectedArmyId(aid)}
            onSelectFleet={(fid) => setSelectedFleetId(fid)}
            settings={settings}
          />

          <RightInfoPanel
            state={gameState}
            selectedTerritoryId={selectedTerritoryId}
            selectedArmyId={selectedArmyId}
            selectedFleetId={selectedFleetId}
            onSelectArmy={setSelectedArmyId}
            onSelectFleet={setSelectedFleetId}
            onAttackOrMoveArmy={(armyId, targetTerritoryId) => {
              soundEngine.playWarHorn();
              mutateGame(
                (d) => cmdAttackOrMoveArmy(d, d.playerNationId, armyId, targetTerritoryId),
                { action: 'attack_move_army', payload: { armyId, targetTerritoryId } }
              );
            }}
            onMoveFleet={(fleetId, targetTerritoryId, mission) =>
              mutateGame(
                (d) => cmdMoveFleet(d, d.playerNationId, fleetId, targetTerritoryId, mission),
                { action: 'move_fleet', payload: { fleetId, targetTerritoryId, mission } }
              )
            }
            onAttackEnemyFleet={(fleetId, enemyFleetId) => {
              soundEngine.playWarHorn();
              mutateGame(
                (d) => cmdAttackEnemyFleet(d, d.playerNationId, fleetId, enemyFleetId),
                { action: 'attack_fleet', payload: { fleetId, enemyFleetId } }
              );
            }}
            onEmbarkArmy={(armyId, fleetId) =>
              mutateGame(
                (d) => cmdEmbarkArmy(d, d.playerNationId, armyId, fleetId),
                { action: 'embark_army', payload: { armyId, fleetId } }
              )
            }
            onLaunchAmphibious={(fleetId, targetTerritoryId) => {
              soundEngine.playWarHorn();
              mutateGame(
                (d) => cmdLaunchAmphibiousInvasion(d, d.playerNationId, fleetId, targetTerritoryId),
                { action: 'launch_amphibious', payload: { fleetId, targetTerritoryId } }
              );
            }}
            onEstablishCity={(territoryId) =>
              mutateGame(
                (d) => cmdEstablishCity(d, d.playerNationId, territoryId),
                { action: 'establish_city', payload: { territoryId } }
              )
            }
            onBuildStructure={(cityId, buildingId) =>
              mutateGame(
                (d) => cmdBuildStructure(d, d.playerNationId, cityId, buildingId),
                { action: 'build_structure', payload: { cityId, buildingId } }
              )
            }
            onRecruitUnits={(cityId, unitId, count = 1) =>
              mutateGame(
                (d) => cmdRecruitUnits(d, d.playerNationId, cityId, unitId, count),
                { action: 'recruit_units', payload: { cityId, unitId, count } }
              )
            }
            onOpenFullCity={(cityId) => {
              setFocusCityId(cityId);
              setActiveTab('cities');
            }}
            onOpenDiplomacy={() => setActiveTab('diplomacy')}
          />

          <BottomPanel
            state={gameState}
            onFocusTerritory={(tid) => setSelectedTerritoryId(tid)}
            onOpenTechTree={() => setActiveTab('technology')}
          />

          {/* Left Nav Views */}
          {activeTab === 'cities' && (
            <CityManagerView
              state={gameState}
              initialCityId={focusCityId}
              onBuildStructure={(cityId, buildingId) =>
                mutateGame(
                  (d) => cmdBuildStructure(d, d.playerNationId, cityId, buildingId),
                  { action: 'build_structure', payload: { cityId, buildingId } }
                )
              }
              onAdjustOccupation={(cityId, key: OccupationKey, delta) =>
                mutateGame(
                  (d) => cmdAdjustCityOccupation(d, d.playerNationId, cityId, key, delta),
                  { action: 'adjust_occupation', payload: { cityId, key, delta } }
                )
              }
              onFocusTerritory={(tid) => setSelectedTerritoryId(tid)}
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'military' && (
            <MilitaryView
              state={gameState}
              onRecruitUnits={(cityId, unitId, count) =>
                mutateGame(
                  (d) => cmdRecruitUnits(d, d.playerNationId, cityId, unitId, count),
                  { action: 'recruit_units', payload: { cityId, unitId, count } }
                )
              }
              onSelectArmyOnMap={(armyId, tid) => {
                setSelectedArmyId(armyId);
                setSelectedFleetId(null);
                setSelectedTerritoryId(tid);
              }}
              onToggleFortify={(armyId) =>
                mutateGame((d) => {
                  const a = d.armies[armyId];
                  if (a) a.fortified = !a.fortified;
                })
              }
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'navy' && (
            <NavyView
              state={gameState}
              onRecruitUnits={(cityId, unitId, count) =>
                mutateGame(
                  (d) => cmdRecruitUnits(d, d.playerNationId, cityId, unitId, count),
                  { action: 'recruit_units', payload: { cityId, unitId, count } }
                )
              }
              onSelectFleetOnMap={(fleetId, tid) => {
                setSelectedFleetId(fleetId);
                setSelectedArmyId(null);
                setSelectedTerritoryId(tid);
              }}
              onMoveFleet={(fleetId, tid, mission) =>
                mutateGame(
                  (d) => cmdMoveFleet(d, d.playerNationId, fleetId, tid, mission),
                  { action: 'move_fleet', payload: { fleetId, targetTerritoryId: tid, mission } }
                )
              }
              onEmbarkArmy={(armyId, fleetId) =>
                mutateGame(
                  (d) => cmdEmbarkArmy(d, d.playerNationId, armyId, fleetId),
                  { action: 'embark_army', payload: { armyId, fleetId } }
                )
              }
              onLaunchAmphibious={(fleetId, targetTerritoryId) => {
                soundEngine.playWarHorn();
                mutateGame(
                  (d) => cmdLaunchAmphibiousInvasion(d, d.playerNationId, fleetId, targetTerritoryId),
                  { action: 'launch_amphibious', payload: { fleetId, targetTerritoryId } }
                );
              }}
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'technology' && (
            <TechTreeModal
              state={gameState}
              onSelectTech={(techId) =>
                mutateGame(
                  (d) => cmdSelectTech(d, d.playerNationId, techId),
                  { action: 'select_tech', payload: { techId } }
                )
              }
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'diplomacy' && (
            <DiplomacyView
              state={gameState}
              onDiplomacyAction={(otherId, dipAction, giftResource?: ResourceKey, giftAmount?: number) =>
                mutateGame(
                  (d) => cmdDiplomacyAction(d, d.playerNationId, otherId, dipAction, giftResource, giftAmount),
                  { action: 'diplomacy', payload: { otherId, dipAction, giftResource, giftAmount } }
                )
              }
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'economy' && (
            <EconomyView
              state={gameState}
              onMarketTrade={(resource, side, amount) =>
                mutateGame(
                  (d) => cmdMarketTrade(d, d.playerNationId, resource, side, amount),
                  { action: 'market_trade', payload: { resource, side, amount } }
                )
              }
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'government' && (
            <GovernmentView
              state={gameState}
              onChangeGovernment={(govId: GovernmentType) =>
                mutateGame(
                  (d) => cmdChangeGovernment(d, d.playerNationId, govId),
                  { action: 'change_government', payload: { govId } }
                )
              }
              onTogglePolicy={(policyId) =>
                mutateGame(
                  (d) => cmdTogglePolicy(d, d.playerNationId, policyId),
                  { action: 'toggle_policy', payload: { policyId } }
                )
              }
              onUpdateBudget={(patch: Partial<BudgetSettings>) =>
                mutateGame(
                  (d) => cmdUpdateBudget(d, d.playerNationId, patch),
                  { action: 'update_budget', payload: { patch } }
                )
              }
              onClose={() => setActiveTab(null)}
            />
          )}

          {activeTab === 'statistics' && (
            <StatisticsView state={gameState} onClose={() => setActiveTab(null)} />
          )}

          {/* World Event Modal */}
          {gameState.pendingEvent && (
            <EventModal
              event={gameState.pendingEvent}
              onChoose={(choiceId) =>
                mutateGame((d) => {
                  cmdResolveEvent(d, choiceId);
                })
              }
            />
          )}

          {/* Victory Modal */}
          {gameState.victory.winnerNationId && !gameState.victory.continuedAfterVictory && (
            <VictoryModal
              state={gameState}
              onContinuePlaying={() =>
                mutateGame((d) => {
                  d.victory.continuedAfterVictory = true;
                  d.speed = 1;
                })
              }
              onReturnToMenu={() => setScreen('menu')}
            />
          )}
        </div>
      )}

      {/* Global Shared Modals */}
      {newGameMode && (
        <NewGameModal
          initialMode={newGameMode}
          onLaunch={startNewGame}
          onClose={() => setNewGameMode(null)}
        />
      )}

      {showSaveLoad && (
        <SaveLoadModal
          currentState={gameState}
          onLoadedGame={handleLoadedGame}
          onClose={() => setShowSaveLoad(false)}
        />
      )}

      {showMultiplayer && (
        <MultiplayerLobby
          onMatchStarted={(mpState) => {
            setShowMultiplayer(false);
            setGameState(mpState);
            setSelectedTerritoryId(mpState.nations[mpState.playerNationId]?.capitalTerritoryId ?? null);
            setScreen('game');
          }}
          onClose={() => setShowMultiplayer(false)}
        />
      )}

      {showEncyclopedia && <EncyclopediaModal onClose={() => setShowEncyclopedia(false)} />}
      {showSettings && <SettingsModal settings={settings} onChange={setSettings} onClose={() => setShowSettings(false)} />}
      {showTutorial && <TutorialModal onClose={() => setShowTutorial(false)} />}

      {/* Floating Feedback Toast */}
      {toast && (
        <div
          style={{
            position: 'fixed',
            bottom: 24,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 200,
            padding: '9px 16px',
            borderRadius: 6,
            fontSize: 12.5,
            fontWeight: 700,
            background: toast.kind === 'err' ? '#7f1d1d' : '#0f291e',
            border: `1px solid ${toast.kind === 'err' ? '#ef4444' : '#34d399'}`,
            color: '#fff',
            boxShadow: '0 10px 30px rgba(0,0,0,0.65)',
          }}
        >
          {toast.text}
        </div>
      )}
    </div>
  );
};
