import { GameState, MultiplayerLobby } from '../types/game';

export type WsEventHandler = (msg: {
  type: string;
  lobbies?: MultiplayerLobby[];
  lobby?: MultiplayerLobby;
  state?: GameState;
  yourNationId?: string;
  message?: string;
  username?: string;
}) => void;

class DominionWsClient {
  private ws: WebSocket | null = null;
  private listeners = new Set<WsEventHandler>();
  private connected = false;

  public connect(username?: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        if (username) this.send({ type: 'identify', username });
        resolve();
        return;
      }
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = `${proto}//${window.location.host}/ws`;
      const socket = new WebSocket(url);
      this.ws = socket;

      socket.onopen = () => {
        this.connected = true;
        if (username) this.send({ type: 'identify', username });
        resolve();
      };
      socket.onerror = () => {
        reject(new Error('WebSocket connection failed.'));
      };
      socket.onclose = () => {
        this.connected = false;
      };
      socket.onmessage = (ev) => {
        try {
          const data = JSON.parse(ev.data);
          for (const fn of this.listeners) fn(data);
        } catch {
          // ignore
        }
      };
    });
  }

  public isConnected(): boolean {
    return this.connected && this.ws?.readyState === WebSocket.OPEN;
  }

  public subscribe(fn: WsEventHandler): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  public send(payload: unknown): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  public sendCommand(action: string, payload: Record<string, unknown>): void {
    this.send({ type: 'game_command', action, payload });
  }

  public disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
      this.connected = false;
    }
  }
}

export const wsClient = new DominionWsClient();
