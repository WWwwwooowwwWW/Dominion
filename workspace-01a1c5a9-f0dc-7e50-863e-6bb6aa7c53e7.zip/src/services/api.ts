import { GameState, MultiplayerLobby, PlayerAccount, SaveSlotSummary } from '../types/game';

const LOCAL_SAVES_KEY = 'dominion_local_saves_v1';

export async function apiAuth(
  username: string,
  password: string,
  preferredColor?: string,
  preferredEmblem?: string
): Promise<{ ok: boolean; account?: PlayerAccount; error?: string }> {
  const res = await fetch('/api/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, preferredColor, preferredEmblem }),
  });
  return res.json();
}

export async function apiGetLeaderboard(): Promise<PlayerAccount[]> {
  try {
    const res = await fetch('/api/leaderboard');
    const data = await res.json();
    return data.accounts ?? [];
  } catch {
    return [];
  }
}

export async function apiGetMatchHistory(): Promise<Array<Record<string, unknown>>> {
  try {
    const res = await fetch('/api/history');
    const data = await res.json();
    return data.history ?? [];
  } catch {
    return [];
  }
}

export async function apiRecordMatchHistory(entry: {
  winnerName: string;
  victoryType: string;
  era: string;
  year: number;
  mode: string;
  mapSize: string;
  durationTicks: number;
}): Promise<void> {
  try {
    await fetch('/api/history', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry),
    });
  } catch {
    // ignore offline
  }
}

export async function apiListSaves(): Promise<SaveSlotSummary[]> {
  try {
    const res = await fetch('/api/saves');
    const data = await res.json();
    if (Array.isArray(data.saves)) return data.saves;
  } catch {
    // fallback below
  }
  try {
    const raw = localStorage.getItem(LOCAL_SAVES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Record<string, { summary: SaveSlotSummary }>;
    return Object.values(parsed)
      .map((x) => x.summary)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

export async function apiSaveGame(
  state: GameState,
  slotName: string,
  slotId?: string,
  isAutosave = false
): Promise<SaveSlotSummary | null> {
  const player = state.nations[state.playerNationId];
  const landTerritories = state.territoryIds.filter((id) => !state.territories[id].isWater);
  const owned = landTerritories.filter((id) => state.territories[id].ownerId === state.playerNationId).length;

  const id = slotId ?? (isAutosave ? 'autosave_latest' : `save_${Date.now()}`);
  const summary: SaveSlotSummary = {
    id,
    name: slotName,
    nationName: player?.name ?? 'Dominion',
    era: player?.era ?? 'ancient',
    year: state.year,
    territoriesOwned: owned,
    totalLandTerritories: landTerritories.length,
    difficulty: state.config.aiDifficulty,
    isAutosave,
    updatedAt: new Date().toISOString(),
  };

  const stateJson = JSON.stringify(state);
  try {
    const raw = localStorage.getItem(LOCAL_SAVES_KEY);
    const map = raw ? JSON.parse(raw) : {};
    map[id] = { summary, stateJson };
    localStorage.setItem(LOCAL_SAVES_KEY, JSON.stringify(map));
  } catch {
    // quota fallback
  }

  try {
    const res = await fetch('/api/saves', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...summary, stateJson }),
    });
    const data = await res.json();
    if (data.ok && data.slot) return data.slot;
  } catch {
    // localStorage fallback succeeded
  }
  return summary;
}

export async function apiLoadGame(id: string): Promise<GameState | null> {
  try {
    const res = await fetch(`/api/saves/${encodeURIComponent(id)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.ok && data.state) return data.state as GameState;
    }
  } catch {
    // fallback
  }
  try {
    const raw = localStorage.getItem(LOCAL_SAVES_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, { stateJson: string }>;
    if (map[id]?.stateJson) return JSON.parse(map[id].stateJson) as GameState;
  } catch {
    return null;
  }
  return null;
}

export async function apiDeleteSave(id: string): Promise<void> {
  try {
    await fetch(`/api/saves/${encodeURIComponent(id)}`, { method: 'DELETE' });
  } catch {
    // ignore
  }
  try {
    const raw = localStorage.getItem(LOCAL_SAVES_KEY);
    if (raw) {
      const map = JSON.parse(raw);
      delete map[id];
      localStorage.setItem(LOCAL_SAVES_KEY, JSON.stringify(map));
    }
  } catch {
    // ignore
  }
}

export async function apiListLobbies(): Promise<MultiplayerLobby[]> {
  try {
    const res = await fetch('/api/lobbies');
    const data = await res.json();
    return data.lobbies ?? [];
  } catch {
    return [];
  }
}
