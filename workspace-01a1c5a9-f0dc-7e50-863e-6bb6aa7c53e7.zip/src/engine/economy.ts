import { BUILDING_BY_ID } from '../data/buildings';
import { GOVERNMENTS, POLICY_BY_ID } from '../data/governments';
import { TECH_BY_ID } from '../data/technologies';
import { TERRAINS } from '../data/terrains';
import { UNIT_BY_ID } from '../data/units';
import { GameState, Nation, ResourceKey, ResourcePool } from '../types/game';
import { emptyResourcePool } from './worldGen';

export const ALL_RESOURCE_KEYS: ResourceKey[] = [
  'gold',
  'food',
  'wood',
  'stone',
  'iron',
  'coal',
  'oil',
  'science',
  'culture',
  'influence',
  'energy',
];

export function getTerritoryScalingFactor(indexOneBased: number): number {
  if (indexOneBased <= 10) return 1.0;
  if (indexOneBased <= 25) return 0.75;
  if (indexOneBased <= 50) return 0.55;
  return 0.38;
}

export function canAfford(nation: Nation, cost: Partial<ResourcePool>): boolean {
  for (const k of ALL_RESOURCE_KEYS) {
    const req = cost[k] ?? 0;
    if (req > 0 && nation.resources[k] < req) return false;
  }
  return true;
}

export function spendResources(nation: Nation, cost: Partial<ResourcePool>): void {
  for (const k of ALL_RESOURCE_KEYS) {
    const req = cost[k] ?? 0;
    if (req > 0) {
      nation.resources[k] = Math.max(0, nation.resources[k] - req);
    }
  }
}

export function recomputeNationEconomy(state: GameState, nation: Nation, dtMinutes: number): void {
  if (nation.eliminated) return;

  const ownedTerritories = state.territoryIds
    .map((id) => state.territories[id])
    .filter((t) => !t.isWater && t.ownerId === nation.id);

  const ownedCities = Object.values(state.cities).filter((c) => c.nationId === nation.id);

  // Aggregate tech bonuses
  let foodMod = 1;
  let woodMod = 1;
  let stoneMod = 1;
  let ironMod = 1;
  let goldMod = 1;
  let scienceMod = 1;
  let industryMod = 1;
  let energyMod = 1;
  let adminCap = 8;

  for (const tid of nation.unlockedTechs) {
    const t = TECH_BY_ID[tid];
    if (!t?.bonuses) continue;
    foodMod += t.bonuses.foodMod ?? 0;
    woodMod += t.bonuses.woodMod ?? 0;
    stoneMod += t.bonuses.stoneMod ?? 0;
    ironMod += t.bonuses.ironMod ?? 0;
    goldMod += t.bonuses.goldMod ?? 0;
    scienceMod += t.bonuses.scienceMod ?? 0;
    industryMod += t.bonuses.industryMod ?? 0;
    energyMod += t.bonuses.energyMod ?? 0;
    adminCap += t.bonuses.adminCapBonus ?? 0;
  }

  const gov = GOVERNMENTS[nation.government];
  goldMod += gov.modifiers.goldMod;
  scienceMod += gov.modifiers.scienceMod;
  industryMod += gov.modifiers.productionMod;
  adminCap += gov.modifiers.adminCapBonus;

  for (const pid of nation.activePolicies) {
    const pol = POLICY_BY_ID[pid];
    if (!pol) continue;
    goldMod += pol.effects.goldMod ?? 0;
    scienceMod += pol.effects.scienceMod ?? 0;
    industryMod += pol.effects.productionMod ?? 0;
  }

  // City government buildings also increase admin capacity
  let storageBonus = 0;
  for (const city of ownedCities) {
    for (const b of city.buildings) {
      const def = BUILDING_BY_ID[b.buildingId];
      if (!def) continue;
      adminCap += (def.effects.adminCapacity ?? 0) * b.level;
      storageBonus += (def.effects.storageBonus ?? 0) * b.level;
    }
  }

  // Overextension / Administrative Strain
  const overTerritories = Math.max(0, ownedTerritories.length - adminCap);
  nation.adminStrain = Math.min(100, overTerritories * 3.5);
  const adminEfficiency = Math.max(0.55, 1 - nation.adminStrain * 0.004);

  // AI difficulty adjustment
  const aiDiffMult = nation.isPlayer
    ? 1.0
    : nation.aiDifficulty === 'easy'
      ? 0.58
      : nation.aiDifficulty === 'hard'
        ? 1.12
        : 0.85;

  const territoryProd = emptyResourcePool(0);
  const naturalProd = emptyResourcePool(0);
  const buildingProd = emptyResourcePool(0);
  const consumption = emptyResourcePool(0);

  // 1. Territory & Natural Deposit Production (Gradual Scaling)
  ownedTerritories.forEach((t, idx) => {
    const scale = getTerritoryScalingFactor(idx + 1) * (1 - t.occupationUnrest * 0.005);
    const tDef = TERRAINS[t.terrain];
    for (const k of ALL_RESOURCE_KEYS) {
      const base = tDef.baseYields[k] ?? 0;
      if (base > 0) {
        let amt = base * scale;
        if (k === 'food' && t.hasRiver) amt *= 1.35;
        if (k === 'gold' && t.isCoastal) amt += 6 * scale;
        territoryProd[k] += amt;
      }
    }
    // Natural Deposits
    for (const dep of t.deposits) {
      const baseDep = dep.resource === 'gold' ? 14 : dep.resource === 'oil' ? 12 : 16;
      naturalProd[dep.resource] += baseDep * dep.richness * scale;
    }
  });

  // 2. City Building & Occupation Production
  let totalPopulation = 0;
  for (const city of ownedCities) {
    totalPopulation += city.population;
    const t = state.territories[city.territoryId];
    const blockaded = Boolean(t?.blockadedByNationId);
    const occ = city.occupations;

    // Citizen occupation output scaling
    const occMultFood = 1 + (occ.farmers / Math.max(400, city.population)) * 0.9;
    const occMultMiners = 1 + (occ.miners / Math.max(400, city.population)) * 0.95;
    const occMultSci = 1 + (occ.researchers / Math.max(400, city.population)) * 1.1;
    const occMultGold = 1 + (occ.merchants / Math.max(400, city.population)) * 0.95;
    const occMultInd = 1 + ((occ.factory_workers + occ.builders) / Math.max(400, city.population)) * 0.9;
    const occMultGov = 1 + (occ.government_workers / Math.max(400, city.population)) * 0.85;

    let cityFood = 8 * occMultFood;
    let cityGold = (city.population / 180) * (nation.budget.taxRate / 15) * occMultGold;
    let cityInd = 4 * occMultInd;

    for (const b of city.buildings) {
      const def = BUILDING_BY_ID[b.buildingId];
      if (!def) continue;
      consumption.gold += def.upkeepGold * b.level;
      consumption.energy += (def.upkeepEnergy ?? 0) * b.level;

      if (def.effects.production) {
        for (const k of ALL_RESOURCE_KEYS) {
          const val = (def.effects.production[k] ?? 0) * b.level;
          if (val <= 0) continue;
          let adj = val;
          if (k === 'food') adj *= occMultFood;
          else if (k === 'stone' || k === 'iron' || k === 'coal' || k === 'oil') adj *= occMultMiners * occMultInd;
          else if (k === 'science') adj *= occMultSci;
          else if (k === 'gold') adj *= occMultGold * (blockaded && def.coastalOnly ? 0.35 : 1);
          else if (k === 'influence' || k === 'culture') adj *= occMultGov;
          buildingProd[k] += adj;
          if (k === 'food') cityFood += adj;
          if (k === 'gold') cityGold += adj;
          if (k === 'iron' || k === 'wood' || k === 'stone') cityInd += adj;
        }
      }
    }

    // Base capital science & influence baseline so players always progress even early on
    buildingProd.science += (city.isCapital ? 10 : 4) * occMultSci;
    buildingProd.culture += (city.isCapital ? 6 : 2) * occMultGov;
    buildingProd.influence += (city.isCapital ? 8 : 3) * occMultGov;

    // Citizen food consumption
    consumption.food += city.population * 0.0085;

    city.foodProduction = Math.round(cityFood);
    city.economicOutput = Math.round(cityGold);
    city.industrialOutput = Math.round(cityInd);
    buildingProd.gold += cityGold;
    buildingProd.food += 8 * occMultFood;
  }

  // 3. Budget spending costs
  const popFactor = Math.max(1, totalPopulation / 1200);
  consumption.gold += (nation.budget.educationFunding / 50) * 4 * popFactor;
  consumption.gold += (nation.budget.healthcareFunding / 50) * 3.5 * popFactor;
  consumption.gold += (nation.budget.infrastructureSpending / 50) * 3 * popFactor;

  scienceMod += (nation.budget.educationFunding - 50) * 0.004;

  // 4. Military & Naval Upkeep
  const milCostMult = (1 + gov.modifiers.militaryCostMod) * (0.65 + nation.budget.militarySpending / 140);
  for (const army of Object.values(state.armies)) {
    if (army.nationId !== nation.id) continue;
    for (const stack of army.units) {
      const u = UNIT_BY_ID[stack.unitId];
      if (!u) continue;
      consumption.gold += u.upkeepGold * stack.count * milCostMult;
      if (u.upkeepOil) consumption.oil += u.upkeepOil * stack.count;
    }
  }
  for (const fleet of Object.values(state.fleets)) {
    if (fleet.nationId !== nation.id) continue;
    for (const stack of fleet.ships) {
      const u = UNIT_BY_ID[stack.unitId];
      if (!u) continue;
      consumption.gold += u.upkeepGold * stack.count * milCostMult;
      if (u.upkeepOil) consumption.oil += u.upkeepOil * stack.count;
    }
  }

  // 5. Active International Trade Routes
  let tradeGold = 0;
  for (const route of state.tradeRoutes) {
    if (route.disrupted) continue;
    if (route.fromNationId === nation.id || route.toNationId === nation.id) {
      const tariffBonus = 1 + nation.budget.tradeTariff * 0.005;
      tradeGold += route.goldPerMin * tariffBonus;
    }
  }
  buildingProd.gold += tradeGold;

  // 6. Apply Global Modifiers & Compute Net Rates per Minute
  const mults: Record<ResourceKey, number> = {
    gold: goldMod * adminEfficiency * aiDiffMult,
    food: foodMod * aiDiffMult,
    wood: woodMod * industryMod * aiDiffMult,
    stone: stoneMod * industryMod * aiDiffMult,
    iron: ironMod * industryMod * aiDiffMult,
    coal: industryMod * aiDiffMult,
    oil: industryMod * aiDiffMult,
    science: scienceMod * adminEfficiency * aiDiffMult,
    culture: (1 + (nation.overallHappiness - 50) * 0.003) * aiDiffMult,
    influence: adminEfficiency * aiDiffMult,
    energy: industryMod * energyMod * aiDiffMult,
  };

  nation.territoryProductionBreakdown = territoryProd;
  nation.naturalDepositBreakdown = naturalProd;
  nation.buildingProductionBreakdown = buildingProd;
  nation.consumptionPerMin = consumption;

  const baseCap = 3500 + ownedTerritories.length * 360 + storageBonus;
  for (const k of ALL_RESOURCE_KEYS) {
    const gross = (territoryProd[k] + naturalProd[k] + buildingProd[k]) * mults[k];
    const net = gross - consumption[k];
    nation.ratesPerMin[k] = net;
    nation.storageCaps[k] = k === 'gold' || k === 'science' || k === 'culture' || k === 'influence' ? 999999 : baseCap;

    if (dtMinutes > 0) {
      if (k === 'science') {
        nation.resources.science = Math.max(0, nation.resources.science + Math.max(0, net) * dtMinutes);
      } else {
        nation.resources[k] = Math.max(
          0,
          Math.min(nation.storageCaps[k], nation.resources[k] + net * dtMinutes)
        );
      }
      if (k === 'gold' && net > 0) {
        nation.stats.totalGoldEarned += net * dtMinutes;
      }
    }
  }

  nation.stats.peakTerritories = Math.max(nation.stats.peakTerritories, ownedTerritories.length);
  nation.stats.peakPopulation = Math.max(nation.stats.peakPopulation, totalPopulation);
  nation.stats.economicScore = Math.round(nation.resources.gold + Math.max(0, nation.ratesPerMin.gold) * 14 + ownedCities.length * 250);
  nation.stats.scienceScore = nation.unlockedTechs.length * 140 + Math.round(nation.ratesPerMin.science * 4);
  nation.stats.cultureScore = Math.round(nation.resources.culture + nation.ratesPerMin.culture * 8);
}

export function refreshTradeRoutes(state: GameState): void {
  const routes: GameState['tradeRoutes'] = [];
  const nationIds = Object.keys(state.nations).filter((id) => !state.nations[id].eliminated);
  const tradeResources: Array<'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil'> = [
    'food',
    'wood',
    'stone',
    'iron',
    'coal',
    'oil',
  ];

  for (let i = 0; i < nationIds.length; i++) {
    for (let j = i + 1; j < nationIds.length; j++) {
      const a = state.nations[nationIds[i]];
      const b = state.nations[nationIds[j]];
      const rel = a.relations[b.id];
      if (!rel || rel.atWar || (!rel.tradeAgreement && !rel.alliance)) continue;

      const cityA = Object.values(state.cities).find((c) => c.nationId === a.id && c.isCapital) ??
        Object.values(state.cities).find((c) => c.nationId === a.id);
      const cityB = Object.values(state.cities).find((c) => c.nationId === b.id && c.isCapital) ??
        Object.values(state.cities).find((c) => c.nationId === b.id);
      if (!cityA || !cityB) continue;

      const tA = state.territories[cityA.territoryId];
      const tB = state.territories[cityB.territoryId];
      const isMaritime = tA.continentId !== tB.continentId || (tA.isCoastal && tB.isCoastal);
      const blockaded = Boolean(tA.blockadedByNationId || tB.blockadedByNationId);

      const res = tradeResources[(i + j) % tradeResources.length];
      routes.push({
        id: `tr_${a.id}_${b.id}`,
        fromNationId: a.id,
        toNationId: b.id,
        fromCityId: cityA.id,
        toCityId: cityB.id,
        isMaritime,
        goldPerMin: isMaritime ? 38 : 26,
        resourceTraded: res,
        amountPerMin: 10,
        pathTerritoryIds: [tA.id, tB.id],
        disrupted: blockaded,
      });
    }
  }
  state.tradeRoutes = routes;
}

export function updateMarketPrices(state: GameState): void {
  const keys: Array<'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil'> = [
    'food',
    'wood',
    'stone',
    'iron',
    'coal',
    'oil',
  ];
  const basePrices: Record<typeof keys[number], number> = {
    food: 1.0,
    wood: 1.2,
    stone: 1.4,
    iron: 2.2,
    coal: 2.6,
    oil: 3.5,
  };

  for (const k of keys) {
    let totalSupply = 0;
    let totalDemand = 0;
    for (const n of Object.values(state.nations)) {
      if (n.eliminated) continue;
      totalSupply += Math.max(0, n.ratesPerMin[k]);
      totalDemand += n.consumptionPerMin[k] + 5;
    }
    const ratio = (totalDemand + 10) / (totalSupply + 15);
    const target = Math.max(basePrices[k] * 0.55, Math.min(basePrices[k] * 2.4, basePrices[k] * (0.75 + ratio * 0.35)));
    const prev = state.market.prices[k];
    state.market.prices[k] = Number((prev * 0.85 + target * 0.15).toFixed(2));
    state.market.demandTrend[k] = Number((state.market.prices[k] - prev).toFixed(2));
  }
}
