import { BUILDING_BY_ID } from '../data/buildings';
import { formatYear } from '../data/eras';
import { GOVERNMENTS, POLICY_BY_ID } from '../data/governments';
import { TECH_BY_ID } from '../data/technologies';
import { TERRAINS } from '../data/terrains';
import { UNIT_BY_ID } from '../data/units';
import { ActiveBattle, Army, Fleet, GameState, Nation, Territory, UnitStack } from '../types/game';

export function getNationMilitaryMultiplier(nation: Nation | undefined): number {
  if (!nation) return 1.0;
  let mod = 1.0 + GOVERNMENTS[nation.government].modifiers.militaryPowerMod;
  for (const tid of nation.unlockedTechs) {
    mod += TECH_BY_ID[tid]?.bonuses?.militaryPowerMod ?? 0;
  }
  for (const pid of nation.activePolicies) {
    mod += POLICY_BY_ID[pid]?.effects.militaryPowerMod ?? 0;
  }
  mod *= 0.8 + nation.budget.militarySpending * 0.004;
  if (!nation.isPlayer) {
    if (nation.aiDifficulty === 'easy') mod *= 0.65;
    else if (nation.aiDifficulty === 'hard') mod *= 1.12;
    else mod *= 0.86;
  }
  return Math.max(0.4, mod);
}

export function computeUnitStacksPower(stacks: UnitStack[], isDefending: boolean, nation?: Nation): number {
  let raw = 0;
  for (const st of stacks) {
    const def = UNIT_BY_ID[st.unitId];
    if (!def || st.count <= 0) continue;
    const base = isDefending ? def.defense : def.strength;
    const hpMult = Math.max(0.2, st.hp / 100);
    const expMult = 1 + st.experience * 0.004;
    raw += base * st.count * hpMult * expMult;
  }
  return raw * getNationMilitaryMultiplier(nation);
}

export function computeArmyPower(army: Army, isDefending: boolean, state: GameState): number {
  const nation = state.nations[army.nationId];
  const base = computeUnitStacksPower(army.units, isDefending, nation);
  const supplyMult = 0.5 + (army.supply / 100) * 0.5;
  const moraleMult = 0.55 + (army.morale / 100) * 0.45;
  const fortMult = isDefending && army.fortified ? 1.2 : 1.0;
  return base * supplyMult * moraleMult * fortMult;
}

export function computeFleetPower(fleet: Fleet, isDefending: boolean, state: GameState): number {
  const nation = state.nations[fleet.nationId];
  const base = computeUnitStacksPower(fleet.ships, isDefending, nation);
  const supplyMult = 0.55 + (fleet.supply / 100) * 0.45;
  const moraleMult = 0.6 + (fleet.morale / 100) * 0.4;
  return base * supplyMult * moraleMult;
}

export function getFleetTransportCapacity(fleet: Fleet): number {
  let cap = 0;
  for (const st of fleet.ships) {
    const def = UNIT_BY_ID[st.unitId];
    if (def?.transportCapacity) cap += def.transportCapacity * st.count;
  }
  return cap;
}

export function getArmyTotalUnitCount(army: Army): number {
  return army.units.reduce((s, u) => s + u.count, 0);
}

export function computeTerritoryDefenseMultiplier(
  territory: Territory,
  attackerUnits: UnitStack[],
  originTerritory: Territory | null,
  state: GameState
): { totalDefenseMult: number; riverPenalty: boolean; fortBonus: number; terrainBonus: number } {
  const tDef = TERRAINS[territory.terrain];
  const terrainBonus = tDef.defenseBonus;

  // Siege / artillery units reduce fortification bonus
  let siegeStrength = 0;
  for (const st of attackerUnits) {
    const u = UNIT_BY_ID[st.unitId];
    if (u?.role === 'siege' || u?.role === 'armor' || u?.role === 'air') {
      siegeStrength += st.count * 0.06;
    }
  }

  let cityFortBonus = 0;
  if (territory.cityId && state.cities[territory.cityId]) {
    for (const b of state.cities[territory.cityId].buildings) {
      const def = BUILDING_BY_ID[b.buildingId];
      if (def?.effects.defenseBonus) cityFortBonus += def.effects.defenseBonus * b.level;
    }
  }
  const fortBonus = Math.max(0, (territory.fortLevel * 0.35 + cityFortBonus) * Math.max(0.35, 1 - siegeStrength));

  const riverPenalty =
    originTerritory !== null &&
    originTerritory.riverBorderNeighbors.includes(territory.id) &&
    !originTerritory.hasBridge;

  const riverFactor = riverPenalty ? 1.25 : 1.0;
  const totalDefenseMult = (1 + terrainBonus + fortBonus) * riverFactor;

  return { totalDefenseMult, riverPenalty, fortBonus, terrainBonus };
}

export function estimateCombatOdds(
  state: GameState,
  attackerArmy: Army,
  targetTerritoryId: string,
  supportingFleet?: Fleet | null
): {
  attackerPower: number;
  defenderPower: number;
  winProbability: number;
  terrainBonusPct: number;
  riverPenalty: boolean;
  coastalSupportPct: number;
} {
  const target = state.territories[targetTerritoryId];
  const origin = state.territories[attackerArmy.territoryId] ?? null;
  if (!target) {
    return { attackerPower: 0, defenderPower: 1, winProbability: 0, terrainBonusPct: 0, riverPenalty: false, coastalSupportPct: 0 };
  }

  let attackerPower = computeArmyPower(attackerArmy, false, state);
  let coastalSupportPct = 0;
  if (supportingFleet) {
    const fPower = computeFleetPower(supportingFleet, false, state);
    if (fPower > 0) {
      coastalSupportPct = Math.min(40, Math.round(12 + Math.sqrt(fPower) * 0.8));
      attackerPower *= 1 + coastalSupportPct / 100;
    }
  }

  const defCalc = computeTerritoryDefenseMultiplier(target, attackerArmy.units, origin, state);

  // Defender army power + local garrison
  const defArmies = Object.values(state.armies).filter(
    (a) => a.territoryId === targetTerritoryId && a.nationId === target.ownerId && !a.embarkedFleetId
  );
  let baseDefPower = target.ownerId ? 24 : target.wildernessGarrison * 1.15;
  for (const da of defArmies) {
    baseDefPower += computeArmyPower(da, true, state);
  }
  if (target.ownerId && state.nations[target.ownerId]) {
    const dNation = state.nations[target.ownerId];
    if (!dNation.isPlayer && dNation.aiDifficulty === 'easy') baseDefPower *= 0.72;
  }

  const defenderPower = Math.max(8, baseDefPower * defCalc.totalDefenseMult);
  const ratio = attackerPower / (attackerPower + defenderPower);
  const winProbability = Math.max(5, Math.min(98, Math.round(ratio * 100)));

  return {
    attackerPower: Math.round(attackerPower),
    defenderPower: Math.round(defenderPower),
    winProbability,
    terrainBonusPct: Math.round(defCalc.terrainBonus * 100),
    riverPenalty: defCalc.riverPenalty,
    coastalSupportPct,
  };
}

export function startLandOrAmphibiousBattle(
  state: GameState,
  army: Army,
  targetTerritoryId: string,
  supportingFleet?: Fleet | null
): ActiveBattle | null {
  const target = state.territories[targetTerritoryId];
  if (!target || target.isWater) return null;

  // Check if battle already underway there with same attacker
  const existing = Object.values(state.battles).find(
    (b) => b.territoryId === targetTerritoryId && b.attackerNationId === army.nationId
  );
  if (existing) {
    if (!existing.attackerArmyIds.includes(army.id)) {
      existing.attackerArmyIds.push(army.id);
      army.inBattleId = existing.id;
    }
    return existing;
  }

  const defArmies = Object.values(state.armies).filter(
    (a) => a.territoryId === targetTerritoryId && a.nationId === target.ownerId && !a.embarkedFleetId
  );

  // Ensure war is declared if attacking another nation
  if (target.ownerId && target.ownerId !== army.nationId) {
    const attN = state.nations[army.nationId];
    const defN = state.nations[target.ownerId];
    if (attN && defN) {
      if (!attN.relations[defN.id]) {
        attN.relations[defN.id] = {
          otherNationId: defN.id,
          score: -50,
          atWar: true,
          tradeAgreement: false,
          nonAggression: false,
          defensivePact: false,
          alliance: false,
          coalitionId: null,
          truceUntilTick: 0,
          lastActionTick: state.tick,
        };
      }
      if (!defN.relations[attN.id]) {
        defN.relations[attN.id] = {
          otherNationId: attN.id,
          score: -50,
          atWar: true,
          tradeAgreement: false,
          nonAggression: false,
          defensivePact: false,
          alliance: false,
          coalitionId: null,
          truceUntilTick: 0,
          lastActionTick: state.tick,
        };
      }
      if (!attN.relations[defN.id].atWar) {
        declareWar(state, attN.id, defN.id);
      }
    }
  }

  const odds = estimateCombatOdds(state, army, targetTerritoryId, supportingFleet);
  const origin = state.territories[army.territoryId] ?? null;
  const defCalc = computeTerritoryDefenseMultiplier(target, army.units, origin, state);

  const battleId = `battle_${state.nextEntitySeq++}`;
  const kind = supportingFleet ? 'amphibious' : 'land';

  const battle: ActiveBattle = {
    id: battleId,
    kind,
    territoryId: targetTerritoryId,
    attackerNationId: army.nationId,
    defenderNationId: target.ownerId,
    attackerArmyIds: [army.id],
    defenderArmyIds: defArmies.map((a) => a.id),
    attackerFleetIds: supportingFleet ? [supportingFleet.id] : [],
    defenderFleetIds: [],
    attackerInitialPower: Math.max(10, odds.attackerPower),
    defenderInitialPower: Math.max(10, odds.defenderPower),
    attackerCurrentPower: Math.max(10, odds.attackerPower),
    defenderCurrentPower: Math.max(10, odds.defenderPower),
    attackerCasualties: 0,
    defenderCasualties: 0,
    terrainModifier: Number(defCalc.totalDefenseMult.toFixed(2)),
    riverPenaltyApplied: defCalc.riverPenalty,
    coastalSupportBonus: odds.coastalSupportPct,
    progress: 50,
    startedAtTick: state.tick,
    log: [
      `${kind === 'amphibious' ? 'Amphibious assault' : 'Land battle'} begins for ${target.name} (${TERRAINS[target.terrain].name}, +${odds.terrainBonusPct}% defense${defCalc.riverPenalty ? ', River Crossing penalty' : ''}).`,
    ],
  };

  army.inBattleId = battleId;
  army.targetTerritoryId = null;
  army.path = [];
  for (const da of defArmies) {
    da.inBattleId = battleId;
  }

  state.battles[battleId] = battle;
  return battle;
}

export function startNavalBattle(state: GameState, attackerFleet: Fleet, defenderFleet: Fleet): ActiveBattle {
  const battleId = `battle_${state.nextEntitySeq++}`;
  const attPow = Math.max(12, computeFleetPower(attackerFleet, false, state));
  const defPow = Math.max(12, computeFleetPower(defenderFleet, true, state));
  const terr = state.territories[defenderFleet.territoryId];

  const battle: ActiveBattle = {
    id: battleId,
    kind: 'naval',
    territoryId: defenderFleet.territoryId,
    attackerNationId: attackerFleet.nationId,
    defenderNationId: defenderFleet.nationId,
    attackerArmyIds: [],
    defenderArmyIds: [],
    attackerFleetIds: [attackerFleet.id],
    defenderFleetIds: [defenderFleet.id],
    attackerInitialPower: attPow,
    defenderInitialPower: defPow,
    attackerCurrentPower: attPow,
    defenderCurrentPower: defPow,
    attackerCasualties: 0,
    defenderCasualties: 0,
    terrainModifier: terr?.weatherStorm ? 1.25 : 1.0,
    riverPenaltyApplied: false,
    coastalSupportBonus: 0,
    progress: 50,
    startedAtTick: state.tick,
    log: [`Naval engagement erupted in ${terr?.name ?? 'open waters'}!`],
  };

  attackerFleet.inBattleId = battleId;
  defenderFleet.inBattleId = battleId;
  state.battles[battleId] = battle;
  return battle;
}

export function declareWar(state: GameState, aggressorId: string, defenderId: string): void {
  const agg = state.nations[aggressorId];
  const def = state.nations[defenderId];
  if (!agg || !def || aggressorId === defenderId || def.eliminated) return;

  const r1 = agg.relations[defenderId];
  const r2 = def.relations[aggressorId];
  if (r1) {
    r1.atWar = true;
    r1.tradeAgreement = false;
    r1.nonAggression = false;
    r1.defensivePact = false;
    r1.alliance = false;
    r1.score = Math.max(-100, r1.score - 55);
  }
  if (r2) {
    r2.atWar = true;
    r2.tradeAgreement = false;
    r2.nonAggression = false;
    r2.defensivePact = false;
    r2.alliance = false;
    r2.score = Math.max(-100, r2.score - 70);
  }

  state.timeline.unshift({
    id: `tl_${state.nextEntitySeq++}`,
    tick: state.tick,
    yearLabel: formatYear(state.year),
    category: 'war',
    title: 'War Declared',
    description: `${agg.name} declared war upon ${def.name}!`,
    nationId: aggressorId,
  });

  if (aggressorId === state.playerNationId || defenderId === state.playerNationId) {
    state.notifications.unshift({
      id: `notif_${state.nextEntitySeq++}`,
      tick: state.tick,
      severity: 'danger',
      title: 'State of War',
      message: `${agg.name} and ${def.name} are now at war.`,
    });
  }
}

function applyCasualtiesToStacks(stacks: UnitStack[], damageFraction: number): number {
  let lostCount = 0;
  for (const st of stacks) {
    if (st.count <= 0) continue;
    const hpHit = damageFraction * 100;
    st.hp -= hpHit;
    st.experience = Math.min(100, st.experience + 3);
    while (st.hp <= 0 && st.count > 0) {
      st.count -= 1;
      lostCount += 1;
      st.hp += 100;
    }
    if (st.count <= 0) st.hp = 0;
  }
  return lostCount;
}

export function transferTerritoryOwnership(
  state: GameState,
  territoryId: string,
  newOwnerId: string
): void {
  const territory = state.territories[territoryId];
  const newOwner = state.nations[newOwnerId];
  if (!territory || !newOwner || territory.isWater) return;

  const oldOwnerId = territory.ownerId;
  territory.ownerId = newOwnerId;
  territory.wildernessGarrison = 0;
  territory.blockadedByNationId = null;
  territory.occupationUnrest = oldOwnerId ? 38 : 10;

  if (territory.cityId && state.cities[territory.cityId]) {
    const city = state.cities[territory.cityId];
    city.nationId = newOwnerId;
    city.isCapital = false;
  }

  newOwner.stats.territoriesConquered += 1;

  // Check if oldOwner has any remaining land territories -> Nation Elimination!
  if (oldOwnerId && state.nations[oldOwnerId] && !state.nations[oldOwnerId].eliminated) {
    const oldNation = state.nations[oldOwnerId];
    const remaining = state.territoryIds.filter(
      (id) => !state.territories[id].isWater && state.territories[id].ownerId === oldOwnerId
    );
    if (remaining.length === 0) {
      oldNation.eliminated = true;
      newOwner.stats.nationsEliminated += 1;
      // Transfer treasury & remaining assets
      newOwner.resources.gold += Math.round(oldNation.resources.gold * 0.75);
      newOwner.resources.food += Math.round(oldNation.resources.food * 0.5);
      newOwner.resources.wood += Math.round(oldNation.resources.wood * 0.5);
      newOwner.resources.iron += Math.round(oldNation.resources.iron * 0.5);
      oldNation.resources.gold = 0;

      // Remove defeated stray armies/fleets
      for (const aid of Object.keys(state.armies)) {
        if (state.armies[aid].nationId === oldOwnerId) delete state.armies[aid];
      }
      for (const fid of Object.keys(state.fleets)) {
        if (state.fleets[fid].nationId === oldOwnerId) delete state.fleets[fid];
      }

      state.timeline.unshift({
        id: `tl_${state.nextEntitySeq++}`,
        tick: state.tick,
        yearLabel: formatYear(state.year),
        category: 'conquest',
        title: `${oldNation.name} Eliminated`,
        description: `${newOwner.name} conquered the final stronghold of ${oldNation.name} and absorbed its assets.`,
        nationId: newOwnerId,
      });

      state.notifications.unshift({
        id: `notif_${state.nextEntitySeq++}`,
        tick: state.tick,
        severity: newOwnerId === state.playerNationId ? 'success' : 'warning',
        title: 'Civilization Eliminated!',
        message: `${oldNation.name} has fallen completely to ${newOwner.name}!`,
        territoryId,
      });
    } else if (oldNation.capitalTerritoryId === territoryId) {
      // Relocate capital to largest remaining territory
      const nextCap = remaining[0];
      oldNation.capitalTerritoryId = nextCap;
      if (state.territories[nextCap].cityId && state.cities[state.territories[nextCap].cityId!]) {
        state.cities[state.territories[nextCap].cityId!].isCapital = true;
      }
    }
  }
}

export function simulateBattles(state: GameState, dtSeconds: number): void {
  const finishedIds: string[] = [];

  for (const battle of Object.values(state.battles)) {
    const territory = state.territories[battle.territoryId];
    if (!territory) {
      finishedIds.push(battle.id);
      continue;
    }

    if (battle.kind === 'naval') {
      const attFleets = battle.attackerFleetIds.map((id) => state.fleets[id]).filter(Boolean);
      const defFleets = battle.defenderFleetIds.map((id) => state.fleets[id]).filter(Boolean);
      const attPower = attFleets.reduce((s, f) => s + computeFleetPower(f, false, state), 0);
      const defPower = defFleets.reduce((s, f) => s + computeFleetPower(f, true, state), 0);

      battle.attackerCurrentPower = Math.round(attPower);
      battle.defenderCurrentPower = Math.round(defPower);

      if (attPower <= 1 || defPower <= 1) {
        const attackerWon = defPower <= 1 && attPower > 1;
        finalizeBattle(state, battle, attackerWon);
        finishedIds.push(battle.id);
        continue;
      }

      const dmgToDef = (attPower / (attPower + defPower)) * dtSeconds * 0.24;
      const dmgToAtt = (defPower / (attPower + defPower)) * dtSeconds * 0.24;
      for (const f of defFleets) battle.defenderCasualties += applyCasualtiesToStacks(f.ships, dmgToDef);
      for (const f of attFleets) battle.attackerCasualties += applyCasualtiesToStacks(f.ships, dmgToAtt);

      const ratio = attPower / (attPower + defPower);
      battle.progress = Math.max(2, Math.min(98, Math.round(battle.progress + (ratio - 0.5) * dtSeconds * 32)));
      if (battle.progress >= 96 || defFleets.every((f) => f.ships.every((s) => s.count <= 0))) {
        finalizeBattle(state, battle, true);
        finishedIds.push(battle.id);
      } else if (battle.progress <= 4 || attFleets.every((f) => f.ships.every((s) => s.count <= 0))) {
        finalizeBattle(state, battle, false);
        finishedIds.push(battle.id);
      }
      continue;
    }

    // Land or Amphibious battle
    const attArmies = battle.attackerArmyIds.map((id) => state.armies[id]).filter(Boolean);
    const defArmies = battle.defenderArmyIds.map((id) => state.armies[id]).filter(Boolean);

    let attPower = attArmies.reduce((s, a) => s + computeArmyPower(a, false, state), 0);
    if (battle.coastalSupportBonus > 0) attPower *= 1 + battle.coastalSupportBonus / 100;

    let defBase = battle.defenderNationId ? 18 : Math.max(0, territory.wildernessGarrison);
    for (const da of defArmies) defBase += computeArmyPower(da, true, state);
    const defPower = defBase * battle.terrainModifier;

    battle.attackerCurrentPower = Math.round(attPower);
    battle.defenderCurrentPower = Math.round(defPower);

    if (attPower <= 1) {
      finalizeBattle(state, battle, false);
      finishedIds.push(battle.id);
      continue;
    }
    if (defPower <= 2) {
      finalizeBattle(state, battle, true);
      finishedIds.push(battle.id);
      continue;
    }

    const total = attPower + defPower;
    const attShare = attPower / total;
    const defShare = defPower / total;

    const dmgToDef = attShare * dtSeconds * 0.28;
    const dmgToAtt = defShare * dtSeconds * 0.22;

    if (!battle.defenderNationId) {
      const prevGar = territory.wildernessGarrison;
      territory.wildernessGarrison = Math.max(0, territory.wildernessGarrison - Math.max(2, attShare * dtSeconds * 24));
      battle.defenderCasualties += Math.max(0, Math.round(prevGar - territory.wildernessGarrison));
    } else {
      for (const da of defArmies) {
        battle.defenderCasualties += applyCasualtiesToStacks(da.units, dmgToDef);
      }
    }

    for (const aa of attArmies) {
      battle.attackerCasualties += applyCasualtiesToStacks(aa.units, dmgToAtt);
    }

    battle.progress = Math.max(0, Math.min(100, Math.round(battle.progress + (attShare - 0.45) * dtSeconds * 28)));

    const defendersBroken =
      (!battle.defenderNationId && territory.wildernessGarrison <= 1) ||
      (battle.defenderNationId !== null && defArmies.every((a) => getArmyTotalUnitCount(a) <= 0) && battle.progress >= 72) ||
      battle.progress >= 98;

    const attackersBroken = attArmies.every((a) => getArmyTotalUnitCount(a) <= 0) || battle.progress <= 3;

    if (defendersBroken) {
      finalizeBattle(state, battle, true);
      finishedIds.push(battle.id);
    } else if (attackersBroken) {
      finalizeBattle(state, battle, false);
      finishedIds.push(battle.id);
    }
  }

  for (const bid of finishedIds) {
    delete state.battles[bid];
  }
}

function finalizeBattle(state: GameState, battle: ActiveBattle, attackerWon: boolean): void {
  const territory = state.territories[battle.territoryId];
  const attNation = state.nations[battle.attackerNationId];
  const defNation = battle.defenderNationId ? state.nations[battle.defenderNationId] : null;

  // Release armies/fleets from battle lock
  for (const aid of battle.attackerArmyIds) {
    const a = state.armies[aid];
    if (!a) continue;
    a.inBattleId = null;
    if (getArmyTotalUnitCount(a) <= 0) {
      delete state.armies[aid];
    } else if (attackerWon) {
      // Disembark if amphibious & march into conquered territory
      if (a.embarkedFleetId && state.fleets[a.embarkedFleetId]) {
        const fl = state.fleets[a.embarkedFleetId];
        fl.carriedArmyIds = fl.carriedArmyIds.filter((id) => id !== a.id);
        a.embarkedFleetId = null;
      }
      a.territoryId = battle.territoryId;
      a.targetTerritoryId = null;
      a.path = [];
      a.moveProgress = 0;
    }
  }

  for (const aid of battle.defenderArmyIds) {
    const a = state.armies[aid];
    if (!a) continue;
    a.inBattleId = null;
    if (getArmyTotalUnitCount(a) <= 0 || attackerWon) {
      delete state.armies[aid];
    }
  }

  for (const fid of [...battle.attackerFleetIds, ...battle.defenderFleetIds]) {
    const f = state.fleets[fid];
    if (!f) continue;
    f.inBattleId = null;
    if (f.ships.every((s) => s.count <= 0)) {
      delete state.fleets[fid];
    }
  }

  if (attackerWon) {
    if (attNation) attNation.stats.totalBattlesWon += 1;
    if (defNation) defNation.stats.totalBattlesLost += 1;

    if (battle.kind !== 'naval' && territory && attNation) {
      transferTerritoryOwnership(state, territory.id, attNation.id);
    }

    if (battle.attackerNationId === state.playerNationId || battle.defenderNationId === state.playerNationId) {
      state.notifications.unshift({
        id: `notif_${state.nextEntitySeq++}`,
        tick: state.tick,
        severity: battle.attackerNationId === state.playerNationId ? 'success' : 'danger',
        title: battle.kind === 'naval' ? 'Naval Victory' : `${territory?.name ?? 'Territory'} Captured!`,
        message: `${attNation?.name ?? 'Attacker'} won the ${battle.kind} battle for ${territory?.name ?? 'sector'}.`,
        territoryId: territory?.id,
      });
    }
  } else {
    if (attNation) attNation.stats.totalBattlesLost += 1;
    if (defNation) defNation.stats.totalBattlesWon += 1;

    if (battle.attackerNationId === state.playerNationId || battle.defenderNationId === state.playerNationId) {
      state.notifications.unshift({
        id: `notif_${state.nextEntitySeq++}`,
        tick: state.tick,
        severity: battle.defenderNationId === state.playerNationId ? 'success' : 'warning',
        title: battle.defenderNationId === state.playerNationId ? 'Defense Held!' : 'Assault Repulsed',
        message: `Defenders held ${territory?.name ?? 'the sector'} against ${attNation?.name ?? 'attackers'}.`,
        territoryId: territory?.id,
      });
    }
  }
}
