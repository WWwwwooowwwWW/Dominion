import { BUILDING_BY_ID } from '../data/buildings';
import { TECH_BY_ID } from '../data/technologies';
import { GameState, Nation, ResourceKey, TechDefinition } from '../types/game';
import { ALL_RESOURCE_KEYS } from './economy';

export interface TechRequirementStatus {
  alreadyUnlocked: boolean;
  alreadyFunded: boolean;
  missingPrereqs: string[];
  missingBuilding: string | null;
  missingResources: Array<{ key: ResourceKey; need: number; have: number }>;
  canStart: boolean;
  effectiveSciCost: number;
  complexityMult: number;
}

export function getTechComplexityMultiplier(nation: Nation): number {
  return Number((1 + nation.unlockedTechs.length * 0.028).toFixed(3));
}

export function getEffectiveTechCost(tech: TechDefinition, nation: Nation): number {
  return Math.round(tech.cost * getTechComplexityMultiplier(nation));
}

export function getTechRequirementsStatus(
  state: GameState,
  nation: Nation,
  tech: TechDefinition
): TechRequirementStatus {
  const alreadyUnlocked = nation.unlockedTechs.includes(tech.id);
  const alreadyFunded = (nation.techFundedIds ?? []).includes(tech.id);
  const missingPrereqs = tech.prerequisites.filter((p) => !nation.unlockedTechs.includes(p));

  let missingBuilding: string | null = null;
  if (tech.requiredBuilding) {
    const hasBuilding = Object.values(state.cities).some(
      (c) =>
        c.nationId === nation.id &&
        c.buildings.some((b) => b.buildingId === tech.requiredBuilding)
    );
    if (!hasBuilding) {
      missingBuilding = tech.requiredBuilding;
    }
  }

  const missingResources: Array<{ key: ResourceKey; need: number; have: number }> = [];
  if (!alreadyFunded && tech.resourceCost) {
    for (const key of ALL_RESOURCE_KEYS) {
      const need = tech.resourceCost[key] ?? 0;
      if (need > 0 && nation.resources[key] < need) {
        missingResources.push({
          key,
          need,
          have: Math.floor(nation.resources[key]),
        });
      }
    }
  }

  const complexityMult = getTechComplexityMultiplier(nation);
  const effectiveSciCost = getEffectiveTechCost(tech, nation);
  const canStart =
    !alreadyUnlocked &&
    missingPrereqs.length === 0 &&
    !missingBuilding &&
    missingResources.length === 0;

  return {
    alreadyUnlocked,
    alreadyFunded,
    missingPrereqs,
    missingBuilding,
    missingResources,
    canStart,
    effectiveSciCost,
    complexityMult,
  };
}

export function formatTechBlockReason(status: TechRequirementStatus): string {
  if (status.alreadyUnlocked) return 'Already researched.';
  if (status.missingPrereqs.length > 0) {
    const names = status.missingPrereqs.map((id) => TECH_BY_ID[id]?.name ?? id).join(', ');
    return `Requires prerequisite tech: ${names}.`;
  }
  if (status.missingBuilding) {
    const bName = BUILDING_BY_ID[status.missingBuilding]?.name ?? status.missingBuilding;
    return `Requires ${bName} built in at least one city.`;
  }
  if (status.missingResources.length > 0) {
    const needed = status.missingResources
      .map((r) => `${r.need} ${r.key.charAt(0).toUpperCase() + r.key.slice(1)}`)
      .join(', ');
    return `Insufficient research resources (need ${needed}).`;
  }
  return '';
}
