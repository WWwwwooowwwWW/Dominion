import { BUILDING_BY_ID } from '../data/buildings';
import { TECHNOLOGIES } from '../data/technologies';
import { UNIT_BY_ID, UNITS } from '../data/units';
import { City, GameState, Nation } from '../types/game';
import { computeArmyPower, declareWar, estimateCombatOdds, startLandOrAmphibiousBattle } from './combat';
import { canAfford, spendResources } from './economy';
import { findNavalPath } from './pathfinding';
import { getTechRequirementsStatus } from './tech';

export function simulateAICivilizations(state: GameState): void {
  for (const nation of Object.values(state.nations)) {
    if (nation.isPlayer || nation.isHumanMultiplayer || nation.eliminated) continue;
    if (state.tick < nation.aiCooldownTick) continue;

    // Cooldown pacing by difficulty (Easy is intentionally relaxed!)
    const baseDelay =
      nation.aiDifficulty === 'easy' ? 22 : nation.aiDifficulty === 'hard' ? 8 : 14;
    nation.aiCooldownTick = state.tick + baseDelay + (nation.id.charCodeAt(nation.id.length - 1) % 5);

    // 1. Auto-select technology if idle (respecting resource & building requirements)
    if (!nation.currentTechId) {
      const available = TECHNOLOGIES.filter(
        (t) => getTechRequirementsStatus(state, nation, t).canStart
      );
      if (available.length > 0) {
        const chosen = available[0];
        if (!nation.techFundedIds) nation.techFundedIds = [];
        if (!nation.techProgressById) nation.techProgressById = {};
        if (!nation.techFundedIds.includes(chosen.id) && chosen.resourceCost) {
          spendResources(nation, chosen.resourceCost);
          nation.techFundedIds.push(chosen.id);
        }
        nation.currentTechId = chosen.id;
        nation.techProgress = nation.techProgressById[chosen.id] ?? 0;
      }
    }

    const ownedTerritories = state.territoryIds
      .map((id) => state.territories[id])
      .filter((t) => !t.isWater && t.ownerId === nation.id);

    if (ownedTerritories.length === 0) continue;

    const myArmies = Object.values(state.armies).filter(
      (a) => a.nationId === nation.id && !a.inBattleId && !a.embarkedFleetId
    );
    const myCities = Object.values(state.cities).filter((c) => c.nationId === nation.id);

    // 2. Construct basic & research buildings (Economic/Agricultural/Scientific/Military)
    if (myCities.length > 0 && (nation.aiDifficulty !== 'easy' || Math.random() < 0.35)) {
      const city = myCities[Math.floor(Math.random() * myCities.length)];
      if (city.queue.length === 0) {
        const terr = state.territories[city.territoryId];
        const candidateIds = [
          'farms',
          'lumber_mills',
          'mines',
          'libraries',
          'trading_posts',
          'barracks',
          'houses',
          'universities',
          'research_laboratories',
          'power_stations',
          'factories',
          'oil_refineries',
          'advanced_research_centers',
          'ports',
        ];
        for (const bid of candidateIds) {
          const def = BUILDING_BY_ID[bid];
          if (!def) continue;
          if (def.coastalOnly && !terr.isCoastal) continue;
          if (def.requiredTech && !nation.unlockedTechs.includes(def.requiredTech)) continue;
          const existing = city.buildings.find((b) => b.buildingId === bid);
          if (existing && existing.level >= 2) continue;
          if (canAfford(nation, def.cost)) {
            spendResources(nation, def.cost);
            city.queue.push({
              id: `con_${state.nextEntitySeq++}`,
              cityId: city.id,
              territoryId: city.territoryId,
              buildingId: bid,
              targetLevel: existing ? existing.level + 1 : 1,
              progress: 0,
              totalTime: def.buildTime,
            });
            break;
          }
        }
      }
    }

    // 3. Recruit troops (keeping armies reasonably small & manageable per prompt)
    const maxArmiesTarget =
      nation.aiDifficulty === 'easy'
        ? Math.min(2, Math.max(1, Math.floor(ownedTerritories.length / 3)))
        : nation.aiDifficulty === 'hard'
          ? Math.min(5, Math.max(2, Math.floor(ownedTerritories.length / 2)))
          : Math.min(3, Math.max(1, Math.floor(ownedTerritories.length / 2)));

    const totalUnits = myArmies.reduce((s, a) => s + a.units.reduce((x, u) => x + u.count, 0), 0);
    const unitCap =
      nation.aiDifficulty === 'easy' ? 10 : nation.aiDifficulty === 'hard' ? 28 : 17;

    if (totalUnits < unitCap && myCities.length > 0) {
      const spawnCity = myCities[0];
      const unlockedLand = UNITS.filter(
        (u) =>
          u.domain === 'land' &&
          (!u.requiredTech || nation.unlockedTechs.includes(u.requiredTech))
      );
      const bestUnit = unlockedLand[Math.max(0, unlockedLand.length - 1)];
      if (bestUnit && canAfford(nation, bestUnit.cost)) {
        spendResources(nation, bestUnit.cost);
        const army = myArmies[0];
        if (army && myArmies.length >= maxArmiesTarget) {
          const stack = army.units.find((s) => s.unitId === bestUnit.id);
          if (stack) stack.count += 1;
          else army.units.push({ unitId: bestUnit.id, count: 1, hp: 100, experience: 5 });
        } else {
          const aid = `army_${state.nextEntitySeq++}`;
          state.armies[aid] = {
            id: aid,
            name: `${nation.adjective} Corps ${myArmies.length + 1}`,
            nationId: nation.id,
            territoryId: spawnCity.territoryId,
            targetTerritoryId: null,
            path: [],
            moveProgress: 0,
            units: [{ unitId: bestUnit.id, count: 2, hp: 100, experience: 5 }],
            supply: 100,
            morale: 88,
            fortified: false,
            embarkedFleetId: null,
            inBattleId: null,
          };
        }
      }
    }

    // 4. Build modest naval ships if coastal & Navigation unlocked (Normal/Hard)
    if (nation.unlockedTechs.includes('navigation') && nation.aiDifficulty !== 'easy') {
      const coastalCity = myCities.find((c) => state.territories[c.territoryId]?.isCoastal);
      const myFleets = Object.values(state.fleets).filter((f) => f.nationId === nation.id);
      if (coastalCity && myFleets.length < 1) {
        const shipDef = UNIT_BY_ID['war_galleys'];
        if (shipDef && canAfford(nation, shipDef.cost)) {
          spendResources(nation, shipDef.cost);
          const fid = `fleet_${state.nextEntitySeq++}`;
          state.fleets[fid] = {
            id: fid,
            name: `${nation.adjective} Squadron`,
            nationId: nation.id,
            territoryId: coastalCity.territoryId,
            targetTerritoryId: null,
            path: [],
            moveProgress: 0,
            ships: [{ unitId: 'war_galleys', count: 2, hp: 100, experience: 10 }],
            supply: 100,
            morale: 85,
            mission: 'patrol',
            carriedArmyIds: [],
            inBattleId: null,
          };
        }
      }
    }

    // 5. Simple Expansion & Skirmishing (Frontwars-style)
    const expandChance =
      nation.aiDifficulty === 'easy'
        ? 0.28
        : nation.aiDifficulty === 'hard'
          ? 0.72
          : 0.48;

    if (myArmies.length > 0 && Math.random() < expandChance) {
      const activeArmy = myArmies.find((a) => !a.targetTerritoryId && computeArmyPower(a, false, state) > 25);
      if (activeArmy) {
        const curT = state.territories[activeArmy.territoryId];
        // Look for adjacent wilderness from any owned territory
        const borderWilderness: Array<{ fromId: string; toId: string }> = [];
        const borderWeakEnemy: Array<{ fromId: string; toId: string }> = [];

        for (const ot of ownedTerritories) {
          for (const nid of ot.landNeighbors) {
            const nb = state.territories[nid];
            if (!nb.ownerId) {
              borderWilderness.push({ fromId: ot.id, toId: nid });
            } else if (nb.ownerId !== nation.id) {
              const rel = nation.relations[nb.ownerId];
              if (rel?.atWar || (nation.aiPersonality === 'aggressive' && !rel?.alliance && !rel?.nonAggression && nation.aiDifficulty !== 'easy')) {
                borderWeakEnemy.push({ fromId: ot.id, toId: nid });
              }
            }
          }
        }

        const preferWilderness = nation.aiPersonality !== 'aggressive' || borderWilderness.length > 0;
        if (preferWilderness && borderWilderness.length > 0 && nation.aiPersonality !== 'defensive') {
          const pick = borderWilderness[Math.floor(Math.random() * borderWilderness.length)];
          const odds = estimateCombatOdds(state, activeArmy, pick.toId);
          if (odds.winProbability >= 52) {
            if (activeArmy.territoryId === pick.fromId) {
              startLandOrAmphibiousBattle(state, activeArmy, pick.toId);
            } else {
              activeArmy.targetTerritoryId = pick.fromId;
            }
          }
        } else if (borderWeakEnemy.length > 0 && nation.aiPersonality !== 'passive') {
          const pick = borderWeakEnemy[Math.floor(Math.random() * borderWeakEnemy.length)];
          const targetOwner = state.territories[pick.toId].ownerId;
          const odds = estimateCombatOdds(state, activeArmy, pick.toId);
          // Only declare war/attack if odds look decent and not blocked by truce
          const rel = targetOwner ? nation.relations[targetOwner] : null;
          if (odds.winProbability >= 56 && (!rel || state.tick >= rel.truceUntilTick)) {
            if (targetOwner && rel && !rel.atWar) {
              declareWar(state, nation.id, targetOwner);
            }
            if (activeArmy.territoryId === pick.fromId) {
              startLandOrAmphibiousBattle(state, activeArmy, pick.toId);
            } else {
              activeArmy.targetTerritoryId = pick.fromId;
            }
          }
        }
      }
    }

    // 6. Simple AI Diplomacy (Peace when losing, occasional Trade Pact)
    for (const rel of Object.values(nation.relations)) {
      const other = state.nations[rel.otherNationId];
      if (!other || other.eliminated) continue;
      if (rel.atWar && ownedTerritories.length <= 2 && Math.random() < 0.15) {
        // AI concedes truce if losing
        rel.atWar = false;
        rel.truceUntilTick = state.tick + 120;
        if (other.relations[nation.id]) {
          other.relations[nation.id].atWar = false;
          other.relations[nation.id].truceUntilTick = state.tick + 120;
        }
        if (other.isPlayer) {
          state.notifications.unshift({
            id: `notif_${state.nextEntitySeq++}`,
            tick: state.tick,
            severity: 'info',
            title: 'Peace Armistice Signed',
            message: `${nation.name} agreed to cease hostilities and signed a temporary truce.`,
          });
        }
      } else if (!rel.atWar && !rel.tradeAgreement && rel.score > 10 && Math.random() < 0.04) {
        if (!other.isPlayer) {
          rel.tradeAgreement = true;
          if (other.relations[nation.id]) other.relations[nation.id].tradeAgreement = true;
        }
      }
    }

    // Move idle patrol fleets through sea lanes
    const myFleets = Object.values(state.fleets).filter(
      (f) => f.nationId === nation.id && !f.inBattleId && !f.targetTerritoryId && f.path.length === 0
    );
    for (const fl of myFleets) {
      const cur = state.territories[fl.territoryId];
      if (cur && cur.seaNeighbors.length > 0 && Math.random() < 0.35) {
        const seaTarget = cur.seaNeighbors[Math.floor(Math.random() * cur.seaNeighbors.length)];
        const path = findNavalPath(state, fl.territoryId, seaTarget);
        if (path && path.length > 1) {
          fl.path = path;
          fl.targetTerritoryId = seaTarget;
        }
      }
    }
  }
}

export function foundNewCityOnTerritory(state: GameState, nationId: string, territoryId: string): City | null {
  const terr = state.territories[territoryId];
  const nation = state.nations[nationId];
  if (!terr || !nation || terr.isWater || terr.ownerId !== nationId || terr.cityId) return null;

  const cityId = `city_${state.nextEntitySeq++}`;
  const cleanName = terr.name.replace(/\s+(Plains|Meadows|Woods|Highlands|Peaks|Dunes|Tundra|Glacier)$/i, '');
  const city: City = {
    id: cityId,
    name: cleanName || terr.name,
    territoryId,
    nationId,
    isCapital: false,
    tier: 1,
    population: 1200,
    housing: 3000,
    foodProduction: 16,
    industrialOutput: 8,
    economicOutput: 14,
    happiness: 75,
    health: 75,
    education: 35,
    infrastructure: 20,
    security: 65,
    unemploymentRate: 5,
    birthRate: 22,
    deathRate: 10,
    diseaseOutbreak: false,
    buildings: [{ buildingId: 'houses', level: 1 }],
    queue: [],
    occupations: {
      farmers: 420,
      miners: 160,
      builders: 150,
      researchers: 100,
      merchants: 110,
      factory_workers: 0,
      government_workers: 60,
      soldiers: 100,
    },
  };
  state.cities[cityId] = city;
  terr.cityId = cityId;
  return city;
}
