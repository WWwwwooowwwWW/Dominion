import { BUILDING_BY_ID } from '../data/buildings';
import { GOVERNMENTS, POLICY_BY_ID } from '../data/governments';
import { TECH_BY_ID } from '../data/technologies';
import { City, GameState, OccupationKey } from '../types/game';

const OCC_KEYS: OccupationKey[] = [
  'farmers',
  'miners',
  'builders',
  'researchers',
  'merchants',
  'factory_workers',
  'government_workers',
  'soldiers',
];

export function rebalanceCityOccupations(city: City): void {
  const totalAssigned = OCC_KEYS.reduce((s, k) => s + city.occupations[k], 0);
  if (totalAssigned === 0 || city.population <= 0) return;
  const targetWorkforce = Math.max(0, Math.round(city.population * 0.92));
  if (Math.abs(totalAssigned - targetWorkforce) < 10) return;
  const scale = targetWorkforce / totalAssigned;
  for (const k of OCC_KEYS) {
    city.occupations[k] = Math.max(0, Math.round(city.occupations[k] * scale));
  }
}

export function simulateCitiesAndPopulation(state: GameState, dtSeconds: number): void {
  const cities = Object.values(state.cities);
  const nationHappinessTotals: Record<string, { sum: number; count: number }> = {};

  for (const city of cities) {
    const nation = state.nations[city.nationId];
    const territory = state.territories[city.territoryId];
    if (!nation || !territory || nation.eliminated) continue;

    // 1. Compute Housing, Health, Security, Infrastructure & Job Slots from Buildings
    let housing = 3000 + city.tier * 1200;
    let health = 55 + (nation.budget.healthcareFunding - 50) * 0.35;
    let security = 50 + (nation.budget.militarySpending - 50) * 0.25;
    let infra = 15 + (nation.budget.infrastructureSpending - 50) * 0.2;
    let happiness = 72 + GOVERNMENTS[nation.government].modifiers.happinessMod - (nation.budget.taxRate - 15) * 0.9;
    let totalJobSlots = 1600 + city.tier * 600;

    for (const pid of nation.activePolicies) {
      const pol = POLICY_BY_ID[pid];
      if (!pol) continue;
      happiness += pol.effects.happinessMod ?? 0;
      health += pol.effects.healthMod ?? 0;
    }

    for (const tid of nation.unlockedTechs) {
      const tech = TECH_BY_ID[tid];
      if (tech?.bonuses?.healthMod) health += tech.bonuses.healthMod * 40;
    }

    let hasBridgeBuilding = false;
    let maxFort = 0;

    for (const b of city.buildings) {
      const def = BUILDING_BY_ID[b.buildingId];
      if (!def) continue;
      housing += (def.effects.housing ?? 0) * b.level;
      health += (def.effects.health ?? 0) * b.level;
      security += (def.effects.security ?? 0) * b.level;
      infra += (def.effects.infrastructure ?? 0) * b.level;
      happiness += (def.effects.happiness ?? 0) * b.level;
      if (def.effects.negatesRiverPenalty) hasBridgeBuilding = true;
      if (b.buildingId === 'fortresses') maxFort = Math.max(maxFort, b.level);

      if (def.effects.jobSlots) {
        for (const k of OCC_KEYS) {
          totalJobSlots += (def.effects.jobSlots[k] ?? 0) * b.level;
        }
      }
    }

    territory.hasBridge = hasBridgeBuilding;
    territory.fortLevel = maxFort;
    territory.occupationUnrest = Math.max(0, territory.occupationUnrest - dtSeconds * 0.45);

    // Overcrowding & Food shortage effects
    const overcrowdingRatio = city.population / Math.max(1000, housing);
    if (overcrowdingRatio > 1.0) {
      const overPct = (overcrowdingRatio - 1) * 40;
      happiness -= overPct;
      health -= overPct * 0.6;
    }

    const foodDeficit = nation.resources.food <= 5 && nation.ratesPerMin.food < 0;
    if (foodDeficit) {
      happiness -= 22;
      health -= 18;
    }

    if (territory.occupationUnrest > 0) {
      happiness -= territory.occupationUnrest * 0.3;
    }

    if (city.diseaseOutbreak) {
      health -= 24;
      happiness -= 12;
      // Chance to recover faster if health infrastructure is high
      if (health > 65 && Math.random() < dtSeconds * 0.04) {
        city.diseaseOutbreak = false;
      }
    }

    city.housing = Math.round(Math.min(territory.populationCapacity * 2.5, housing));
    city.health = Math.max(5, Math.min(100, Math.round(health)));
    city.security = Math.max(5, Math.min(100, Math.round(security)));
    city.infrastructure = Math.max(5, Math.min(100, Math.round(infra)));
    city.happiness = Math.max(5, Math.min(100, Math.round(happiness)));
    city.education = Math.min(100, Math.round(30 + nation.unlockedTechs.length * 1.4 + nation.budget.educationFunding * 0.25));

    const workforce = city.population * 0.92;
    const unemployment = workforce > totalJobSlots ? ((workforce - totalJobSlots) / workforce) * 100 : 0;
    city.unemploymentRate = Math.max(0, Math.min(85, Math.round(unemployment)));
    if (city.unemploymentRate > 18) {
      city.happiness = Math.max(5, city.happiness - Math.round((city.unemploymentRate - 18) * 0.35));
    }

    // 2. Birth & Death Rates -> Natural Growth
    let growthMult = 1.0;
    for (const pid of nation.activePolicies) {
      growthMult += POLICY_BY_ID[pid]?.effects.growthMod ?? 0;
    }

    const birthRate = (14 + city.happiness * 0.14 + (foodDeficit ? -10 : 5)) * growthMult;
    const deathRate = 18 - city.health * 0.11 + (foodDeficit ? 18 : 0) + (city.diseaseOutbreak ? 14 : 0);
    city.birthRate = Math.max(4, Math.round(birthRate));
    city.deathRate = Math.max(4, Math.round(deathRate));

    const netRatePer1000 = (city.birthRate - city.deathRate) / 1000;
    const capPenalty = city.population >= city.housing ? 0.15 : 1.0;
    const popDelta = city.population * netRatePer1000 * (dtSeconds / 18) * capPenalty;
    city.population = Math.max(350, Math.round(city.population + popDelta));

    // City Tier auto-evolution based on population
    if (city.population >= 45000) city.tier = 5;
    else if (city.population >= 24000) city.tier = 4;
    else if (city.population >= 11000) city.tier = 3;
    else if (city.population >= 5000) city.tier = 2;
    else city.tier = 1;

    rebalanceCityOccupations(city);

    if (!nationHappinessTotals[nation.id]) {
      nationHappinessTotals[nation.id] = { sum: 0, count: 0 };
    }
    nationHappinessTotals[nation.id].sum += city.happiness;
    nationHappinessTotals[nation.id].count += 1;
  }

  for (const [nid, info] of Object.entries(nationHappinessTotals)) {
    if (state.nations[nid] && info.count > 0) {
      state.nations[nid].overallHappiness = Math.round(info.sum / info.count);
    }
  }
}
