import { formatYear } from '../data/eras';
import { TECH_BY_ID } from '../data/technologies';
import { GameState, PendingEvent } from '../types/game';
import { getEffectiveTechCost } from './tech';

export function simulateWeatherAndEvents(state: GameState): void {
  // Periodic ocean weather storms shifting every ~40 ticks
  if (state.tick % 40 === 0) {
    const seaIds = state.territoryIds.filter((id) => state.territories[id].isWater);
    for (const id of seaIds) {
      state.territories[id].weatherStorm = false;
    }
    const stormCount = Math.max(1, Math.floor(seaIds.length * 0.06));
    for (let i = 0; i < stormCount; i++) {
      const pick = seaIds[Math.floor(Math.random() * seaIds.length)];
      if (pick) state.territories[pick].weatherStorm = true;
    }
  }

  // Trigger a player world event roughly every ~95 ticks if none pending
  if (state.tick > 35 && state.tick % 95 === 0 && !state.pendingEvent && state.config.mode !== 'multiplayer') {
    const player = state.nations[state.playerNationId];
    if (!player || player.eliminated) return;

    const playerCities = Object.values(state.cities).filter((c) => c.nationId === player.id);
    const playerTerrs = state.territoryIds.filter(
      (id) => !state.territories[id].isWater && state.territories[id].ownerId === player.id
    );
    const targetTerrId = playerTerrs[Math.floor(Math.random() * playerTerrs.length)];
    const targetTerr = targetTerrId ? state.territories[targetTerrId] : null;
    const targetCity = playerCities[Math.floor(Math.random() * playerCities.length)];

    const kinds: PendingEvent['kind'][] = [
      'discovery',
      'breakthrough',
      'boom',
      'drought',
      'flood',
      'earthquake',
      'storm',
      'disease',
      'recession',
      'instability',
    ];
    const kind = kinds[Math.floor(Math.random() * kinds.length)];
    state.pendingEvent = buildEvent(state, kind, player.id, targetTerr?.id, targetCity?.name ?? targetTerr?.name ?? player.name);
  }
}

function buildEvent(
  state: GameState,
  kind: PendingEvent['kind'],
  nationId: string,
  territoryId: string | undefined,
  locationName: string
): PendingEvent {
  const id = `evt_${state.nextEntitySeq++}`;
  switch (kind) {
    case 'discovery':
      return {
        id,
        kind,
        title: `Mineral Vein Discovered in ${locationName}`,
        description: `Prospectors surveying ${locationName} uncovered rich subterranean mineral deposits.`,
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'extract',
            label: 'State Mining Charter',
            description: 'Fund immediate extraction equipment for permanent deposits.',
            costGold: 60,
            effectSummary: '+120 Iron, +80 Stone, adds rich deposit',
          },
          {
            id: 'auction',
            label: 'Auction Private Leases',
            description: 'Grant private concessions for immediate treasury revenue.',
            effectSummary: '+140 Gold',
          },
        ],
      };
    case 'breakthrough':
      return {
        id,
        kind,
        title: 'Scholars Achieve Breakthrough',
        description: 'Royal academies report unexpected theoretical advances.',
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'fund',
            label: 'Sponsor Research Publication',
            description: 'Accelerate your current technology research substantially.',
            costGold: 50,
            effectSummary: '+45% progress on current technology',
          },
          {
            id: 'archive',
            label: 'Record in Imperial Archives',
            description: 'Preserve findings for cultural prestige.',
            effectSummary: '+80 Culture, +50 Influence',
          },
        ],
      };
    case 'boom':
      return {
        id,
        kind,
        title: `Prosperity & Population Boom in ${locationName}`,
        description: 'Abundant harvests and peaceful commerce attract settlers across the region.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'welcome',
            label: 'Subsidize New Settlers',
            description: 'Expand civic infrastructure to welcome growing families.',
            costGold: 45,
            effectSummary: '+600 Population, +100 Food',
          },
          {
            id: 'tax',
            label: 'Levy Prosperity Tax',
            description: 'Collect modest revenue from thriving urban merchants.',
            effectSummary: '+110 Gold, +250 Population',
          },
        ],
      };
    case 'drought':
      return {
        id,
        kind,
        title: `Severe Drought Strikes ${locationName}`,
        description: 'Dry seasonal winds threaten grain harvests and rural stability.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'relief',
            label: 'Distribute Emergency Rations',
            description: 'Use treasury funds to import grain and prevent unrest.',
            costGold: 65,
            effectSummary: 'Prevents food & happiness loss',
          },
          {
            id: 'ration',
            label: 'Enforce Strict Rationing',
            description: 'Conserve state reserves while rural provinces endure hardship.',
            effectSummary: '-90 Food, +12 Unrest in region',
          },
        ],
      };
    case 'flood':
      return {
        id,
        kind,
        title: `River Floods in ${locationName}`,
        description: 'Swollen waters inundated riverbanks and damaged roadways.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'dikes',
            label: 'Construct Emergency Levees',
            description: 'Mobilize builders and stone to repair infrastructure.',
            costGold: 70,
            effectSummary: '+80 Food next harvest, restores stability',
          },
          {
            id: 'wait',
            label: 'Let Waters Recede',
            description: 'Accept temporary structural wear without spending gold.',
            effectSummary: '-60 Wood, -40 Stone',
          },
        ],
      };
    case 'earthquake':
      return {
        id,
        kind,
        title: `Earthquake Tremors in ${locationName}`,
        description: 'Tectonic tremors shook regional settlements and fortifications.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'rebuild',
            label: 'Imperial Reconstruction Aid',
            description: 'Send engineers and stone to rebuild immediately.',
            costGold: 80,
            effectSummary: 'Prevents unrest and boosts loyalty',
          },
          {
            id: 'local',
            label: 'Leave to Local Magistrates',
            description: 'Save imperial gold while reconstruction slows.',
            effectSummary: '+15 Unrest in affected province',
          },
        ],
      };
    case 'storm':
      return {
        id,
        kind,
        title: 'Violent Oceanic Gales',
        description: 'Hurricanes sweep across sea lanes, delaying naval transit and maritime trade.',
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'harbor',
            label: 'Issue Safe-Harbor Orders',
            description: 'Protect merchant vessels until the storms clear.',
            costGold: 35,
            effectSummary: 'Protects fleets from storm wear',
          },
          {
            id: 'sail',
            label: 'Press Through the Gale',
            description: 'Keep schedules running despite rough seas.',
            effectSummary: 'Minor supply wear on fleets',
          },
        ],
      };
    case 'disease':
      return {
        id,
        kind,
        title: `Outbreak Reported in ${locationName}`,
        description: 'Physicians warn of a contagious fever spreading through crowded quarters.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'quarantine',
            label: 'Quarantine & Medical Relief',
            description: 'Fund clinics and sanitation measures immediately.',
            costGold: 75,
            effectSummary: 'Contains outbreak rapidly',
          },
          {
            id: 'minimal',
            label: 'Keep Markets Open',
            description: 'Avoid economic shutdown, risking localized illness.',
            effectSummary: 'Disease outbreak in city until health recovers',
          },
        ],
      };
    case 'recession':
      return {
        id,
        kind,
        title: 'Global Trade Slowdown',
        description: 'Credit tightening across foreign markets temporarily depresses merchant margins.',
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'stimulus',
            label: 'Public Works Stimulus',
            description: 'Inject treasury reserves into domestic construction.',
            costGold: 85,
            effectSummary: '+120 Stone, +120 Wood, +10 Happiness',
          },
          {
            id: 'austerity',
            label: 'Fiscal Austerity',
            description: 'Weather the downturn cautiously.',
            effectSummary: '-80 Gold, +25 Influence',
          },
        ],
      };
    case 'instability':
    default:
      return {
        id,
        kind: 'instability',
        title: `Political Factionalism in ${locationName}`,
        description: 'Regional leaders demand greater autonomy or tax relief.',
        targetTerritoryId: territoryId,
        targetNationId: nationId,
        createdAtTick: state.tick,
        choices: [
          {
            id: 'concessions',
            label: 'Grant Civic Charter',
            description: 'Appease local councils with influence and modest concessions.',
            costGold: 50,
            effectSummary: 'Reduces unrest & boosts happiness',
          },
          {
            id: 'crackdown',
            label: 'Assert Imperial Authority',
            description: 'Deploy garrison troops to enforce order.',
            effectSummary: '+40 Influence, +12 Unrest',
          },
        ],
      };
  }
}

export function resolvePendingEventChoice(state: GameState, choiceId: string): void {
  const evt = state.pendingEvent;
  if (!evt) return;
  const nation = state.nations[evt.targetNationId];
  const terr = evt.targetTerritoryId ? state.territories[evt.targetTerritoryId] : null;
  const city = terr?.cityId ? state.cities[terr.cityId] : null;
  if (!nation) {
    state.pendingEvent = null;
    return;
  }

  const choice = evt.choices.find((c) => c.id === choiceId) ?? evt.choices[0];
  if (choice.costGold && nation.resources.gold >= choice.costGold) {
    nation.resources.gold -= choice.costGold;
  } else if (choice.costGold && nation.resources.gold < choice.costGold) {
    // Fallback to non-gold option if treasury depleted
    nation.resources.gold = Math.max(0, nation.resources.gold - choice.costGold);
  }

  switch (evt.kind) {
    case 'discovery':
      if (choice.id === 'extract') {
        nation.resources.iron += 120;
        nation.resources.stone += 80;
        if (terr && terr.deposits.length < 3) terr.deposits.push({ resource: 'iron', richness: 2 });
      } else {
        nation.resources.gold += 140;
      }
      break;
    case 'breakthrough':
      if (choice.id === 'fund' && nation.currentTechId) {
        const tech = TECH_BY_ID[nation.currentTechId];
        const boost = tech ? Math.max(40, Math.round(getEffectiveTechCost(tech, nation) * 0.35)) : 80;
        nation.techProgress += boost;
      } else {
        nation.resources.culture += 80;
        nation.resources.influence += 50;
      }
      break;
    case 'boom':
      if (city) city.population += choice.id === 'welcome' ? 600 : 250;
      if (choice.id === 'welcome') nation.resources.food += 100;
      else nation.resources.gold += 110;
      break;
    case 'drought':
      if (choice.id !== 'relief') {
        nation.resources.food = Math.max(0, nation.resources.food - 90);
        if (terr) terr.occupationUnrest = Math.min(100, terr.occupationUnrest + 12);
      }
      break;
    case 'flood':
      if (choice.id === 'dikes') nation.resources.food += 80;
      else {
        nation.resources.wood = Math.max(0, nation.resources.wood - 60);
        nation.resources.stone = Math.max(0, nation.resources.stone - 40);
      }
      break;
    case 'earthquake':
      if (choice.id !== 'rebuild' && terr) terr.occupationUnrest = Math.min(100, terr.occupationUnrest + 15);
      break;
    case 'storm':
      if (choice.id !== 'harbor') {
        for (const f of Object.values(state.fleets)) {
          if (f.nationId === nation.id) f.supply = Math.max(25, f.supply - 15);
        }
      }
      break;
    case 'disease':
      if (choice.id !== 'quarantine' && city) {
        city.diseaseOutbreak = true;
      }
      break;
    case 'recession':
      if (choice.id === 'stimulus') {
        nation.resources.stone += 120;
        nation.resources.wood += 120;
      } else {
        nation.resources.gold = Math.max(0, nation.resources.gold - 80);
        nation.resources.influence += 25;
      }
      break;
    case 'instability':
      if (choice.id === 'concessions' && terr) {
        terr.occupationUnrest = Math.max(0, terr.occupationUnrest - 15);
      } else {
        nation.resources.influence += 40;
        if (terr) terr.occupationUnrest = Math.min(100, terr.occupationUnrest + 12);
      }
      break;
  }

  state.timeline.unshift({
    id: `tl_${state.nextEntitySeq++}`,
    tick: state.tick,
    yearLabel: formatYear(state.year),
    category: 'event',
    title: evt.title,
    description: `${nation.name} chose: ${choice.label}.`,
    nationId: nation.id,
  });
  state.pendingEvent = null;
}
