import { formatYear } from '../data/eras';
import { TECHNOLOGIES } from '../data/technologies';
import { GameState, VictoryType } from '../types/game';
import { computeArmyPower, computeFleetPower } from './combat';

export function evaluateVictoryConditions(state: GameState): void {
  const landIds = state.territoryIds.filter((id) => !state.territories[id].isWater);
  const totalLand = Math.max(1, landIds.length);
  const activeNations = Object.values(state.nations).filter((n) => !n.eliminated);

  // Update each nation's military, naval & diplomatic scores
  let globalMilitaryTotal = 0;
  for (const n of activeNations) {
    const armyPow = Object.values(state.armies)
      .filter((a) => a.nationId === n.id)
      .reduce((s, a) => s + computeArmyPower(a, false, state), 0);
    const navalPow = Object.values(state.fleets)
      .filter((f) => f.nationId === n.id)
      .reduce((s, f) => s + computeFleetPower(f, false, state), 0);
    n.stats.militaryPower = Math.round(armyPow + navalPow * 0.75);
    n.stats.navalPower = Math.round(navalPow);
    globalMilitaryTotal += n.stats.militaryPower;

    const allies = Object.values(n.relations).filter(
      (r) => !state.nations[r.otherNationId]?.eliminated && (r.alliance || r.defensivePact)
    ).length;
    const tradePacts = Object.values(n.relations).filter(
      (r) => !state.nations[r.otherNationId]?.eliminated && r.tradeAgreement
    ).length;
    n.stats.diplomaticScore = Math.round(n.resources.influence + allies * 350 + tradePacts * 140);
  }

  // Compute progress for the player (or leading observer)
  const player = state.nations[state.playerNationId];
  if (player) {
    const pTerr = landIds.filter((id) => state.territories[id].ownerId === player.id).length;
    const terrTarget = Math.max(8, Math.round(totalLand * 0.6));

    const milTarget = Math.max(800, Math.round(globalMilitaryTotal * 0.52));
    const econTarget = 20000;
    const sciTarget = TECHNOLOGIES.length;
    const cultTarget = 8000;
    const otherActive = Math.max(1, activeNations.length - 1);
    const pAllies = Object.values(player.relations).filter(
      (r) => !state.nations[r.otherNationId]?.eliminated && (r.alliance || r.defensivePact)
    ).length;
    const dipTarget = Math.max(1, Math.ceil(otherActive * 0.65));

    state.victory.territorial = {
      current: pTerr,
      target: terrTarget,
      pct: Math.min(100, Math.round((pTerr / terrTarget) * 100)),
    };
    state.victory.military = {
      current: player.stats.militaryPower,
      target: milTarget,
      pct: Math.min(100, Math.round((player.stats.militaryPower / milTarget) * 100)),
    };
    state.victory.economic = {
      current: player.stats.economicScore,
      target: econTarget,
      pct: Math.min(100, Math.round((player.stats.economicScore / econTarget) * 100)),
    };
    state.victory.scientific = {
      current: player.unlockedTechs.length,
      target: sciTarget,
      pct: Math.min(100, Math.round((player.unlockedTechs.length / sciTarget) * 100)),
    };
    state.victory.cultural = {
      current: player.stats.cultureScore,
      target: cultTarget,
      pct: Math.min(100, Math.round((player.stats.cultureScore / cultTarget) * 100)),
    };
    state.victory.diplomatic = {
      current: pAllies,
      target: dipTarget,
      pct: Math.min(100, Math.round((pAllies / dipTarget) * 100)),
    };
  }

  if (state.victory.winnerNationId) return;

  // Check if ANY nation met a victory condition
  for (const n of activeNations) {
    const ownedCount = landIds.filter((id) => state.territories[id].ownerId === n.id).length;
    let wonType: VictoryType | null = null;

    if (activeNations.length === 1 && ownedCount > 1) {
      wonType = 'military';
    } else if (ownedCount >= Math.max(8, Math.round(totalLand * 0.6))) {
      wonType = 'territorial';
    } else if (n.unlockedTechs.includes('space_exploration') && n.unlockedTechs.length >= TECHNOLOGIES.length - 4) {
      wonType = 'scientific';
    } else if (n.stats.economicScore >= 20000) {
      wonType = 'economic';
    } else if (n.stats.cultureScore >= 8000) {
      wonType = 'cultural';
    } else if (
      activeNations.length >= 3 &&
      Object.values(n.relations).filter(
        (r) => !state.nations[r.otherNationId]?.eliminated && r.alliance
      ).length >= Math.ceil((activeNations.length - 1) * 0.75) &&
      n.resources.influence >= 1500
    ) {
      wonType = 'diplomatic';
    }

    if (wonType) {
      state.victory.winnerNationId = n.id;
      state.victory.victoryType = wonType;
      state.speed = 0; // Pause at victory screen
      state.timeline.unshift({
        id: `tl_${state.nextEntitySeq++}`,
        tick: state.tick,
        yearLabel: formatYear(state.year),
        category: 'victory',
        title: `${wonType.toUpperCase()} VICTORY!`,
        description: `${n.name} achieved ${wonType} supremacy across the world!`,
        nationId: n.id,
      });
      break;
    }
  }
}
