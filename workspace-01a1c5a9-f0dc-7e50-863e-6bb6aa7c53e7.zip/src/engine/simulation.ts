import { BUILDING_BY_ID } from '../data/buildings';
import { ERAS, formatYear } from '../data/eras';
import { GOVERNMENTS, POLICY_BY_ID } from '../data/governments';
import { TECH_BY_ID, TECHNOLOGIES } from '../data/technologies';
import { TERRAINS } from '../data/terrains';
import { UNIT_BY_ID } from '../data/units';
import {
  BudgetSettings,
  EraId,
  Fleet,
  GameState,
  GovernmentType,
  OccupationKey,
  ResourceKey,
} from '../types/game';
import { foundNewCityOnTerritory, simulateAICivilizations } from './ai';
import {
  computeFleetPower,
  declareWar,
  getArmyTotalUnitCount,
  getFleetTransportCapacity,
  simulateBattles,
  startLandOrAmphibiousBattle,
  startNavalBattle,
} from './combat';
import {
  canAfford,
  recomputeNationEconomy,
  refreshTradeRoutes,
  spendResources,
  updateMarketPrices,
} from './economy';
import {
  formatTechBlockReason,
  getEffectiveTechCost,
  getTechComplexityMultiplier,
  getTechRequirementsStatus,
  TechRequirementStatus,
} from './tech';

export {
  formatTechBlockReason,
  getEffectiveTechCost,
  getTechComplexityMultiplier,
  getTechRequirementsStatus,
  type TechRequirementStatus,
};
import { resolvePendingEventChoice, simulateWeatherAndEvents } from './events';
import { findLandPath, findNavalPath } from './pathfinding';
import { simulateCitiesAndPopulation } from './population';
import { evaluateVictoryConditions } from './victory';

export function stepSimulation(state: GameState, baseDtSeconds = 1.0): void {
  if (state.speed === 0) return;

  const dt = baseDtSeconds * state.speed * (state.config.speedMultiplier || 1);
  const dtMinutes = dt / 60;
  state.tick += 1;

  // Advance historical calendar realistically per era
  const playerEra = state.nations[state.playerNationId]?.era ?? 'ancient';
  const yearsPerSec =
    playerEra === 'ancient'
      ? 14
      : playerEra === 'classical'
        ? 8
        : playerEra === 'medieval'
          ? 5
          : playerEra === 'renaissance'
            ? 2.8
            : playerEra === 'industrial'
              ? 1.4
              : 0.7;
  state.year += yearsPerSec * dt * 0.25;

  // 1. Economy & Science Accumulation
  for (const nation of Object.values(state.nations)) {
    if (nation.eliminated) continue;
    recomputeNationEconomy(state, nation, dtMinutes);
    advanceNationResearch(state, nation, dtMinutes);
  }

  // 2. Construction Queues
  for (const city of Object.values(state.cities)) {
    if (city.queue.length === 0) continue;
    const item = city.queue[0];
    const buildersFactor = 1 + (city.occupations.builders / Math.max(500, city.population)) * 0.7;
    item.progress += dt * buildersFactor;
    if (item.progress >= item.totalTime) {
      city.queue.shift();
      const existing = city.buildings.find((b) => b.buildingId === item.buildingId);
      if (existing) {
        existing.level = item.targetLevel;
      } else {
        city.buildings.push({ buildingId: item.buildingId, level: item.targetLevel });
      }
      const def = BUILDING_BY_ID[item.buildingId];
      if (city.nationId === state.playerNationId && def) {
        state.notifications.unshift({
          id: `notif_${state.nextEntitySeq++}`,
          tick: state.tick,
          severity: 'success',
          title: 'Construction Complete',
          message: `${def.name} (Lv.${item.targetLevel}) completed in ${city.name}.`,
          territoryId: city.territoryId,
        });
      }
    }
  }

  // 3. Recruitment Queues
  for (let i = state.recruitmentQueue.length - 1; i >= 0; i--) {
    const order = state.recruitmentQueue[i];
    const city = state.cities[order.cityId];
    const barracksBonus =
      city?.buildings.some((b) => b.buildingId === 'barracks' || b.buildingId === 'military_academies') ? 1.25 : 1.0;
    order.progress += dt * barracksBonus;
    if (order.progress >= order.totalTime) {
      state.recruitmentQueue.splice(i, 1);
      const uDef = UNIT_BY_ID[order.unitId];
      if (!uDef) continue;

      if (uDef.domain === 'naval') {
        const existingFleet = Object.values(state.fleets).find(
          (f) => f.nationId === order.nationId && f.territoryId === order.territoryId && !f.inBattleId
        );
        if (existingFleet) {
          const stack = existingFleet.ships.find((s) => s.unitId === order.unitId);
          if (stack) stack.count += order.count;
          else existingFleet.ships.push({ unitId: order.unitId, count: order.count, hp: 100, experience: 10 });
        } else {
          const fid = `fleet_${state.nextEntitySeq++}`;
          const n = state.nations[order.nationId];
          state.fleets[fid] = {
            id: fid,
            name: `${n?.adjective ?? 'Naval'} Fleet ${Object.keys(state.fleets).length + 1}`,
            nationId: order.nationId,
            territoryId: order.territoryId,
            targetTerritoryId: null,
            path: [],
            moveProgress: 0,
            ships: [{ unitId: order.unitId, count: order.count, hp: 100, experience: 10 }],
            supply: 100,
            morale: 92,
            mission: 'idle',
            carriedArmyIds: [],
            inBattleId: null,
          };
        }
      } else {
        const existingArmy = Object.values(state.armies).find(
          (a) =>
            a.nationId === order.nationId &&
            a.territoryId === order.territoryId &&
            !a.embarkedFleetId &&
            !a.inBattleId
        );
        if (existingArmy) {
          const stack = existingArmy.units.find((s) => s.unitId === order.unitId);
          if (stack) stack.count += order.count;
          else existingArmy.units.push({ unitId: order.unitId, count: order.count, hp: 100, experience: 10 });
        } else {
          const aid = `army_${state.nextEntitySeq++}`;
          const n = state.nations[order.nationId];
          state.armies[aid] = {
            id: aid,
            name: `${n?.adjective ?? 'Field'} Army ${Object.keys(state.armies).length + 1}`,
            nationId: order.nationId,
            territoryId: order.territoryId,
            targetTerritoryId: null,
            path: [],
            moveProgress: 0,
            units: [{ unitId: order.unitId, count: order.count, hp: 100, experience: 10 }],
            supply: 100,
            morale: 90,
            fortified: false,
            embarkedFleetId: null,
            inBattleId: null,
          };
        }
      }
    }
  }

  // 4. Move Armies along Land Paths
  stepArmyMovements(state, dt);

  // 5. Move Fleets along Ocean Paths, Repair, Blockades & Naval Intercepts
  stepFleetMovementsAndNaval(state, dt);

  // 6. Combat Resolution
  simulateBattles(state, dt);

  // 7. Population & City Simulation
  simulateCitiesAndPopulation(state, dt);

  // 8. Periodic Systems (AI, Trade, Market, Weather/Events, Victory)
  if (state.tick % 4 === 0) {
    simulateAICivilizations(state);
    refreshTradeRoutes(state);
    updateMarketPrices(state);
  }
  simulateWeatherAndEvents(state);
  evaluateVictoryConditions(state);

  // Cap notification/timeline arrays
  if (state.notifications.length > 60) state.notifications.length = 60;
  if (state.timeline.length > 120) state.timeline.length = 120;
}

function advanceNationResearch(state: GameState, nation: GameState['nations'][string], dtMinutes: number): void {
  if (!nation.currentTechId && nation.techQueue.length > 0) {
    const next = nation.techQueue.shift()!;
    const def = TECH_BY_ID[next];
    if (def && getTechRequirementsStatus(state, nation, def).canStart) {
      cmdSelectTech(state, nation.id, next);
    }
  }
  if (!nation.currentTechId) return;

  const tech = TECH_BY_ID[nation.currentTechId];
  if (!tech) {
    nation.currentTechId = null;
    return;
  }

  const sciRate = Math.max(4, nation.ratesPerMin.science);
  nation.techProgress += sciRate * dtMinutes * 1.9;
  if (!nation.techProgressById) nation.techProgressById = {};
  nation.techProgressById[tech.id] = nation.techProgress;

  const effectiveCost = getEffectiveTechCost(tech, nation);
  if (nation.techProgress >= effectiveCost) {
    nation.unlockedTechs.push(tech.id);
    delete nation.techProgressById[tech.id];
    nation.currentTechId = null;
    nation.techProgress = 0;

    // Check historical era advancement
    const prevEraOrder = ERAS.find((e) => e.id === nation.era)?.order ?? 0;
    const techEraOrder = ERAS.find((e) => e.id === tech.era)?.order ?? 0;
    if (techEraOrder > prevEraOrder) {
      nation.era = tech.era;
      const eraName = ERAS.find((e) => e.id === tech.era)?.name ?? tech.era;
      state.timeline.unshift({
        id: `tl_${state.nextEntitySeq++}`,
        tick: state.tick,
        yearLabel: formatYear(state.year),
        category: 'era',
        title: `${nation.name} Entered ${eraName}`,
        description: `Advancing through ${tech.name}, ${nation.name} entered the ${eraName}.`,
        nationId: nation.id,
      });
      if (nation.id === state.playerNationId) {
        state.notifications.unshift({
          id: `notif_${state.nextEntitySeq++}`,
          tick: state.tick,
          severity: 'success',
          title: `New Historical Era: ${eraName}!`,
          message: `Your civilization has entered the ${eraName}, unlocking new technologies and units.`,
        });
      }
    } else if (nation.id === state.playerNationId) {
      state.notifications.unshift({
        id: `notif_${state.nextEntitySeq++}`,
        tick: state.tick,
        severity: 'info',
        title: `Research Complete: ${tech.name}`,
        message: tech.unlocksText.join(' · '),
      });
    }
  }
}

function stepArmyMovements(state: GameState, dt: number): void {
  for (const army of Object.values(state.armies)) {
    if (army.inBattleId || army.embarkedFleetId) continue;
    const nation = state.nations[army.nationId];
    if (!nation) continue;

    // Supply & Morale replenishment / desertion
    const curT = state.territories[army.territoryId];
    if (curT) {
      const tDef = TERRAINS[curT.terrain];
      if (curT.ownerId === army.nationId) {
        army.supply = Math.min(100, army.supply + dt * 6);
        army.morale = Math.min(100, army.morale + dt * 4);
        // Heal slightly in owned city
        if (curT.cityId) {
          for (const s of army.units) s.hp = Math.min(100, s.hp + dt * 2.2);
        }
      } else {
        army.supply = Math.max(15, army.supply - (0.5 + tDef.supplyDrain * 5) * dt);
      }
    }

    if (!army.targetTerritoryId && army.path.length === 0) continue;

    // Build path if target specified without path
    if (army.targetTerritoryId && army.path.length === 0) {
      const path = findLandPath(state, army.territoryId, army.targetTerritoryId, army.nationId, true);
      if (!path || path.length < 2) {
        army.targetTerritoryId = null;
        continue;
      }
      army.path = path;
      army.moveProgress = 0;
    }

    if (army.path.length < 2) {
      army.path = [];
      army.targetTerritoryId = null;
      continue;
    }

    const fromT = state.territories[army.path[0]];
    const nextT = state.territories[army.path[1]];
    if (!fromT || !nextT) {
      army.path = [];
      army.targetTerritoryId = null;
      continue;
    }

    // Calculate slowest unit speed & terrain movement cost
    let minSpeed = 120;
    for (const st of army.units) {
      const def = UNIT_BY_ID[st.unitId];
      if (def) minSpeed = Math.min(minSpeed, def.speed);
    }
    let infraBoost = 1.0;
    if (fromT.cityId && state.cities[fromT.cityId]) {
      const city = state.cities[fromT.cityId];
      if (city.buildings.some((b) => b.buildingId === 'railways')) infraBoost += 0.45;
      else if (city.buildings.some((b) => b.buildingId === 'roads')) infraBoost += 0.22;
    }

    const dist = Math.max(40, Math.hypot(nextT.center.x - fromT.center.x, nextT.center.y - fromT.center.y));
    const terrainCost = TERRAINS[nextT.terrain].movementCost;
    const stepFrac = ((minSpeed * infraBoost) / (dist * terrainCost)) * dt * 1.45;

    army.fortified = false;
    army.moveProgress += stepFrac;

    if (army.moveProgress >= 1.0) {
      army.moveProgress = 0;
      const isHostile = nextT.ownerId !== army.nationId && !(nextT.ownerId && nation.relations[nextT.ownerId]?.alliance);
      if (isHostile) {
        // Trigger battle at destination!
        army.path = [];
        army.targetTerritoryId = null;
        startLandOrAmphibiousBattle(state, army, nextT.id);
      } else {
        army.territoryId = nextT.id;
        army.path.shift();
        if (army.path.length < 2) {
          army.path = [];
          army.targetTerritoryId = null;
        }
      }
    }
  }
}

function stepFleetMovementsAndNaval(state: GameState, dt: number): void {
  // Clear stale blockades before recalculating from active blockade fleets
  for (const id of state.territoryIds) {
    state.territories[id].blockadedByNationId = null;
  }

  const fleets = Object.values(state.fleets);
  for (const fleet of fleets) {
    if (fleet.inBattleId) continue;
    const nation = state.nations[fleet.nationId];
    if (!nation) continue;

    // Keep carried armies synced to fleet position
    for (const aid of fleet.carriedArmyIds) {
      if (state.armies[aid]) {
        state.armies[aid].territoryId = fleet.territoryId;
      }
    }

    const curT = state.territories[fleet.territoryId];
    if (curT) {
      // Friendly Naval Base / Port repair & resupply
      const atFriendlyBase =
        !curT.isWater &&
        curT.ownerId === fleet.nationId &&
        curT.cityId &&
        state.cities[curT.cityId]?.buildings.some(
          (b) => b.buildingId === 'naval_bases' || b.buildingId === 'ports'
        );
      if (atFriendlyBase) {
        fleet.supply = Math.min(100, fleet.supply + dt * 12);
        fleet.morale = Math.min(100, fleet.morale + dt * 8);
        for (const s of fleet.ships) s.hp = Math.min(100, s.hp + dt * 5);
      } else if (curT.weatherStorm) {
        fleet.supply = Math.max(20, fleet.supply - dt * 1.4);
      }

      // Apply naval blockade on adjacent enemy coastal territories if mission === 'blockade'
      if (fleet.mission === 'blockade' && curT.isWater) {
        for (const nid of curT.landNeighbors) {
          const lt = state.territories[nid];
          if (lt.ownerId && lt.ownerId !== fleet.nationId && nation.relations[lt.ownerId]?.atWar) {
            lt.blockadedByNationId = fleet.nationId;
          }
        }
      }
    }

    // Intercept hostile fleets in same sea zone
    const enemyFleetHere = fleets.find(
      (other) =>
        other.id !== fleet.id &&
        !other.inBattleId &&
        other.territoryId === fleet.territoryId &&
        other.nationId !== fleet.nationId &&
        nation.relations[other.nationId]?.atWar &&
        computeFleetPower(fleet, false, state) > 5
    );
    if (enemyFleetHere) {
      startNavalBattle(state, fleet, enemyFleetHere);
      continue;
    }

    if (fleet.path.length < 2) {
      fleet.path = [];
      fleet.targetTerritoryId = null;
      continue;
    }

    const fromT = state.territories[fleet.path[0]];
    const nextT = state.territories[fleet.path[1]];
    if (!fromT || !nextT) {
      fleet.path = [];
      fleet.targetTerritoryId = null;
      continue;
    }

    let minSpeed = 160;
    for (const st of fleet.ships) {
      const def = UNIT_BY_ID[st.unitId];
      if (def) minSpeed = Math.min(minSpeed, def.speed);
    }
    let navalTechBonus = 1.0;
    for (const tid of nation.unlockedTechs) {
      navalTechBonus += TECH_BY_ID[tid]?.bonuses?.navalSpeedMod ?? 0;
    }
    const stormPenalty = nextT.weatherStorm ? 0.62 : 1.0;
    const dist = Math.max(40, Math.hypot(nextT.center.x - fromT.center.x, nextT.center.y - fromT.center.y));
    const stepFrac = ((minSpeed * navalTechBonus * stormPenalty) / dist) * dt * 1.6;

    fleet.moveProgress += stepFrac;
    if (fleet.moveProgress >= 1.0) {
      fleet.moveProgress = 0;
      fleet.territoryId = nextT.id;
      fleet.path.shift();
      if (fleet.path.length < 2) {
        fleet.path = [];
        fleet.targetTerritoryId = null;
      }
    }
  }
}

// =====================================================================
// VALIDATED PLAYER / MULTIPLAYER ACTION COMMANDS
// =====================================================================

export function cmdAttackOrMoveArmy(
  state: GameState,
  nationId: string,
  armyId: string,
  targetTerritoryId: string
): { ok: boolean; error?: string } {
  const army = state.armies[armyId];
  const target = state.territories[targetTerritoryId];
  const nation = state.nations[nationId];
  if (!army || army.nationId !== nationId || !target || !nation) {
    return { ok: false, error: 'Invalid army or target territory.' };
  }
  if (army.inBattleId) return { ok: false, error: 'Army is currently engaged in battle.' };
  if (army.embarkedFleetId) return { ok: false, error: 'Army is embarked on a fleet. Disembark or launch amphibious invasion instead.' };
  if (target.isWater) return { ok: false, error: 'Armies cannot march across ocean waters without Transport Ships.' };

  const curT = state.territories[army.territoryId];
  const isAdjacent = curT?.landNeighbors.includes(targetTerritoryId);
  const isHostile = target.ownerId !== nationId && !(target.ownerId && nation.relations[target.ownerId]?.alliance);

  if (isHostile && isAdjacent) {
    startLandOrAmphibiousBattle(state, army, targetTerritoryId);
    return { ok: true };
  }

  const path = findLandPath(state, army.territoryId, targetTerritoryId, nationId, true);
  if (!path || path.length < 2) {
    return { ok: false, error: 'No connected land supply route to destination. Use a Naval Fleet for overseas invasion!' };
  }
  army.targetTerritoryId = targetTerritoryId;
  army.path = path;
  army.moveProgress = 0;
  army.fortified = false;
  return { ok: true };
}

export function cmdMoveFleet(
  state: GameState,
  nationId: string,
  fleetId: string,
  targetTerritoryId: string,
  mission: Fleet['mission'] = 'idle'
): { ok: boolean; error?: string } {
  const fleet = state.fleets[fleetId];
  const target = state.territories[targetTerritoryId];
  if (!fleet || fleet.nationId !== nationId || !target) {
    return { ok: false, error: 'Invalid fleet or destination.' };
  }
  if (fleet.inBattleId) return { ok: false, error: 'Fleet is currently in naval combat.' };
  if (!target.isWater && !(target.isCoastal && target.ownerId === nationId)) {
    return { ok: false, error: 'Fleets can only navigate ocean sea zones or friendly coastal ports.' };
  }

  const path = findNavalPath(state, fleet.territoryId, targetTerritoryId, true);
  if (!path || path.length < 2) {
    return { ok: false, error: 'No navigable sea route to destination.' };
  }
  fleet.mission = mission;
  fleet.targetTerritoryId = targetTerritoryId;
  fleet.path = path;
  fleet.moveProgress = 0;
  return { ok: true };
}

export function cmdAttackEnemyFleet(
  state: GameState,
  nationId: string,
  fleetId: string,
  enemyFleetId: string
): { ok: boolean; error?: string } {
  const myFleet = state.fleets[fleetId];
  const enemyFleet = state.fleets[enemyFleetId];
  const nation = state.nations[nationId];
  if (!myFleet || !enemyFleet || myFleet.nationId !== nationId || !nation) {
    return { ok: false, error: 'Invalid fleet selection.' };
  }
  if (enemyFleet.nationId === nationId) return { ok: false, error: 'Cannot attack friendly fleet.' };

  if (!nation.relations[enemyFleet.nationId]?.atWar) {
    declareWar(state, nationId, enemyFleet.nationId);
  }
  if (myFleet.territoryId === enemyFleet.territoryId || state.territories[myFleet.territoryId]?.neighbors.includes(enemyFleet.territoryId)) {
    startNavalBattle(state, myFleet, enemyFleet);
    return { ok: true };
  }
  return cmdMoveFleet(state, nationId, fleetId, enemyFleet.territoryId, 'attack');
}

export function cmdEmbarkArmy(
  state: GameState,
  nationId: string,
  armyId: string,
  fleetId: string
): { ok: boolean; error?: string } {
  const army = state.armies[armyId];
  const fleet = state.fleets[fleetId];
  if (!army || !fleet || army.nationId !== nationId || fleet.nationId !== nationId) {
    return { ok: false, error: 'Invalid army or fleet.' };
  }
  if (army.embarkedFleetId) return { ok: false, error: 'Army is already embarked.' };
  const cap = getFleetTransportCapacity(fleet);
  const used = fleet.carriedArmyIds.reduce((s, id) => s + (state.armies[id] ? getArmyTotalUnitCount(state.armies[id]) : 0), 0);
  const needed = getArmyTotalUnitCount(army);
  if (cap <= 0) return { ok: false, error: 'This fleet has no Transport Ships!' };
  if (used + needed > cap) return { ok: false, error: `Insufficient transport capacity (${cap - used} free, need ${needed}).` };

  const armyT = state.territories[army.territoryId];
  const fleetT = state.territories[fleet.territoryId];
  const closeEnough =
    army.territoryId === fleet.territoryId ||
    armyT?.neighbors.includes(fleet.territoryId) ||
    fleetT?.neighbors.includes(army.territoryId);
  if (!closeEnough || !armyT?.isCoastal) {
    return { ok: false, error: 'Army must be in a coastal territory adjacent to the fleet to embark.' };
  }

  army.embarkedFleetId = fleet.id;
  army.territoryId = fleet.territoryId;
  army.path = [];
  army.targetTerritoryId = null;
  fleet.carriedArmyIds.push(army.id);
  fleet.mission = 'transport';
  return { ok: true };
}

export function cmdLaunchAmphibiousInvasion(
  state: GameState,
  nationId: string,
  fleetId: string,
  targetCoastalTerritoryId: string
): { ok: boolean; error?: string } {
  const fleet = state.fleets[fleetId];
  const target = state.territories[targetCoastalTerritoryId];
  if (!fleet || fleet.nationId !== nationId || !target || target.isWater || !target.isCoastal) {
    return { ok: false, error: 'Target must be a coastal land territory.' };
  }
  if (fleet.carriedArmyIds.length === 0) {
    return { ok: false, error: 'No army embarked on this fleet! Embark a land army onto Transport Ships first.' };
  }
  const fleetT = state.territories[fleet.territoryId];
  const adjacent = fleet.territoryId === target.id || fleetT?.neighbors.includes(target.id);
  if (!adjacent) {
    return { ok: false, error: 'Sail the fleet to coastal waters adjacent to the target shoreline first.' };
  }

  const army = state.armies[fleet.carriedArmyIds[0]];
  if (!army) return { ok: false, error: 'Embarked army unavailable.' };

  if (target.ownerId === nationId) {
    // Friendly disembark!
    fleet.carriedArmyIds = fleet.carriedArmyIds.filter((id) => id !== army.id);
    army.embarkedFleetId = null;
    army.territoryId = target.id;
    return { ok: true };
  }

  startLandOrAmphibiousBattle(state, army, target.id, fleet);
  return { ok: true };
}

export function cmdEstablishCity(
  state: GameState,
  nationId: string,
  territoryId: string
): { ok: boolean; error?: string } {
  const terr = state.territories[territoryId];
  const nation = state.nations[nationId];
  if (!terr || !nation || terr.ownerId !== nationId || terr.isWater) {
    return { ok: false, error: 'You must own this land territory.' };
  }
  if (terr.cityId) return { ok: false, error: 'A city already exists in this territory.' };
  const cost = { gold: 90, wood: 60, stone: 35 };
  if (!canAfford(nation, cost)) return { ok: false, error: 'Requires 90 Gold, 60 Wood, 35 Stone.' };
  spendResources(nation, cost);
  foundNewCityOnTerritory(state, nationId, territoryId);
  return { ok: true };
}

export function cmdBuildStructure(
  state: GameState,
  nationId: string,
  cityId: string,
  buildingId: string
): { ok: boolean; error?: string } {
  const city = state.cities[cityId];
  const nation = state.nations[nationId];
  const def = BUILDING_BY_ID[buildingId];
  if (!city || !nation || !def || city.nationId !== nationId) {
    return { ok: false, error: 'Invalid city or building.' };
  }
  const terr = state.territories[city.territoryId];
  if (def.coastalOnly && !terr?.isCoastal) {
    return { ok: false, error: `${def.name} can only be built in coastal cities.` };
  }
  if (def.requiredTech && !nation.unlockedTechs.includes(def.requiredTech)) {
    return { ok: false, error: `Requires technology: ${TECH_BY_ID[def.requiredTech]?.name ?? def.requiredTech}.` };
  }
  const existing = city.buildings.find((b) => b.buildingId === buildingId);
  const queuedSame = city.queue.filter((q) => q.buildingId === buildingId).length;
  const targetLevel = (existing?.level ?? 0) + queuedSame + 1;
  if (targetLevel > def.maxLevel) {
    return { ok: false, error: `${def.name} is already at max level (${def.maxLevel}).` };
  }

  const levelCost: Partial<Record<ResourceKey, number>> = {};
  for (const [k, v] of Object.entries(def.cost)) {
    levelCost[k as ResourceKey] = Math.round((v ?? 0) * (1 + (targetLevel - 1) * 0.6));
  }
  if (!canAfford(nation, levelCost)) {
    return { ok: false, error: 'Insufficient resources for construction.' };
  }
  spendResources(nation, levelCost);
  city.queue.push({
    id: `con_${state.nextEntitySeq++}`,
    cityId: city.id,
    territoryId: city.territoryId,
    buildingId,
    targetLevel,
    progress: 0,
    totalTime: Math.round(def.buildTime * (1 + (targetLevel - 1) * 0.35)),
  });
  return { ok: true };
}

export function cmdRecruitUnits(
  state: GameState,
  nationId: string,
  cityId: string,
  unitId: string,
  count = 1
): { ok: boolean; error?: string } {
  const city = state.cities[cityId];
  const nation = state.nations[nationId];
  const def = UNIT_BY_ID[unitId];
  if (!city || !nation || !def || city.nationId !== nationId || count < 1) {
    return { ok: false, error: 'Invalid recruitment order.' };
  }
  if (def.requiredTech && !nation.unlockedTechs.includes(def.requiredTech)) {
    return { ok: false, error: `Requires ${TECH_BY_ID[def.requiredTech]?.name ?? def.requiredTech}.` };
  }
  if (def.domain === 'naval') {
    const hasHarbor = city.buildings.some((b) => b.buildingId === 'ports' || b.buildingId === 'naval_bases');
    if (!hasHarbor) {
      return { ok: false, error: 'Naval units require a Port or Naval Base in this coastal city.' };
    }
  }
  if (def.domain === 'air') {
    const hasAir = city.buildings.some((b) => b.buildingId === 'airbases' || b.buildingId === 'airports');
    if (!hasAir) {
      return { ok: false, error: 'Air units require an Airbase or Airport in this city.' };
    }
  }

  const totalCost: Partial<Record<ResourceKey, number>> = {};
  for (const [k, v] of Object.entries(def.cost)) {
    totalCost[k as ResourceKey] = Math.round((v ?? 0) * count);
  }
  if (!canAfford(nation, totalCost)) {
    return { ok: false, error: 'Insufficient resources to train these units.' };
  }
  spendResources(nation, totalCost);
  state.recruitmentQueue.push({
    id: `rec_${state.nextEntitySeq++}`,
    nationId,
    cityId: city.id,
    territoryId: city.territoryId,
    unitId,
    count,
    progress: 0,
    totalTime: Math.max(3, Math.round(def.trainTime * (0.7 + count * 0.3))),
  });
  return { ok: true };
}

export function cmdSelectTech(
  state: GameState,
  nationId: string,
  techId: string
): { ok: boolean; error?: string; message?: string } {
  const nation = state.nations[nationId];
  const tech = TECH_BY_ID[techId];
  if (!nation || !tech) return { ok: false, error: 'Technology not found.' };
  if (nation.currentTechId === techId) return { ok: true };

  const status = getTechRequirementsStatus(state, nation, tech);
  if (!status.canStart) {
    return { ok: false, error: formatTechBlockReason(status) };
  }

  if (!nation.techFundedIds) nation.techFundedIds = [];
  if (!nation.techProgressById) nation.techProgressById = {};

  if (!status.alreadyFunded && tech.resourceCost) {
    spendResources(nation, tech.resourceCost);
    nation.techFundedIds.push(tech.id);
  }

  if (nation.currentTechId) {
    nation.techProgressById[nation.currentTechId] = nation.techProgress;
  }

  nation.currentTechId = techId;
  nation.techProgress = nation.techProgressById[techId] ?? 0;
  return {
    ok: true,
    message: status.alreadyFunded
      ? `Resumed research on ${tech.name}.`
      : `Funded & started researching ${tech.name}.`,
  };
}

export function cmdAdjustCityOccupation(
  state: GameState,
  nationId: string,
  cityId: string,
  key: OccupationKey,
  delta: number
): { ok: boolean } {
  const city = state.cities[cityId];
  if (!city || city.nationId !== nationId) return { ok: false };
  const workforce = Math.round(city.population * 0.92);
  const sum = Object.values(city.occupations).reduce((a, b) => a + b, 0);
  if (delta > 0) {
    const free = Math.max(0, workforce - sum);
    let add = Math.min(delta, free);
    if (add < delta) {
      // Shift from largest other occupation
      const otherKeys = (Object.keys(city.occupations) as OccupationKey[]).filter((k) => k !== key);
      otherKeys.sort((a, b) => city.occupations[b] - city.occupations[a]);
      const donor = otherKeys[0];
      const steal = Math.min(delta - add, city.occupations[donor]);
      city.occupations[donor] -= steal;
      add += steal;
    }
    city.occupations[key] += add;
  } else if (delta < 0) {
    city.occupations[key] = Math.max(0, city.occupations[key] + delta);
  }
  return { ok: true };
}

export function cmdDiplomacyAction(
  state: GameState,
  nationId: string,
  otherId: string,
  action: 'war' | 'peace' | 'trade' | 'non_aggression' | 'defensive_pact' | 'alliance' | 'gift' | 'exchange',
  giftResource?: ResourceKey,
  giftAmount = 100
): { ok: boolean; message: string } {
  const me = state.nations[nationId];
  const them = state.nations[otherId];
  if (!me || !them || them.eliminated) return { ok: false, message: 'Civilization unavailable.' };
  const rel = me.relations[otherId];
  const rev = them.relations[nationId];
  if (!rel || !rev) return { ok: false, message: 'No diplomatic contact.' };

  if (action === 'war') {
    declareWar(state, nationId, otherId);
    return { ok: true, message: `Declared war on ${them.name}.` };
  }

  if (action === 'peace') {
    if (!rel.atWar) return { ok: false, message: 'Not currently at war.' };
    if (them.isHumanMultiplayer) {
      // Immediate bilateral peace request simplified for smooth gameplay
    }
    rel.atWar = false;
    rev.atWar = false;
    rel.truceUntilTick = state.tick + 90;
    rev.truceUntilTick = state.tick + 90;
    rel.score = Math.min(100, rel.score + 20);
    rev.score = Math.min(100, rev.score + 20);
    return { ok: true, message: `Peace treaty signed with ${them.name}.` };
  }

  if (action === 'gift') {
    const res = giftResource ?? 'gold';
    if (me.resources[res] < giftAmount) return { ok: false, message: `Insufficient ${res} to send gift.` };
    me.resources[res] -= giftAmount;
    them.resources[res] += giftAmount;
    rel.score = Math.min(100, rel.score + 18);
    rev.score = Math.min(100, rev.score + 22);
    return { ok: true, message: `Sent ${giftAmount} ${res} to ${them.name} (+22 Relations).` };
  }

  if (rel.atWar) return { ok: false, message: 'Must sign Peace before diplomatic pacts.' };

  if (action === 'trade') {
    if (rel.score < -25) return { ok: false, message: `${them.name} refuses trade while relations are hostile (${rel.score}).` };
    rel.tradeAgreement = true;
    rev.tradeAgreement = true;
    rel.score = Math.min(100, rel.score + 10);
    rev.score = Math.min(100, rev.score + 10);
    refreshTradeRoutes(state);
    return { ok: true, message: `Trade Agreement established with ${them.name}.` };
  }

  if (action === 'non_aggression') {
    if (rel.score < -15) return { ok: false, message: 'Relations too low for Non-Aggression Pact.' };
    rel.nonAggression = true;
    rev.nonAggression = true;
    rel.score = Math.min(100, rel.score + 10);
    rev.score = Math.min(100, rev.score + 10);
    return { ok: true, message: `Non-Aggression Pact signed with ${them.name}.` };
  }

  if (action === 'defensive_pact') {
    if (rel.score < 15) return { ok: false, message: `Need +15 Relations for Defensive Pact (currently ${rel.score}).` };
    rel.defensivePact = true;
    rev.defensivePact = true;
    rel.score = Math.min(100, rel.score + 12);
    rev.score = Math.min(100, rev.score + 12);
    return { ok: true, message: `Defensive Pact formed with ${them.name}.` };
  }

  if (action === 'alliance') {
    if (rel.score < 30) return { ok: false, message: `Need +30 Relations for Full Alliance (currently ${rel.score}).` };
    rel.alliance = true;
    rev.alliance = true;
    rel.defensivePact = true;
    rev.defensivePact = true;
    rel.score = Math.min(100, rel.score + 15);
    rev.score = Math.min(100, rev.score + 15);
    return { ok: true, message: `Grand Alliance ratified with ${them.name}!` };
  }

  if (action === 'exchange') {
    if (me.resources.gold < 80) return { ok: false, message: 'Requires 80 Gold for commodity barter.' };
    me.resources.gold -= 80;
    me.resources.iron += 45;
    me.resources.wood += 45;
    them.resources.gold += 80;
    rel.score = Math.min(100, rel.score + 6);
    rev.score = Math.min(100, rev.score + 6);
    return { ok: true, message: `Exchanged 80 Gold for 45 Iron & 45 Wood with ${them.name}.` };
  }

  return { ok: false, message: 'Unknown diplomatic action.' };
}

export function cmdMarketTrade(
  state: GameState,
  nationId: string,
  resource: 'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil',
  side: 'buy' | 'sell',
  amount: number
): { ok: boolean; error?: string } {
  const nation = state.nations[nationId];
  if (!nation || amount <= 0) return { ok: false, error: 'Invalid trade.' };
  const price = state.market.prices[resource];
  if (side === 'buy') {
    const cost = Math.ceil(price * amount);
    if (nation.resources.gold < cost) return { ok: false, error: `Need ${cost} Gold.` };
    nation.resources.gold -= cost;
    nation.resources[resource] = Math.min(nation.storageCaps[resource], nation.resources[resource] + amount);
    state.market.prices[resource] = Number((price * 1.03).toFixed(2));
  } else {
    if (nation.resources[resource] < amount) return { ok: false, error: `Insufficient ${resource}.` };
    const rev = Math.floor(price * amount * 0.9);
    nation.resources[resource] -= amount;
    nation.resources.gold += rev;
    state.market.prices[resource] = Number(Math.max(0.5, price * 0.97).toFixed(2));
  }
  return { ok: true };
}

export function cmdChangeGovernment(
  state: GameState,
  nationId: string,
  govId: GovernmentType
): { ok: boolean; error?: string } {
  const nation = state.nations[nationId];
  const gov = GOVERNMENTS[govId];
  if (!nation || !gov) return { ok: false, error: 'Invalid government.' };
  if (gov.requiredTech && !nation.unlockedTechs.includes(gov.requiredTech)) {
    return { ok: false, error: `Requires ${TECH_BY_ID[gov.requiredTech]?.name ?? gov.requiredTech}.` };
  }
  if (nation.resources.influence < 40) return { ok: false, error: 'Requires 40 Influence to reform government.' };
  nation.resources.influence -= 40;
  nation.government = govId;
  return { ok: true };
}

export function cmdTogglePolicy(
  state: GameState,
  nationId: string,
  policyId: string
): { ok: boolean; error?: string } {
  const nation = state.nations[nationId];
  const pol = POLICY_BY_ID[policyId];
  if (!nation || !pol) return { ok: false, error: 'Invalid policy.' };
  if (nation.activePolicies.includes(policyId)) {
    nation.activePolicies = nation.activePolicies.filter((p) => p !== policyId);
    return { ok: true };
  }
  if (nation.resources.influence < pol.costInfluence) {
    return { ok: false, error: `Requires ${pol.costInfluence} Influence.` };
  }
  nation.resources.influence -= pol.costInfluence;
  nation.activePolicies.push(policyId);
  return { ok: true };
}

export function cmdUpdateBudget(
  state: GameState,
  nationId: string,
  patch: Partial<BudgetSettings>
): void {
  const nation = state.nations[nationId];
  if (!nation) return;
  nation.budget = { ...nation.budget, ...patch };
}

export function cmdResolveEvent(state: GameState, choiceId: string): void {
  resolvePendingEventChoice(state, choiceId);
}

export function getFirstUnlockedTechAvailable(nation: GameState['nations'][string]): string | null {
  const avail = TECHNOLOGIES.find(
    (t) => !nation.unlockedTechs.includes(t.id) && t.prerequisites.every((p) => nation.unlockedTechs.includes(p))
  );
  return avail?.id ?? null;
}
