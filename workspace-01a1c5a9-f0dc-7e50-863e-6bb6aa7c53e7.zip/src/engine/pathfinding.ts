import { TERRAINS } from '../data/terrains';
import { GameState } from '../types/game';

export function findLandPath(
  state: GameState,
  fromId: string,
  toId: string,
  nationId: string,
  allowEnemyOrWildernessDestination = true
): string[] | null {
  if (fromId === toId) return [fromId];
  const start = state.territories[fromId];
  const goal = state.territories[toId];
  if (!start || !goal || goal.isWater) return null;

  const nation = state.nations[nationId];
  const canPassThrough = (tid: string): boolean => {
    const t = state.territories[tid];
    if (!t || t.isWater) return false;
    if (tid === toId && allowEnemyOrWildernessDestination) return true;
    if (t.ownerId === nationId) return true;
    if (t.ownerId && nation?.relations[t.ownerId]?.alliance) return true;
    return false;
  };

  if (!canPassThrough(toId)) return null;

  const open = new Set<string>([fromId]);
  const cameFrom: Record<string, string> = {};
  const gScore: Record<string, number> = { [fromId]: 0 };
  const fScore: Record<string, number> = {
    [fromId]: Math.hypot(goal.center.x - start.center.x, goal.center.y - start.center.y),
  };

  while (open.size > 0) {
    let current = '';
    let bestF = Infinity;
    for (const id of open) {
      if ((fScore[id] ?? Infinity) < bestF) {
        bestF = fScore[id];
        current = id;
      }
    }
    if (!current) break;
    if (current === toId) {
      const path = [current];
      while (cameFrom[current]) {
        current = cameFrom[current];
        path.unshift(current);
      }
      return path;
    }

    open.delete(current);
    const curT = state.territories[current];
    for (const nid of curT.landNeighbors) {
      if (!canPassThrough(nid)) continue;
      const nb = state.territories[nid];
      const dist = Math.hypot(nb.center.x - curT.center.x, nb.center.y - curT.center.y);
      const cost = dist * TERRAINS[nb.terrain].movementCost;
      const tentative = (gScore[current] ?? Infinity) + cost;
      if (tentative < (gScore[nid] ?? Infinity)) {
        cameFrom[nid] = current;
        gScore[nid] = tentative;
        fScore[nid] = tentative + Math.hypot(goal.center.x - nb.center.x, goal.center.y - nb.center.y);
        open.add(nid);
      }
    }
  }
  return null;
}

/**
 * Naval A* pathfinding strictly through water territories (and optional starting/ending friendly coastal ports).
 * Ships CANNOT cross land territories.
 */
export function findNavalPath(
  state: GameState,
  fromId: string,
  toId: string,
  allowCoastalEndpoints = true
): string[] | null {
  if (fromId === toId) return [fromId];
  const start = state.territories[fromId];
  const goal = state.territories[toId];
  if (!start || !goal) return null;
  if (!goal.isWater && !(allowCoastalEndpoints && goal.isCoastal)) return null;

  const isNavigable = (tid: string): boolean => {
    const t = state.territories[tid];
    if (!t) return false;
    if (t.isWater) return true;
    if (allowCoastalEndpoints && (tid === fromId || tid === toId) && t.isCoastal) return true;
    return false;
  };

  if (!isNavigable(fromId) || !isNavigable(toId)) return null;

  const open = new Set<string>([fromId]);
  const cameFrom: Record<string, string> = {};
  const gScore: Record<string, number> = { [fromId]: 0 };
  const fScore: Record<string, number> = {
    [fromId]: Math.hypot(goal.center.x - start.center.x, goal.center.y - start.center.y),
  };

  while (open.size > 0) {
    let current = '';
    let bestF = Infinity;
    for (const id of open) {
      if ((fScore[id] ?? Infinity) < bestF) {
        bestF = fScore[id];
        current = id;
      }
    }
    if (!current) break;
    if (current === toId) {
      const path = [current];
      while (cameFrom[current]) {
        current = cameFrom[current];
        path.unshift(current);
      }
      return path;
    }

    open.delete(current);
    const curT = state.territories[current];
    for (const nid of curT.neighbors) {
      if (!isNavigable(nid)) continue;
      // Only allow stepping onto a coastal land cell if it's the destination (never transit over land!)
      const nb = state.territories[nid];
      if (!nb.isWater && nid !== toId) continue;
      const dist = Math.hypot(nb.center.x - curT.center.x, nb.center.y - curT.center.y);
      const stormMult = nb.weatherStorm ? 1.55 : 1.0;
      const tentative = (gScore[current] ?? Infinity) + dist * stormMult;
      if (tentative < (gScore[nid] ?? Infinity)) {
        cameFrom[nid] = current;
        gScore[nid] = tentative;
        fScore[nid] = tentative + Math.hypot(goal.center.x - nb.center.x, goal.center.y - nb.center.y);
        open.add(nid);
      }
    }
  }
  return null;
}
