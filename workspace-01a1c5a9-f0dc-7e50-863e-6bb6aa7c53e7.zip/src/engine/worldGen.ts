import {
  AI_CIVILIZATION_TEMPLATES,
  RIVER_NAMES,
  TERRITORY_PREFIXES,
  TERRITORY_ROOTS,
  TERRITORY_SUFFIXES_BY_TERRAIN,
} from '../data/civilizations';
import { ERAS } from '../data/eras';
import { TECHNOLOGIES } from '../data/technologies';
import { TERRAINS } from '../data/terrains';
import {
  Army,
  City,
  EraId,
  Fleet,
  GameConfig,
  GameState,
  LakeFeature,
  LandTerrainType,
  Nation,
  Point2D,
  ResourceDeposit,
  ResourcePool,
  RiverPath,
  Territory,
} from '../types/game';
import { mulberry32, Noise2D } from './noise';

export function emptyResourcePool(initVal = 0): ResourcePool {
  return {
    gold: initVal,
    food: initVal,
    wood: initVal,
    stone: initVal,
    iron: initVal,
    coal: initVal,
    oil: initVal,
    science: initVal,
    culture: initVal,
    influence: initVal,
    energy: initVal,
  };
}

function clipPolygonHalfPlane(poly: Point2D[], px: number, py: number, nx: number, ny: number): Point2D[] {
  if (poly.length === 0) return [];
  const out: Point2D[] = [];
  const dot = (a: Point2D) => (a.x - px) * nx + (a.y - py) * ny;
  for (let i = 0; i < poly.length; i++) {
    const cur = poly[i];
    const prev = poly[(i + poly.length - 1) % poly.length];
    const dc = dot(cur);
    const dp = dot(prev);
    const curIn = dc <= 1e-6;
    const prevIn = dp <= 1e-6;
    if (curIn !== prevIn) {
      const t = dp / (dp - dc);
      out.push({
        x: prev.x + t * (cur.x - prev.x),
        y: prev.y + t * (cur.y - prev.y),
      });
    }
    if (curIn) out.push(cur);
  }
  return out;
}

function polygonCentroid(poly: Point2D[]): Point2D {
  if (poly.length === 0) return { x: 0, y: 0 };
  let area = 0;
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const f = a.x * b.y - b.x * a.y;
    area += f;
    cx += (a.x + b.x) * f;
    cy += (a.y + b.y) * f;
  }
  if (Math.abs(area) < 1e-5) {
    const sx = poly.reduce((acc, p) => acc + p.x, 0) / poly.length;
    const sy = poly.reduce((acc, p) => acc + p.y, 0) / poly.length;
    return { x: sx, y: sy };
  }
  area *= 0.5;
  return { x: cx / (6 * area), y: cy / (6 * area) };
}

function computeVoronoiCells(sites: Point2D[], width: number, height: number): Point2D[][] {
  const cells: Point2D[][] = [];
  for (let i = 0; i < sites.length; i++) {
    let poly: Point2D[] = [
      { x: 0, y: 0 },
      { x: width, y: 0 },
      { x: width, y: height },
      { x: 0, y: height },
    ];
    const si = sites[i];
    const sorted = sites
      .map((s, idx) => ({ idx, s, distSq: (s.x - si.x) ** 2 + (s.y - si.y) ** 2 }))
      .filter((o) => o.idx !== i)
      .sort((a, b) => a.distSq - b.distSq);

    for (const other of sorted) {
      let maxR2 = 0;
      for (const v of poly) {
        const d2 = (v.x - si.x) ** 2 + (v.y - si.y) ** 2;
        if (d2 > maxR2) maxR2 = d2;
      }
      if (other.distSq > 4.2 * maxR2 && poly.length > 0) break;

      const mx = (si.x + other.s.x) * 0.5;
      const my = (si.y + other.s.y) * 0.5;
      const nx = other.s.x - si.x;
      const ny = other.s.y - si.y;
      poly = clipPolygonHalfPlane(poly, mx, my, nx, ny);
      if (poly.length < 3) break;
    }
    cells.push(poly);
  }
  return cells;
}

function snapKey(p: Point2D): string {
  return `${Math.round(p.x * 2)}:${Math.round(p.y * 2)}`;
}

function edgeKey(a: Point2D, b: Point2D): string {
  const ka = snapKey(a);
  const kb = snapKey(b);
  return ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
}

function hashEdge(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function subdivideEdge(a: Point2D, b: Point2D, edgeNoise: Noise2D, worldWidth: number, worldHeight: number): Point2D[] {
  const onBoundary =
    (Math.abs(a.x) < 1 && Math.abs(b.x) < 1) ||
    (Math.abs(a.x - worldWidth) < 1 && Math.abs(b.x - worldWidth) < 1) ||
    (Math.abs(a.y) < 1 && Math.abs(b.y) < 1) ||
    (Math.abs(a.y - worldHeight) < 1 && Math.abs(b.y - worldHeight) < 1);
  if (onBoundary) return [a, b];

  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy);
  if (len < 16) return [a, b];

  const segments = Math.min(8, Math.max(3, Math.floor(len / 22)));
  const nx = -dy / len;
  const ny = dx / len;
  const ka = snapKey(a);
  const kb = snapKey(b);
  const forward = ka <= kb;

  const pts: Point2D[] = [a];
  const amp = Math.min(26, len * 0.16);
  const seedShift = (hashEdge(edgeKey(a, b)) % 1000) * 0.013;

  for (let s = 1; s < segments; s++) {
    const t = s / segments;
    const u = forward ? t : 1 - t;
    const px = a.x + dx * t;
    const py = a.y + dy * t;
    const envelope = Math.sin(Math.PI * t);
    const wave =
      edgeNoise.noise(px * 0.018 + seedShift, py * 0.018 - seedShift) * 0.75 +
      edgeNoise.noise(u * 4.5 + seedShift, seedShift * 2.1) * 0.45;
    const offset = wave * amp * envelope;
    pts.push({
      x: Math.max(0, Math.min(worldWidth, px + nx * offset)),
      y: Math.max(0, Math.min(worldHeight, py + ny * offset)),
    });
  }
  pts.push(b);
  return pts;
}

export function generateWorld(config: GameConfig): GameState {
  const rand = mulberry32(config.seed);
  const elevNoise = new Noise2D(config.seed + 101);
  const moistNoise = new Noise2D(config.seed + 202);
  const detailNoise = new Noise2D(config.seed + 303);
  const edgeNoise = new Noise2D(config.seed + 404);

  const dims =
    config.mapSize === 'small'
      ? { w: 2000, h: 1200, count: 132 }
      : config.mapSize === 'large'
        ? { w: 2800, h: 1650, count: 270 }
        : { w: 2400, h: 1400, count: 196 };

  const { w: worldWidth, h: worldHeight, count: siteCount } = dims;

  // 1. Stratified jittered site placement + 2 passes of Lloyd relaxation for balanced organic regions
  const cols = Math.round(Math.sqrt((siteCount * worldWidth) / worldHeight));
  const rows = Math.round(siteCount / cols);
  let sites: Point2D[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cellW = worldWidth / cols;
      const cellH = worldHeight / rows;
      sites.push({
        x: (c + 0.18 + rand() * 0.64) * cellW,
        y: (r + 0.18 + rand() * 0.64) * cellH,
      });
    }
  }

  let rawCells = computeVoronoiCells(sites, worldWidth, worldHeight);
  for (let pass = 0; pass < 2; pass++) {
    sites = rawCells.map((cell, idx) => (cell.length >= 3 ? polygonCentroid(cell) : sites[idx]));
    rawCells = computeVoronoiCells(sites, worldWidth, worldHeight);
  }

  // 2. Build topological adjacency from shared straight Voronoi edges BEFORE organic edge perturbation
  const edgeOwners = new Map<string, number[]>();
  for (let i = 0; i < rawCells.length; i++) {
    const poly = rawCells[i];
    for (let j = 0; j < poly.length; j++) {
      const a = poly[j];
      const b = poly[(j + 1) % poly.length];
      const ek = edgeKey(a, b);
      const arr = edgeOwners.get(ek) ?? [];
      if (!arr.includes(i)) arr.push(i);
      edgeOwners.set(ek, arr);
    }
  }

  const neighborSets: Set<number>[] = rawCells.map(() => new Set<number>());
  for (const owners of edgeOwners.values()) {
    if (owners.length === 2) {
      neighborSets[owners[0]].add(owners[1]);
      neighborSets[owners[1]].add(owners[0]);
    }
  }

  // 3. Perturb every polygon edge identically for both sides so borders are irregular & watertight
  const organicPolys: Point2D[][] = rawCells.map((poly) => {
    const out: Point2D[] = [];
    for (let j = 0; j < poly.length; j++) {
      const a = poly[j];
      const b = poly[(j + 1) % poly.length];
      const sub = subdivideEdge(a, b, edgeNoise, worldWidth, worldHeight);
      for (let k = 0; k < sub.length - 1; k++) {
        out.push(sub[k]);
      }
    }
    return out;
  });

  // 4. Tectonic Continent Shaping Function
  const continentCenters: Array<{ x: number; y: number; rx: number; ry: number; weight: number }> = [];
  if (config.terrainStyle === 'pangaea') {
    continentCenters.push({ x: worldWidth * 0.5, y: worldHeight * 0.5, rx: worldWidth * 0.36, ry: worldHeight * 0.36, weight: 0.72 });
    continentCenters.push({ x: worldWidth * 0.25, y: worldHeight * 0.65, rx: worldWidth * 0.14, ry: worldHeight * 0.16, weight: 0.38 });
  } else if (config.terrainStyle === 'archipelago') {
    for (let i = 0; i < 8; i++) {
      continentCenters.push({
        x: worldWidth * (0.14 + rand() * 0.72),
        y: worldHeight * (0.16 + rand() * 0.68),
        rx: worldWidth * (0.09 + rand() * 0.08),
        ry: worldHeight * (0.1 + rand() * 0.09),
        weight: 0.52 + rand() * 0.18,
      });
    }
  } else {
    // Realistic multi-continent world (Western, Eastern, Southern continents + islands)
    continentCenters.push({ x: worldWidth * 0.27, y: worldHeight * 0.44, rx: worldWidth * 0.19, ry: worldHeight * 0.29, weight: 0.66 });
    continentCenters.push({ x: worldWidth * 0.69, y: worldHeight * 0.41, rx: worldWidth * 0.22, ry: worldHeight * 0.28, weight: 0.68 });
    continentCenters.push({ x: worldWidth * 0.52, y: worldHeight * 0.75, rx: worldWidth * 0.16, ry: worldHeight * 0.16, weight: 0.55 });
    continentCenters.push({ x: worldWidth * 0.85, y: worldHeight * 0.72, rx: worldWidth * 0.09, ry: worldHeight * 0.11, weight: 0.48 });
  }

  const sampleGeography = (x: number, y: number) => {
    const nx = x / worldWidth;
    const ny = y / worldHeight;
    let plate = -0.35;
    for (const c of continentCenters) {
      const dx = (x - c.x) / c.rx;
      const dy = (y - c.y) / c.ry;
      const d = Math.sqrt(dx * dx + dy * dy);
      const falloff = Math.max(0, 1 - d * d * 0.82);
      plate = Math.max(plate, falloff * c.weight - 0.18);
    }
    // Keep outer ocean frame navigable around map margins
    const edgePad = Math.min(nx, 1 - nx, ny, 1 - ny);
    const oceanMargin = edgePad < 0.055 ? -0.45 * (1 - edgePad / 0.055) : 0;

    const ridge = 1 - Math.abs(elevNoise.fbm(x * 0.0028, y * 0.0028, 4));
    const n = elevNoise.fbm(x * 0.0022, y * 0.0022, 5);
    const elevation = plate + n * 0.48 + (ridge > 0.76 ? (ridge - 0.76) * 1.15 : 0) + oceanMargin;
    const moisture = 0.5 + moistNoise.fbm(x * 0.0025 + 17.3, y * 0.0025 - 9.1, 4) * 0.75;
    return { elevation, moisture };
  };

  // Compute elevation per territory & tune sea level so ~55-60% of cells are land
  const rawGeo = sites.map((s) => sampleGeography(s.x, s.y));
  const sortedElevs = [...rawGeo.map((g) => g.elevation)].sort((a, b) => a - b);
  const targetWaterFrac = config.terrainStyle === 'archipelago' ? 0.48 : config.terrainStyle === 'pangaea' ? 0.36 : 0.42;
  const seaLevel = sortedElevs[Math.floor(sortedElevs.length * targetWaterFrac)] ?? 0;

  const usedNames = new Set<string>();
  const makeTerritoryName = (terrain: string): string => {
    for (let attempt = 0; attempt < 30; attempt++) {
      const usePrefix = rand() < 0.42;
      const prefix = TERRITORY_PREFIXES[Math.floor(rand() * TERRITORY_PREFIXES.length)];
      const root = TERRITORY_ROOTS[Math.floor(rand() * TERRITORY_ROOTS.length)];
      const suffixes = TERRITORY_SUFFIXES_BY_TERRAIN[terrain] ?? ['Region'];
      const suffix = suffixes[Math.floor(rand() * suffixes.length)];
      const name = usePrefix && attempt < 15 ? `${prefix} ${root} ${suffix}` : `${root} ${suffix}`;
      if (!usedNames.has(name)) {
        usedNames.add(name);
        return name;
      }
    }
    const fallback = `Province ${usedNames.size + 1}`;
    usedNames.add(fallback);
    return fallback;
  };

  const resourceMult = config.resourceAbundance === 'scarce' ? 0.65 : config.resourceAbundance === 'abundant' ? 1.45 : 1.0;

  const territories: Record<string, Territory> = {};
  const territoryIds: string[] = [];

  for (let i = 0; i < rawCells.length; i++) {
    const id = `t_${i}`;
    territoryIds.push(id);
    const center = sites[i];
    const { elevation, moisture } = rawGeo[i];
    const relElev = elevation - seaLevel;
    const isWater = relElev < 0;
    const latDist = Math.abs(center.y / worldHeight - 0.5) * 2; // 0 equator .. 1 poles

    let terrain: Territory['terrain'] = 'plains';
    if (isWater) {
      terrain = 'ocean';
    } else if (latDist > 0.85 || (latDist > 0.72 && relElev > 0.16)) {
      terrain = 'snow';
    } else if (latDist > 0.7) {
      terrain = relElev > 0.28 ? 'mountains' : 'tundra';
    } else if (relElev > 0.32) {
      terrain = 'mountains';
    } else if (relElev > 0.19) {
      terrain = 'hills';
    } else if (moisture < 0.33 && latDist < 0.52) {
      terrain = 'desert';
    } else if (moisture > 0.58) {
      terrain = 'forest';
    } else if (moisture > 0.45) {
      terrain = 'grassland';
    } else {
      terrain = 'plains';
    }

    const tDef = TERRAINS[terrain];
    const deposits: ResourceDeposit[] = [];
    if (!isWater) {
      const roll = () => rand() < 0.32 * resourceMult;
      if ((terrain === 'hills' || terrain === 'mountains') && rand() < 0.55 * resourceMult) {
        deposits.push({ resource: 'iron', richness: rand() < 0.28 ? 2 : 1 });
      }
      if ((terrain === 'hills' || terrain === 'mountains' || terrain === 'tundra') && rand() < 0.38 * resourceMult) {
        deposits.push({ resource: 'coal', richness: rand() < 0.25 ? 2 : 1 });
      }
      if ((terrain === 'desert' || terrain === 'tundra' || terrain === 'snow') && rand() < 0.42 * resourceMult) {
        deposits.push({ resource: 'oil', richness: rand() < 0.32 ? 2 : 1 });
      }
      if ((terrain === 'mountains' || terrain === 'hills') && rand() < 0.45 * resourceMult) {
        deposits.push({ resource: 'stone', richness: 2 });
      }
      if ((terrain === 'mountains' || terrain === 'desert' || terrain === 'plains') && rand() < 0.18 * resourceMult) {
        deposits.push({ resource: 'gold', richness: rand() < 0.3 ? 2 : 1 });
      }
      if (terrain === 'forest' && roll()) {
        deposits.push({ resource: 'wood', richness: 2 });
      }
      if ((terrain === 'grassland' || terrain === 'plains') && roll()) {
        deposits.push({ resource: 'food', richness: 2 });
      }
    }

    const neighbors = Array.from(neighborSets[i]).map((n) => `t_${n}`);
    const strategicValue = Math.min(
      10,
      Math.max(1, Math.round(2 + deposits.length * 2 + (terrain === 'mountains' ? 2 : terrain === 'grassland' ? 1 : 0)))
    );

    territories[id] = {
      id,
      name: makeTerritoryName(terrain),
      isWater,
      terrain,
      center,
      polygon: organicPolys[i],
      neighbors,
      landNeighbors: [],
      seaNeighbors: [],
      riverBorderNeighbors: [],
      isCoastal: false,
      hasRiver: false,
      elevation: relElev,
      moisture,
      continentId: 0,
      deposits,
      populationCapacity: Math.round(tDef.basePopulationCap * (0.85 + rand() * 0.35)),
      strategicValue,
      conquestDifficulty: Math.min(10, tDef.baseConquestDifficulty + Math.floor(deposits.length / 2)),
      ownerId: null,
      wildernessGarrison: isWater ? 0 : Math.round(28 + tDef.baseConquestDifficulty * 9 + rand() * 25),
      fortLevel: 0,
      hasBridge: false,
      cityId: null,
      blockadedByNationId: null,
      occupationUnrest: 0,
      weatherStorm: false,
    };
  }

  // 5. Refine landNeighbors, seaNeighbors, coastal flags, coastal_water classification
  for (const id of territoryIds) {
    const t = territories[id];
    t.landNeighbors = t.neighbors.filter((nid) => !territories[nid].isWater);
    t.seaNeighbors = t.neighbors.filter((nid) => territories[nid].isWater);
    if (!t.isWater && t.seaNeighbors.length > 0) {
      t.isCoastal = true;
      t.strategicValue = Math.min(10, t.strategicValue + 2);
    }
    if (t.isWater && t.landNeighbors.length > 0) {
      t.terrain = 'coastal_water';
      t.name = makeTerritoryName('coastal_water');
    }
  }

  // 6. Assign continent IDs via BFS on land territories
  let currentContinent = 1;
  for (const id of territoryIds) {
    const t = territories[id];
    if (t.isWater || t.continentId !== 0) continue;
    const queue = [id];
    t.continentId = currentContinent;
    while (queue.length > 0) {
      const cur = queue.shift()!;
      for (const nid of territories[cur].landNeighbors) {
        if (territories[nid].continentId === 0) {
          territories[nid].continentId = currentContinent;
          queue.push(nid);
        }
      }
    }
    currentContinent++;
  }

  // 7. Generate Rivers flowing from mountain/hill heads toward sea or inland lakes
  const rivers: RiverPath[] = [];
  const lakes: LakeFeature[] = [];
  const highHeads = territoryIds
    .filter((id) => !territories[id].isWater && (territories[id].terrain === 'mountains' || territories[id].terrain === 'hills'))
    .sort((a, b) => territories[b].elevation - territories[a].elevation);

  const riverCount = config.mapSize === 'small' ? 5 : config.mapSize === 'large' ? 10 : 7;
  const usedRiverStart = new Set<string>();

  for (let r = 0; r < Math.min(riverCount, highHeads.length); r++) {
    const startHead: string | undefined = highHeads.find(
      (id) => !usedRiverStart.has(id) && territories[id].landNeighbors.some((n) => !usedRiverStart.has(n))
    );
    if (!startHead) break;
    let curId: string = startHead;
    usedRiverStart.add(curId);
    const pts: Point2D[] = [{ ...territories[curId].center }];
    const visited = new Set<string>([curId]);

    for (let step = 0; step < 8; step++) {
      const cur: Territory = territories[curId];
      // Prefer water neighbor to terminate at coast
      const waterNb = cur.seaNeighbors[0];
      if (waterNb) {
        const wCenter = territories[waterNb].center;
        pts.push({
          x: (cur.center.x + wCenter.x) * 0.5,
          y: (cur.center.y + wCenter.y) * 0.5,
        });
        break;
      }
      const nextCandidates: string[] = cur.landNeighbors
        .filter((nid) => !visited.has(nid))
        .sort((a, b) => territories[a].elevation - territories[b].elevation);

      if (nextCandidates.length === 0) {
        // Terminate in an inland lake!
        const lakePoly: Point2D[] = [];
        const lr = 16 + rand() * 12;
        for (let k = 0; k < 10; k++) {
          const ang = (Math.PI * 2 * k) / 10;
          const rad = lr * (0.78 + rand() * 0.42);
          lakePoly.push({
            x: cur.center.x + Math.cos(ang) * rad,
            y: cur.center.y + Math.sin(ang) * rad,
          });
        }
        lakes.push({
          id: `lake_${lakes.length}`,
          name: `Lake ${TERRITORY_ROOTS[Math.floor(rand() * TERRITORY_ROOTS.length)]}`,
          center: { ...cur.center },
          polygon: lakePoly,
        });
        break;
      }

      const nextId = nextCandidates[0];
      visited.add(nextId);
      usedRiverStart.add(nextId);
      const nxt = territories[nextId];

      // Mark river border & river agricultural benefits
      cur.hasRiver = true;
      nxt.hasRiver = true;
      if (!cur.riverBorderNeighbors.includes(nextId)) cur.riverBorderNeighbors.push(nextId);
      if (!nxt.riverBorderNeighbors.includes(curId)) nxt.riverBorderNeighbors.push(curId);

      // Add organic midpoint curve
      const midX = (cur.center.x + nxt.center.x) * 0.5 + detailNoise.noise(cur.center.x * 0.01, nxt.center.y * 0.01) * 18;
      const midY = (cur.center.y + nxt.center.y) * 0.5 + detailNoise.noise(nxt.center.x * 0.01, cur.center.y * 0.01) * 18;
      pts.push({ x: midX, y: midY });
      pts.push({ ...nxt.center });
      curId = nextId;
    }

    if (pts.length >= 2) {
      rivers.push({
        id: `river_${rivers.length}`,
        name: RIVER_NAMES[rivers.length % RIVER_NAMES.length],
        points: pts,
        width: 2.5 + rand() * 1.8,
      });
    }
  }

  // 8. Pick well-spaced habitable starting spots for Player + AI Civilizations
  const habitable = territoryIds.filter(
    (id) =>
      !territories[id].isWater &&
      territories[id].terrain !== 'mountains' &&
      territories[id].terrain !== 'snow' &&
      territories[id].landNeighbors.length >= 2
  );
  // Prefer fertile coastal/plains/grassland starts
  habitable.sort((a, b) => {
    const score = (id: string) => {
      const t = territories[id];
      let s = 0;
      if (t.terrain === 'grassland' || t.terrain === 'plains') s += 4;
      if (t.isCoastal) s += 3;
      if (t.hasRiver) s += 2;
      s += t.landNeighbors.length * 0.5;
      return s;
    };
    return score(b) - score(a);
  });

  const totalNations = 1 + Math.min(config.aiCount, AI_CIVILIZATION_TEMPLATES.length);
  const chosenStarts: string[] = [];
  const minDist = Math.min(worldWidth, worldHeight) / Math.max(2.6, Math.sqrt(totalNations) * 1.05);

  for (let passDist = minDist; chosenStarts.length < totalNations && passDist >= 70; passDist *= 0.72) {
    for (const id of habitable) {
      if (chosenStarts.includes(id)) continue;
      const c = territories[id].center;
      const farEnough = chosenStarts.every((sid) => {
        const sc = territories[sid].center;
        return Math.hypot(c.x - sc.x, c.y - sc.y) >= passDist;
      });
      if (farEnough) {
        chosenStarts.push(id);
        if (chosenStarts.length >= totalNations) break;
      }
    }
  }

  const startEraOrder = ERAS.find((e) => e.id === config.startingEra)?.order ?? 0;
  const getStartingTechsForEra = (era: EraId): string[] => {
    const targetOrder = ERAS.find((e) => e.id === era)?.order ?? 0;
    return TECHNOLOGIES.filter((tech) => {
      const to = ERAS.find((e) => e.id === tech.era)?.order ?? 0;
      return to < targetOrder;
    }).map((t) => t.id);
  };

  const eraYearMap: Record<EraId, number> = {
    ancient: -4000,
    classical: -500,
    medieval: 600,
    renaissance: 1480,
    industrial: 1780,
    modern: 1930,
    future: 2040,
  };

  const nations: Record<string, Nation> = {};
  const cities: Record<string, City> = {};
  const armies: Record<string, Army> = {};
  const fleets: Record<string, Fleet> = {};
  let seq = 1;

  const createNationWithCapital = (
    nationId: string,
    opts: {
      name: string;
      adjective: string;
      leaderName: string;
      color: string;
      secondaryColor: string;
      emblem: Nation['emblem'];
      isPlayer: boolean;
      personality: Nation['aiPersonality'];
      startTerritoryId: string;
      capitalName: string;
    }
  ) => {
    const unlockedTechs = getStartingTechsForEra(config.startingEra);
    const resMult = config.startingResourcesMultiplier * (opts.isPlayer ? 1 : config.aiDifficulty === 'easy' ? 0.65 : config.aiDifficulty === 'hard' ? 1.25 : 0.9);
    const eraFactor = 1 + startEraOrder * 1.45;

    const resources: ResourcePool = {
      gold: Math.round((280 + startEraOrder * 950) * resMult),
      food: Math.round(200 * resMult * eraFactor),
      wood: Math.round(180 * resMult * eraFactor),
      stone: Math.round(130 * resMult * eraFactor),
      iron: Math.round((startEraOrder >= 1 ? 140 * eraFactor : 35) * resMult),
      coal: Math.round((startEraOrder >= 3 ? 110 * eraFactor : 15) * resMult),
      oil: Math.round((startEraOrder >= 5 ? 240 * eraFactor : 5) * resMult),
      science: 0,
      culture: Math.round((40 + startEraOrder * 65) * resMult),
      influence: Math.round((60 + startEraOrder * 55) * resMult),
      energy: Math.round(startEraOrder >= 5 ? 320 * eraFactor : startEraOrder >= 4 ? 120 : 10),
    };

    const nation: Nation = {
      id: nationId,
      name: opts.name,
      adjective: opts.adjective,
      leaderName: opts.leaderName,
      color: opts.color,
      secondaryColor: opts.secondaryColor,
      emblem: opts.emblem,
      isPlayer: opts.isPlayer,
      isHumanMultiplayer: opts.isPlayer,
      aiDifficulty: config.aiDifficulty,
      aiPersonality: opts.personality,
      eliminated: false,
      era: config.startingEra,
      government: 'tribal',
      activePolicies: [],
      budget: {
        taxRate: 15,
        militarySpending: 50,
        educationFunding: 50,
        healthcareFunding: 50,
        infrastructureSpending: 50,
        tradeTariff: 10,
      },
      resources,
      ratesPerMin: emptyResourcePool(0),
      consumptionPerMin: emptyResourcePool(0),
      storageCaps: emptyResourcePool(3500),
      territoryProductionBreakdown: emptyResourcePool(0),
      buildingProductionBreakdown: emptyResourcePool(0),
      naturalDepositBreakdown: emptyResourcePool(0),
      unlockedTechs,
      currentTechId: null,
      techProgress: 0,
      techQueue: [],
      techFundedIds: [...unlockedTechs],
      techProgressById: {},
      capitalTerritoryId: opts.startTerritoryId,
      relations: {},
      aiCooldownTick: Math.floor(rand() * 12),
      adminStrain: 0,
      overallHappiness: 78,
      stats: {
        totalBattlesWon: 0,
        totalBattlesLost: 0,
        territoriesConquered: 1,
        nationsEliminated: 0,
        peakTerritories: 1,
        peakPopulation: 2400,
        totalGoldEarned: resources.gold,
        militaryPower: 0,
        navalPower: 0,
        economicScore: 0,
        scienceScore: 0,
        cultureScore: 0,
        diplomaticScore: 0,
      },
    };

    nations[nationId] = nation;

    // Claim starting territory & found Capital City
    const startT = territories[opts.startTerritoryId];
    startT.ownerId = nationId;
    startT.wildernessGarrison = 0;

    // For Normal/Hard AI, grant 1 bonus adjacent territory? Wait: prompt says "Players begin with: One starting settlement. A small amount of territory... AI civilizations should start with relatively small territories."
    // Let's keep every nation starting cleanly with 1 capital territory (or Hard AI gets 1 adjacent wilderness). Actually 1 each on Easy/Normal, 2 on Hard feels crisp and fair!
    if (!opts.isPlayer && config.aiDifficulty === 'hard') {
      const adjWild = startT.landNeighbors.find((nid) => !territories[nid].ownerId);
      if (adjWild) {
        territories[adjWild].ownerId = nationId;
        territories[adjWild].wildernessGarrison = 0;
        nation.stats.territoriesConquered = 2;
      }
    }

    const cityId = `city_${seq++}`;
    const startPop = opts.isPlayer ? 2400 : config.aiDifficulty === 'easy' ? 1600 : config.aiDifficulty === 'hard' ? 2800 : 2100;
    const city: City = {
      id: cityId,
      name: opts.capitalName,
      territoryId: startT.id,
      nationId,
      isCapital: true,
      tier: 1,
      population: startPop,
      housing: 4500,
      foodProduction: 35,
      industrialOutput: 12,
      economicOutput: 24,
      happiness: 80,
      health: 78,
      education: 40 + startEraOrder * 10,
      infrastructure: 25 + startEraOrder * 10,
      security: 75,
      unemploymentRate: 4,
      birthRate: 24,
      deathRate: 10,
      diseaseOutbreak: false,
      buildings: [
        { buildingId: 'farms', level: 1 },
        { buildingId: 'town_halls', level: 1 },
        { buildingId: 'barracks', level: 1 },
      ],
      queue: [],
      occupations: {
        farmers: Math.round(startPop * 0.35),
        miners: Math.round(startPop * 0.14),
        builders: Math.round(startPop * 0.12),
        researchers: Math.round(startPop * 0.1),
        merchants: Math.round(startPop * 0.1),
        factory_workers: 0,
        government_workers: Math.round(startPop * 0.06),
        soldiers: Math.round(startPop * 0.13),
      },
    };
    if (startT.isCoastal) {
      city.buildings.push({ buildingId: 'ports', level: 1 });
    }
    if (startEraOrder >= 1) city.buildings.push({ buildingId: 'libraries', level: 1 });
    if (startEraOrder >= 3) city.buildings.push({ buildingId: 'universities', level: 1 });
    if (startEraOrder >= 4) city.buildings.push({ buildingId: 'research_laboratories', level: 1 });
    if (startEraOrder >= 5) {
      city.buildings.push(
        { buildingId: 'factories', level: 1 },
        { buildingId: 'power_stations', level: 1 },
        { buildingId: 'oil_refineries', level: 1 }
      );
    }
    if (startEraOrder >= 6) city.buildings.push({ buildingId: 'advanced_research_centers', level: 1 });
    cities[cityId] = city;
    startT.cityId = cityId;

    // Starting Army
    const armyId = `army_${seq++}`;
    const startUnitId =
      startEraOrder >= 5
        ? 'modern_infantry'
        : startEraOrder >= 4
          ? 'riflemen'
          : startEraOrder >= 2
            ? 'medieval_infantry'
            : 'ancient_infantry';
    const startCount = opts.isPlayer
      ? 6
      : config.aiDifficulty === 'easy'
        ? 3
        : config.aiDifficulty === 'hard'
          ? 7
          : 5;

    armies[armyId] = {
      id: armyId,
      name: `${opts.adjective} 1st Army`,
      nationId,
      territoryId: startT.id,
      targetTerritoryId: null,
      path: [],
      moveProgress: 0,
      units: [
        { unitId: startUnitId, count: startCount, hp: 100, experience: 10 },
      ],
      supply: 100,
      morale: 92,
      fortified: false,
      embarkedFleetId: null,
      inBattleId: null,
    };
  };

  // Player Nation
  const playerNationId = 'nation_player';
  createNationWithCapital(playerNationId, {
    name: config.playerNationName || 'Dominion Republic',
    adjective: (config.playerNationName || 'Dominion').split(' ')[0],
    leaderName: config.playerLeaderName || 'Commander Valen',
    color: config.playerColor || '#2dd4bf',
    secondaryColor: '#f5d06f',
    emblem: config.playerEmblem || 'eagle',
    isPlayer: true,
    personality: 'expansionist',
    startTerritoryId: chosenStarts[0],
    capitalName: `${(config.playerNationName || 'Dominion').split(' ')[0]} Prime`,
  });

  // AI Nations
  const shuffledTemplates = [...AI_CIVILIZATION_TEMPLATES].sort(() => rand() - 0.5);
  for (let i = 1; i < chosenStarts.length; i++) {
    const tpl = shuffledTemplates[(i - 1) % shuffledTemplates.length];
    createNationWithCapital(`nation_ai_${i}`, {
      name: tpl.name,
      adjective: tpl.adjective,
      leaderName: tpl.leaderName,
      color: tpl.color,
      secondaryColor: tpl.secondaryColor,
      emblem: tpl.emblem,
      isPlayer: false,
      personality: tpl.personality,
      startTerritoryId: chosenStarts[i],
      capitalName: tpl.capitalName,
    });
  }

  // Initialize mutual diplomatic relations
  const allNationIds = Object.keys(nations);
  for (const nid of allNationIds) {
    for (const oid of allNationIds) {
      if (nid === oid) continue;
      nations[nid].relations[oid] = {
        otherNationId: oid,
        score: Math.round((rand() - 0.35) * 30),
        atWar: false,
        tradeAgreement: false,
        nonAggression: false,
        defensivePact: false,
        alliance: false,
        coalitionId: null,
        truceUntilTick: 0,
        lastActionTick: 0,
      };
    }
  }

  const startYear = eraYearMap[config.startingEra] ?? -4000;
  return {
    id: `game_${Date.now()}`,
    name: `${config.playerNationName || 'Dominion'} Campaign`,
    config,
    tick: 0,
    speed: 1,
    year: startYear,
    worldWidth,
    worldHeight,
    territories,
    territoryIds,
    rivers,
    lakes,
    nations,
    playerNationId,
    cities,
    armies,
    fleets,
    battles: {},
    recruitmentQueue: [],
    tradeRoutes: [],
    market: {
      prices: { food: 1.0, wood: 1.2, stone: 1.4, iron: 2.2, coal: 2.6, oil: 3.5 },
      demandTrend: { food: 0, wood: 0, stone: 0, iron: 0, coal: 0, oil: 0 },
    },
    timeline: [
      {
        id: `tl_start`,
        tick: 0,
        yearLabel: startYear < 0 ? `${Math.abs(startYear)} BC` : `${startYear} AD`,
        category: 'era',
        title: 'Dawn of Civilization',
        description: `${nations[playerNationId].name} raises its banner in ${territories[chosenStarts[0]].name}.`,
        nationId: playerNationId,
      },
    ],
    notifications: [
      {
        id: 'notif_welcome',
        tick: 0,
        severity: 'info',
        title: 'Campaign Started',
        message: 'Select adjacent unclaimed wilderness or build up your capital to begin expanding your borders.',
        territoryId: chosenStarts[0],
      },
    ],
    pendingEvent: null,
    victory: {
      territorial: { current: 1, target: Math.max(10, Math.round(territoryIds.filter((id) => !territories[id].isWater).length * 0.6)), pct: 0 },
      military: { current: 0, target: 100, pct: 0 },
      economic: { current: 0, target: 15000, pct: 0 },
      scientific: { current: 0, target: TECHNOLOGIES.length, pct: 0 },
      cultural: { current: 0, target: 6000, pct: 0 },
      diplomatic: { current: 0, target: 100, pct: 0 },
      winnerNationId: null,
      victoryType: null,
      continuedAfterVictory: false,
    },
    nextEntitySeq: seq,
  };
}
