import React from 'react';
import { Settings, Volume2, X } from 'lucide-react';
import { GameSettings } from '../types/game';

interface Props {
  settings: GameSettings;
  onChange: (next: GameSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<Props> = ({ settings, onChange, onClose }) => {
  const toggle = (key: keyof GameSettings) => {
    onChange({ ...settings, [key]: !settings[key] });
  };

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" style={{ width: 'min(540px, 92vw)' }} onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <Settings size={20} color="#d4a84f" />
            <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
              Campaign &amp; Display Settings
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Volume2 size={14} color="#d4a84f" /> Sound Effects
              </div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Synthesized strategy clicks, battle horns &amp; conquest chimes</div>
            </div>
            <button className={`dom-btn ${settings.sfxEnabled ? 'dom-btn-emerald' : ''}`} onClick={() => toggle('sfxEnabled')}>
              {settings.sfxEnabled ? 'Enabled' : 'Muted'}
            </button>
          </div>

          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Map Territory &amp; City Labels</div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Display city banners and region names on zoom</div>
            </div>
            <button className={`dom-btn ${settings.showTerritoryLabels ? 'dom-btn-emerald' : ''}`} onClick={() => toggle('showTerritoryLabels')}>
              {settings.showTerritoryLabels ? 'Shown' : 'Hidden'}
            </button>
          </div>

          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Resource Deposit Icons</div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Show Iron, Coal, Oil, Gold, Stone markers on map</div>
            </div>
            <button className={`dom-btn ${settings.showResourceBadges ? 'dom-btn-emerald' : ''}`} onClick={() => toggle('showResourceBadges')}>
              {settings.showResourceBadges ? 'Shown' : 'Hidden'}
            </button>
          </div>

          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Army &amp; Fleet Banners</div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Show unit stacks, ship icons &amp; troop movement paths</div>
            </div>
            <button className={`dom-btn ${settings.showUnitBanners ? 'dom-btn-emerald' : ''}`} onClick={() => toggle('showUnitBanners')}>
              {settings.showUnitBanners ? 'Shown' : 'Hidden'}
            </button>
          </div>

          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Maritime &amp; Land Trade Routes</div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Render golden trade arcs connecting commercial partners</div>
            </div>
            <button className={`dom-btn ${settings.showTradeRoutes ? 'dom-btn-emerald' : ''}`} onClick={() => toggle('showTradeRoutes')}>
              {settings.showTradeRoutes ? 'Shown' : 'Hidden'}
            </button>
          </div>

          <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Interface Scale</div>
              <div style={{ fontSize: 11, color: '#9fb0c7' }}>Adjust typography and HUD readability</div>
            </div>
            <div style={{ display: 'flex', gap: 5 }}>
              {(['compact', 'standard', 'large'] as const).map((sc) => (
                <button
                  key={sc}
                  className={`dom-btn ${settings.uiScale === sc ? 'dom-btn-gold' : ''}`}
                  style={{ textTransform: 'capitalize' }}
                  onClick={() => onChange({ ...settings, uiScale: sc })}
                >
                  {sc}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
