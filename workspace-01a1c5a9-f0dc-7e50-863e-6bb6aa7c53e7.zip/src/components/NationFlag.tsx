import React from 'react';
import { Nation } from '../types/game';

interface Props {
  color: string;
  secondaryColor?: string;
  emblem: Nation['emblem'];
  size?: number;
}

export const NationFlag: React.FC<Props> = ({
  color,
  secondaryColor = '#f2cb77',
  emblem,
  size = 28,
}) => {
  const renderSymbol = () => {
    switch (emblem) {
      case 'crown':
        return <path d="M8 22h16l2-10-5 4-5-6-5 6-5-4 2 10z" fill={secondaryColor} />;
      case 'star':
        return <polygon points="16,6 19,13 26,13 20.5,17.5 22.5,24.5 16,20.2 9.5,24.5 11.5,17.5 6,13 13,13" fill={secondaryColor} />;
      case 'sun':
        return (
          <>
            <circle cx="16" cy="16" r="5" fill={secondaryColor} />
            <path d="M16 5v4M16 23v4M5 16h4M23 16h4M8.5 8.5l2.8 2.8M20.7 20.7l2.8 2.8M23.5 8.5l-2.8 2.8M11.3 20.7l-2.8 2.8" stroke={secondaryColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'anchor':
        return (
          <path
            d="M16 7a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zm0 5v12m-5-9h10m-11 4c0 3.5 2.7 6 6 6s6-2.5 6-6"
            fill="none"
            stroke={secondaryColor}
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        );
      case 'sword':
        return (
          <path d="M23 7l-9 9-2-2-2 2 2 2-4 4 2 2 4-4 2 2 2-2-2-2 9-9V7z" fill={secondaryColor} />
        );
      case 'shield':
        return (
          <path d="M16 7l8 3v6c0 5-3.4 8.5-8 10-4.6-1.5-8-5-8-10v-6l8-3z" fill="none" stroke={secondaryColor} strokeWidth="2.2" />
        );
      case 'crescent':
        return (
          <path d="M19 8a8 8 0 1 0 3 14.5A6.5 6.5 0 1 1 19 8z" fill={secondaryColor} />
        );
      case 'dragon':
        return (
          <path d="M10 22c1-5 4-8 8-9l-2-4 5 2 3 4-4 2c1 3-1 6-4 7l-6-2z" fill={secondaryColor} />
        );
      case 'lion':
        return (
          <path d="M16 7c4 0 7 3 7 7 0 3-2 6-5 7l1 3h-6l1-3c-3-1-5-4-5-7 0-4 3-7 7-7z" fill={secondaryColor} />
        );
      case 'eagle':
      default:
        return (
          <path d="M16 7l3 4 6-2-3 6 3 4-6-1-3 6-3-6-6 1 3-4-3-6 6 2 3-4z" fill={secondaryColor} />
        );
    }
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      style={{
        borderRadius: 4,
        border: '1px solid rgba(212, 168, 79, 0.5)',
        boxShadow: '0 2px 6px rgba(0,0,0,0.45)',
        flexShrink: 0,
      }}
    >
      <defs>
        <linearGradient id={`fg_${color.replace('#', '')}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor="#090d14" stopOpacity="0.85" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" fill={color} />
      <rect width="32" height="32" fill={`url(#fg_${color.replace('#', '')})`} opacity="0.55" />
      <path d="M0 24L32 8v10L0 32z" fill={secondaryColor} opacity="0.16" />
      {renderSymbol()}
    </svg>
  );
};
