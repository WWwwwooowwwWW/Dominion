import React, { useState } from 'react';
import { Globe, Play, Shuffle, X } from 'lucide-react';
import { ERAS } from '../data/eras';
import { AIDifficulty, EraId, GameConfig, MapSize, Nation } from '../types/game';
import { NationFlag } from './NationFlag';

interface Props {
  initialMode: 'singleplayer' | 'custom';
  onLaunch: (config: GameConfig) => void;
  onClose: () => void;
}

const COLORS = ['#2dd4bf', '#3b82f6', '#eab308', '#ef4444', '#a855f7', '#ec4899', '#10b981', '#f97316'];
const EMBLEMS: Nation['emblem'][] = ['eagle', 'crown', 'lion', 'star', 'sun', 'anchor', 'sword', 'dragon', 'shield', 'crescent'];

export const NewGameModal: React.FC<Props> = ({ initialMode, onLaunch, onClose }) => {
  const [playerNationName, setPlayerNationName] = useState('Dominion Empire');
  const [playerLeaderName, setPlayerLeaderName] = useState('Sovereign Valen');
  const [playerColor, setPlayerColor] = useState('#2dd4bf');
  const [playerEmblem, setPlayerEmblem] = useState<Nation['emblem']>('eagle');

  const [mapSize, setMapSize] = useState<MapSize>('medium');
  const [aiCount, setAiCount] = useState(6);
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('easy');
  const [startingEra, setStartingEra] = useState<EraId>('ancient');
  const [terrainStyle, setTerrainStyle] = useState<GameConfig['terrainStyle']>('continents');
  const [resourceAbundance, setResourceAbundance] = useState<GameConfig['resourceAbundance']>('standard');
  const [startingResourcesMultiplier, setStartingResourcesMultiplier] = useState(1.0);
  const [speedMultiplier, setSpeedMultiplier] = useState(1.0);
  const [seed, setSeed] = useState(() => Math.floor(100000 + Math.random() * 899999));

  const start = () => {
    onLaunch({
      mode: initialMode,
      seed,
      mapSize,
      aiCount,
      aiDifficulty,
      startingEra,
      resourceAbundance,
      terrainStyle,
      startingResourcesMultiplier,
      playerNationName: playerNationName.trim() || 'Dominion Empire',
      playerLeaderName: playerLeaderName.trim() || 'Commander',
      playerColor,
      playerEmblem,
      speedMultiplier,
    });
  };

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" style={{ width: 'min(820px, 95vw)' }} onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Globe size={20} color="#d4a84f" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                {initialMode === 'custom' ? 'Custom World & Rules Setup' : 'Single Player Campaign Setup'}
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Forge your civilization banner, configure geography, and enter the world map
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Civilization Customization */}
          <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77' }}>Civilization &amp; National Flag</div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <NationFlag color={playerColor} emblem={playerEmblem} size={56} />
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>Nation Name</label>
                <input
                  className="dom-input"
                  style={{ width: '100%' }}
                  value={playerNationName}
                  onChange={(e) => setPlayerNationName(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>Leader Title &amp; Name</label>
              <input
                className="dom-input"
                style={{ width: '100%' }}
                value={playerLeaderName}
                onChange={(e) => setPlayerLeaderName(e.target.value)}
              />
            </div>

            <div>
              <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 5 }}>National Color</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setPlayerColor(c)}
                    style={{
                      width: 26,
                      height: 26,
                      borderRadius: 5,
                      background: c,
                      border: playerColor === c ? '2.5px solid #f2cb77' : '1px solid #334155',
                      cursor: 'pointer',
                    }}
                  />
                ))}
              </div>
            </div>

            <div>
              <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 5 }}>Heraldic Emblem</label>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                {EMBLEMS.map((emb) => (
                  <button
                    key={emb}
                    className={`dom-btn ${playerEmblem === emb ? 'dom-btn-gold' : ''}`}
                    style={{ padding: '4px 8px', fontSize: 11, textTransform: 'capitalize' }}
                    onClick={() => setPlayerEmblem(emb)}
                  >
                    {emb}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* World & AI Rules */}
          <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77' }}>World Geography &amp; AI Settings</div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>World Size</label>
                <select className="dom-select" style={{ width: '100%' }} value={mapSize} onChange={(e) => setMapSize(e.target.value as MapSize)}>
                  <option value="small">Small (~132 Regions)</option>
                  <option value="medium">Medium (~196 Regions)</option>
                  <option value="large">Massive (~270 Regions)</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>Terrain Layout</label>
                <select
                  className="dom-select"
                  style={{ width: '100%' }}
                  value={terrainStyle}
                  onChange={(e) => setTerrainStyle(e.target.value as GameConfig['terrainStyle'])}
                >
                  <option value="continents">Continents &amp; Seas</option>
                  <option value="archipelago">Archipelago Islands</option>
                  <option value="pangaea">Pangaea Supercontinent</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>AI Difficulty</label>
                <select
                  className="dom-select"
                  style={{ width: '100%' }}
                  value={aiDifficulty}
                  onChange={(e) => setAiDifficulty(e.target.value as AIDifficulty)}
                >
                  <option value="easy">Easy (Accessible Conquest)</option>
                  <option value="normal">Normal (Balanced)</option>
                  <option value="hard">Hard (Active Rivals)</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>AI Opponents ({aiCount})</label>
                <input
                  type="range"
                  min={1}
                  max={12}
                  value={aiCount}
                  onChange={(e) => setAiCount(Number(e.target.value))}
                  style={{ width: '100%', accentColor: '#d4a84f', marginTop: 7 }}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>Starting Era</label>
                <select
                  className="dom-select"
                  style={{ width: '100%' }}
                  value={startingEra}
                  onChange={(e) => setStartingEra(e.target.value as EraId)}
                >
                  {ERAS.map((era) => (
                    <option key={era.id} value={era.id}>
                      {era.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>Resource Abundance</label>
                <select
                  className="dom-select"
                  style={{ width: '100%' }}
                  value={resourceAbundance}
                  onChange={(e) => setResourceAbundance(e.target.value as GameConfig['resourceAbundance'])}
                >
                  <option value="scarce">Scarce</option>
                  <option value="standard">Standard</option>
                  <option value="abundant">Abundant</option>
                </select>
              </div>
            </div>

            {initialMode === 'custom' && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>
                    Starting Treasury ({startingResourcesMultiplier}x)
                  </label>
                  <select
                    className="dom-select"
                    style={{ width: '100%' }}
                    value={startingResourcesMultiplier}
                    onChange={(e) => setStartingResourcesMultiplier(Number(e.target.value))}
                  >
                    <option value={0.75}>0.75x Austere</option>
                    <option value={1.0}>1.0x Standard</option>
                    <option value={1.5}>1.5x Prosperous</option>
                    <option value={2.5}>2.5x Imperial</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>
                    Simulation Pace
                  </label>
                  <select
                    className="dom-select"
                    style={{ width: '100%' }}
                    value={speedMultiplier}
                    onChange={(e) => setSpeedMultiplier(Number(e.target.value))}
                  >
                    <option value={0.8}>Measured (0.8x)</option>
                    <option value={1.0}>Standard (1.0x)</option>
                    <option value={1.5}>Fast (1.5x)</option>
                  </select>
                </div>
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 3 }}>World Seed</label>
                <input
                  className="dom-input font-mono-num"
                  style={{ width: '100%' }}
                  type="number"
                  value={seed}
                  onChange={(e) => setSeed(Number(e.target.value) || 1)}
                />
              </div>
              <button
                className="dom-btn"
                onClick={() => setSeed(Math.floor(100000 + Math.random() * 899999))}
              >
                <Shuffle size={13} /> Randomize
              </button>
            </div>
          </div>
        </div>

        <div style={{ padding: '12px 18px', borderTop: '1px solid #243247', display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button className="dom-btn" onClick={onClose}>
            Cancel
          </button>
          <button className="dom-btn dom-btn-gold" style={{ padding: '9px 22px', fontSize: 13.5 }} onClick={start}>
            <Play size={15} /> Launch Civilization
          </button>
        </div>
      </div>
    </div>
  );
};
