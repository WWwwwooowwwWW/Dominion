import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Anchor,
  Coins,
  Compass,
  Crosshair,
  Layers,
  Map as MapIcon,
  Maximize2,
  Mountain,
  Pickaxe,
  Plus,
  Minus,
  Shield,
  Users,
} from 'lucide-react';
import { TERRAINS } from '../data/terrains';
import { computeArmyPower, computeFleetPower, getArmyTotalUnitCount } from '../engine/combat';
import { GameSettings, GameState, MapOverlayMode, Point2D, Territory } from '../types/game';

interface Props {
  state: GameState;
  overlay: MapOverlayMode;
  onChangeOverlay: (mode: MapOverlayMode) => void;
  selectedTerritoryId: string | null;
  selectedArmyId: string | null;
  selectedFleetId: string | null;
  onSelectTerritory: (id: string) => void;
  onSelectArmy: (id: string | null) => void;
  onSelectFleet: (id: string | null) => void;
  settings: GameSettings;
}

function pointInPolygon(x: number, y: number, poly: Point2D[]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x;
    const yi = poly[i].y;
    const xj = poly[j].x;
    const yj = poly[j].y;
    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

const OVERLAY_OPTIONS: Array<{ id: MapOverlayMode; label: string; icon: React.ReactNode }> = [
  { id: 'political', label: 'Political', icon: <MapIcon size={13} /> },
  { id: 'terrain', label: 'Terrain', icon: <Mountain size={13} /> },
  { id: 'resource', label: 'Resources', icon: <Pickaxe size={13} /> },
  { id: 'military', label: 'Military', icon: <Shield size={13} /> },
  { id: 'naval', label: 'Naval', icon: <Anchor size={13} /> },
  { id: 'population', label: 'Population', icon: <Users size={13} /> },
  { id: 'economic', label: 'Economic', icon: <Coins size={13} /> },
];

export const WorldMapCanvas: React.FC<Props> = ({
  state,
  overlay,
  onChangeOverlay,
  selectedTerritoryId,
  selectedArmyId,
  selectedFleetId,
  onSelectTerritory,
  onSelectArmy,
  onSelectFleet,
  settings,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const terrainOffscreenRef = useRef<HTMLCanvasElement | null>(null);
  const builtWorldIdRef = useRef<string>('');

  const [camera, setCamera] = useState<{ x: number; y: number; zoom: number }>({
    x: state.worldWidth * 0.5,
    y: state.worldHeight * 0.5,
    zoom: 0.55,
  });
  const [hoverTid, setHoverTid] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragRef = useRef<{ active: boolean; moved: boolean; startX: number; startY: number; camX: number; camY: number }>({
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    camX: 0,
    camY: 0,
  });

  const centerOnCapital = useCallback(() => {
    const capId = state.nations[state.playerNationId]?.capitalTerritoryId;
    const cap = capId ? state.territories[capId] : null;
    if (cap) {
      setCamera((c) => ({ ...c, x: cap.center.x, y: cap.center.y, zoom: Math.max(0.82, c.zoom) }));
    }
  }, [state.nations, state.playerNationId, state.territories]);

  const resetView = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const fitZoom = Math.min(el.clientWidth / state.worldWidth, el.clientHeight / state.worldHeight) * 0.96;
    setCamera({
      x: state.worldWidth * 0.5,
      y: state.worldHeight * 0.5,
      zoom: Math.max(0.28, fitZoom),
    });
  }, [state.worldHeight, state.worldWidth]);

  // Center on player's capital on fresh game launch
  useEffect(() => {
    if (builtWorldIdRef.current !== state.id) {
      const capId = state.nations[state.playerNationId]?.capitalTerritoryId;
      const cap = capId ? state.territories[capId] : null;
      if (cap) {
        setCamera({ x: cap.center.x, y: cap.center.y, zoom: 0.8 });
      } else {
        resetView();
      }
    }
  }, [state.id, state.nations, state.playerNationId, state.territories, resetView]);

  // Build static high-detail offscreen geographical terrain canvas once per world
  useEffect(() => {
    if (builtWorldIdRef.current === state.id && terrainOffscreenRef.current) return;
    builtWorldIdRef.current = state.id;

    const off = document.createElement('canvas');
    off.width = state.worldWidth;
    off.height = state.worldHeight;
    const ctx = off.getContext('2d');
    if (!ctx) return;

    // 1. Deep ocean background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, state.worldHeight);
    bgGrad.addColorStop(0, '#0a1f36');
    bgGrad.addColorStop(0.5, '#0c2744');
    bgGrad.addColorStop(1, '#081b30');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, state.worldWidth, state.worldHeight);

    // 2. Render ocean sea-zones first (coastal shelf vs abyssal ocean)
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (!t.isWater || t.polygon.length < 3) continue;
      ctx.beginPath();
      ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
      for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
      ctx.closePath();

      ctx.fillStyle = t.terrain === 'coastal_water' ? '#143c5e' : '#0b2540';
      ctx.fill();
      ctx.strokeStyle = 'rgba(72, 145, 200, 0.14)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // 3. Cartographic latitude/longitude grid lines over sea
    ctx.strokeStyle = 'rgba(130, 185, 235, 0.06)';
    ctx.lineWidth = 1;
    for (let x = 160; x < state.worldWidth; x += 200) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, state.worldHeight);
      ctx.stroke();
    }
    for (let y = 140; y < state.worldHeight; y += 180) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(state.worldWidth, y);
      ctx.stroke();
    }

    // 4. Coastal shoreline halo shadow
    ctx.save();
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (t.isWater || t.polygon.length < 3) continue;
      ctx.beginPath();
      ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
      for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
      ctx.closePath();
      ctx.strokeStyle = 'rgba(105, 205, 230, 0.25)';
      ctx.lineWidth = 7;
      ctx.stroke();
    }
    ctx.restore();

    // 5. Land terrain base fills + elevation hillshade + biome details
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (t.isWater || t.polygon.length < 3) continue;
      const tDef = TERRAINS[t.terrain];

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
      for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
      ctx.closePath();

      const grad = ctx.createRadialGradient(
        t.center.x - 18,
        t.center.y - 18,
        8,
        t.center.x,
        t.center.y,
        95
      );
      grad.addColorStop(0, tDef.accentColor);
      grad.addColorStop(1, tDef.mapColor);
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.clip();

      // Biome miniature geographical textures
      const seedHash = id.split('').reduce((a, ch) => a * 31 + ch.charCodeAt(0), 7);
      if (t.terrain === 'mountains') {
        for (let p = 0; p < 5; p++) {
          const ox = ((seedHash + p * 53) % 60) - 30;
          const oy = ((seedHash + p * 37) % 44) - 22;
          const px = t.center.x + ox;
          const py = t.center.y + oy;
          // Sunlit left slope
          ctx.fillStyle = '#6f7380';
          ctx.beginPath();
          ctx.moveTo(px, py - 15);
          ctx.lineTo(px - 14, py + 9);
          ctx.lineTo(px, py + 9);
          ctx.closePath();
          ctx.fill();
          // Shadowed right slope
          ctx.fillStyle = '#363842';
          ctx.beginPath();
          ctx.moveTo(px, py - 15);
          ctx.lineTo(px + 14, py + 9);
          ctx.lineTo(px, py + 9);
          ctx.closePath();
          ctx.fill();
          // Snow cap
          ctx.fillStyle = '#dce4ef';
          ctx.beginPath();
          ctx.moveTo(px, py - 15);
          ctx.lineTo(px - 5, py - 6);
          ctx.lineTo(px + 5, py - 6);
          ctx.closePath();
          ctx.fill();
        }
      } else if (t.terrain === 'forest') {
        for (let p = 0; p < 9; p++) {
          const ox = ((seedHash + p * 43) % 72) - 36;
          const oy = ((seedHash + p * 29) % 56) - 28;
          ctx.fillStyle = p % 2 === 0 ? '#1b3a27' : '#2a583b';
          ctx.beginPath();
          ctx.arc(t.center.x + ox, t.center.y + oy, 6.5, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (t.terrain === 'hills') {
        ctx.strokeStyle = 'rgba(255,255,255,0.12)';
        ctx.lineWidth = 2;
        for (let p = -1; p <= 1; p++) {
          ctx.beginPath();
          ctx.arc(t.center.x + p * 18, t.center.y + Math.abs(p) * 6, 15, Math.PI, 0);
          ctx.stroke();
        }
      } else if (t.terrain === 'desert') {
        ctx.strokeStyle = 'rgba(255, 224, 160, 0.16)';
        ctx.lineWidth = 1.6;
        for (let p = -2; p <= 2; p++) {
          ctx.beginPath();
          ctx.moveTo(t.center.x - 35, t.center.y + p * 11);
          ctx.quadraticCurveTo(t.center.x, t.center.y + p * 11 - 7, t.center.x + 35, t.center.y + p * 11);
          ctx.stroke();
        }
      }
      ctx.restore();

      // Subtle coastline edge
      ctx.beginPath();
      ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
      for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
      ctx.closePath();
      ctx.strokeStyle = 'rgba(10, 16, 25, 0.32)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // 6. Rivers
    for (const river of state.rivers) {
      if (river.points.length < 2) continue;
      ctx.save();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(river.points[0].x, river.points[0].y);
      for (let i = 1; i < river.points.length; i++) {
        ctx.lineTo(river.points[i].x, river.points[i].y);
      }
      ctx.strokeStyle = '#185480';
      ctx.lineWidth = river.width + 2.5;
      ctx.stroke();
      ctx.strokeStyle = '#3b9cd9';
      ctx.lineWidth = river.width;
      ctx.stroke();
      ctx.restore();
    }

    // 7. Inland Lakes
    for (const lake of state.lakes) {
      if (lake.polygon.length < 3) continue;
      ctx.beginPath();
      ctx.moveTo(lake.polygon[0].x, lake.polygon[0].y);
      for (let i = 1; i < lake.polygon.length; i++) ctx.lineTo(lake.polygon[i].x, lake.polygon[i].y);
      ctx.closePath();
      ctx.fillStyle = '#1e699c';
      ctx.fill();
      ctx.strokeStyle = '#5bb5eb';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }

    terrainOffscreenRef.current = off;
  }, [state.id, state.lakes, state.rivers, state.territories, state.territoryIds, state.worldHeight, state.worldWidth]);

  // Helper: interpolate moving entity position along path
  const getInterpolatedPos = (path: string[], fallbackTid: string, progress: number): Point2D => {
    if (path.length >= 2) {
      const a = state.territories[path[0]];
      const b = state.territories[path[1]];
      if (a && b) {
        return {
          x: a.center.x + (b.center.x - a.center.x) * progress,
          y: a.center.y + (b.center.y - a.center.y) * progress,
        };
      }
    }
    return state.territories[fallbackTid]?.center ?? { x: 0, y: 0 };
  };

  // Precompute max city pop & economic output for heatmaps
  const maxPop = useMemo(() => {
    let m = 5000;
    for (const c of Object.values(state.cities)) m = Math.max(m, c.population);
    return m;
  }, [state.cities]);

  // Main Dynamic Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    const terrainCanvas = terrainOffscreenRef.current;
    if (!canvas || !container || !terrainCanvas) return;

    const dpr = window.devicePixelRatio || 1;
    const w = container.clientWidth;
    const h = container.clientHeight;
    if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.fillStyle = '#071322';
    ctx.fillRect(0, 0, w, h);

    // Apply Camera Pan & Zoom Transform
    ctx.translate(w * 0.5, h * 0.5);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-camera.x, -camera.y);

    // Draw cached geography base
    ctx.drawImage(terrainCanvas, 0, 0);

    // 1. Territory Overlay Fills (Political / Resource / Population / Economic / Naval / Military)
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (t.polygon.length < 3) continue;

      let fill: string | null = null;
      if (overlay === 'political' && !t.isWater && t.ownerId) {
        const owner = state.nations[t.ownerId];
        if (owner) fill = owner.color + '72'; // crisp translucent national hue
      } else if (overlay === 'resource' && !t.isWater) {
        if (t.deposits.length > 0) {
          const topRes = t.deposits[0].resource;
          fill =
            topRes === 'oil'
              ? 'rgba(168, 85, 247, 0.55)'
              : topRes === 'gold'
                ? 'rgba(245, 196, 65, 0.62)'
                : topRes === 'iron'
                  ? 'rgba(148, 163, 184, 0.55)'
                  : topRes === 'coal'
                    ? 'rgba(51, 65, 85, 0.7)'
                    : 'rgba(52, 211, 153, 0.45)';
        } else {
          fill = 'rgba(7, 11, 18, 0.45)';
        }
      } else if (overlay === 'population' && !t.isWater) {
        const city = t.cityId ? state.cities[t.cityId] : null;
        const ratio = city ? Math.min(1, city.population / maxPop) : t.ownerId ? 0.15 : 0.02;
        fill = city
          ? `rgba(245, ${Math.round(180 - ratio * 110)}, 50, ${0.35 + ratio * 0.45})`
          : t.ownerId
            ? 'rgba(56, 189, 248, 0.25)'
            : 'rgba(8, 12, 20, 0.48)';
      } else if (overlay === 'economic' && !t.isWater) {
        const city = t.cityId ? state.cities[t.cityId] : null;
        const eco = city ? Math.min(1, city.economicOutput / 180) : t.isCoastal && t.ownerId ? 0.28 : 0.08;
        fill = `rgba(212, 168, 79, ${0.12 + eco * 0.65})`;
      } else if (overlay === 'military' && !t.isWater) {
        const hasArmy = Object.values(state.armies).some((a) => a.territoryId === id);
        if (hasArmy) fill = 'rgba(239, 68, 68, 0.46)';
        else if (t.fortLevel > 0) fill = 'rgba(56, 189, 248, 0.42)';
        else if (t.ownerId) fill = (state.nations[t.ownerId]?.color ?? '#64748b') + '35';
      } else if (overlay === 'naval') {
        if (t.isWater) {
          fill = t.weatherStorm ? 'rgba(239, 68, 68, 0.28)' : 'rgba(14, 165, 233, 0.16)';
        } else if (t.isCoastal) {
          fill = t.blockadedByNationId ? 'rgba(239, 68, 68, 0.52)' : 'rgba(56, 189, 248, 0.28)';
        } else {
          fill = 'rgba(7, 11, 18, 0.5)';
        }
      }

      if (fill) {
        ctx.beginPath();
        ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
        for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
      }
    }

    // 2. Internal Province Borders & National Borders
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (t.isWater || t.polygon.length < 3) continue;
      ctx.beginPath();
      ctx.moveTo(t.polygon[0].x, t.polygon[0].y);
      for (let i = 1; i < t.polygon.length; i++) ctx.lineTo(t.polygon[i].x, t.polygon[i].y);
      ctx.closePath();

      if (t.ownerId && state.nations[t.ownerId]) {
        const owner = state.nations[t.ownerId];
        ctx.strokeStyle = owner.color;
        ctx.lineWidth = 2.6;
        ctx.stroke();
        ctx.strokeStyle = 'rgba(7, 10, 16, 0.55)';
        ctx.lineWidth = 0.9;
        ctx.stroke();
      } else {
        ctx.strokeStyle = 'rgba(220, 230, 245, 0.16)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    // Highlight Attackable Neighbors of Selected Territory
    if (selectedTerritoryId && state.territories[selectedTerritoryId]) {
      const sel = state.territories[selectedTerritoryId];
      // Highlight selection
      ctx.beginPath();
      ctx.moveTo(sel.polygon[0].x, sel.polygon[0].y);
      for (let i = 1; i < sel.polygon.length; i++) ctx.lineTo(sel.polygon[i].x, sel.polygon[i].y);
      ctx.closePath();
      ctx.fillStyle = 'rgba(242, 203, 119, 0.18)';
      ctx.fill();
      ctx.strokeStyle = '#f2cb77';
      ctx.lineWidth = 3.2;
      ctx.stroke();

      // If owned by player, show glowing dashed borders on adjacent targets
      if (sel.ownerId === state.playerNationId) {
        ctx.save();
        ctx.setLineDash([6, 5]);
        for (const nid of sel.landNeighbors) {
          const nb = state.territories[nid];
          if (nb && nb.ownerId !== state.playerNationId) {
            ctx.beginPath();
            ctx.moveTo(nb.polygon[0].x, nb.polygon[0].y);
            for (let i = 1; i < nb.polygon.length; i++) ctx.lineTo(nb.polygon[i].x, nb.polygon[i].y);
            ctx.closePath();
            ctx.strokeStyle = nb.ownerId ? 'rgba(239, 68, 68, 0.8)' : 'rgba(52, 211, 153, 0.7)';
            ctx.lineWidth = 2.0;
            ctx.stroke();
          }
        }
        ctx.restore();
      }
    }

    // Hover highlight
    if (hoverTid && hoverTid !== selectedTerritoryId && state.territories[hoverTid]) {
      const ht = state.territories[hoverTid];
      ctx.beginPath();
      ctx.moveTo(ht.polygon[0].x, ht.polygon[0].y);
      for (let i = 1; i < ht.polygon.length; i++) ctx.lineTo(ht.polygon[i].x, ht.polygon[i].y);
      ctx.closePath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
      ctx.lineWidth = 1.8;
      ctx.stroke();
    }

    // 3. Maritime & Land Trade Routes
    if (settings.showTradeRoutes) {
      for (const tr of state.tradeRoutes) {
        const cA = state.cities[tr.fromCityId];
        const cB = state.cities[tr.toCityId];
        if (!cA || !cB) continue;
        const pA = state.territories[cA.territoryId]?.center;
        const pB = state.territories[cB.territoryId]?.center;
        if (!pA || !pB) continue;
        ctx.save();
        ctx.setLineDash([7, 6]);
        ctx.beginPath();
        ctx.moveTo(pA.x, pA.y);
        const mx = (pA.x + pB.x) * 0.5;
        const my = (pA.y + pB.y) * 0.5 - (tr.isMaritime ? 38 : 16);
        ctx.quadraticCurveTo(mx, my, pB.x, pB.y);
        ctx.strokeStyle = tr.disrupted ? 'rgba(239, 68, 68, 0.65)' : 'rgba(242, 203, 119, 0.52)';
        ctx.lineWidth = overlay === 'economic' || overlay === 'naval' ? 2.4 : 1.5;
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4. Weather Storms & Blockade Rings
    for (const id of state.territoryIds) {
      const t = state.territories[id];
      if (t.weatherStorm) {
        ctx.save();
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.55)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(t.center.x, t.center.y, 18, 0, Math.PI * 1.65);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(t.center.x, t.center.y, 11, Math.PI * 0.4, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      if (t.blockadedByNationId) {
        ctx.save();
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(t.center.x, t.center.y, 24, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 5. Resource Deposit Badges (Visible on zoom or Resource overlay)
    if (settings.showResourceBadges && (camera.zoom > 0.62 || overlay === 'resource')) {
      for (const id of state.territoryIds) {
        const t = state.territories[id];
        if (t.isWater || t.deposits.length === 0) continue;
        const dep = t.deposits[0];
        const rx = t.center.x + 16;
        const ry = t.center.y + 16;
        const colMap: Record<string, string> = {
          iron: '#94a3b8',
          coal: '#475569',
          oil: '#a855f7',
          gold: '#f5c441',
          stone: '#cbd5e1',
          wood: '#22c55e',
          food: '#84cc16',
        };
        ctx.fillStyle = '#090d14';
        ctx.beginPath();
        ctx.arc(rx, ry, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = colMap[dep.resource] ?? '#d4a84f';
        ctx.lineWidth = 1.6;
        ctx.stroke();
        ctx.fillStyle = colMap[dep.resource] ?? '#d4a84f';
        ctx.font = 'bold 8px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(dep.resource[0].toUpperCase(), rx, ry + 0.5);
      }
    }

    // 6. Cities & Naval Bases
    for (const city of Object.values(state.cities)) {
      const t = state.territories[city.territoryId];
      const owner = state.nations[city.nationId];
      if (!t || !owner) continue;
      const cx = t.center.x;
      const cy = t.center.y - 6;

      // City base marker
      const radius = 5 + city.tier * 1.4;
      ctx.fillStyle = '#0b111c';
      ctx.beginPath();
      ctx.arc(cx, cy, radius + 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = owner.color;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = city.isCapital ? '#f2cb77' : '#e2e8f0';
      ctx.lineWidth = city.isCapital ? 2.2 : 1.2;
      ctx.stroke();

      // Naval Base / Port Anchor Badge
      const hasNaval = city.buildings.some((b) => b.buildingId === 'naval_bases' || b.buildingId === 'ports');
      if (hasNaval) {
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('⚓', cx + radius + 9, cy + 3);
      }

      if (settings.showTerritoryLabels && camera.zoom >= 0.42) {
        ctx.font = city.isCapital ? 'bold 11px sans-serif' : '600 10px sans-serif';
        ctx.textAlign = 'center';
        const label = city.isCapital ? `★ ${city.name}` : city.name;
        const tw = ctx.measureText(label).width + 10;
        ctx.fillStyle = 'rgba(7, 11, 18, 0.82)';
        ctx.fillRect(cx - tw * 0.5, cy + radius + 4, tw, 15);
        ctx.fillStyle = city.isCapital ? '#f2cb77' : '#e2e8f0';
        ctx.fillText(label, cx, cy + radius + 14.5);
      }
    }

    // Wilderness labels on closer zoom
    if (settings.showTerritoryLabels && camera.zoom >= 0.82) {
      for (const id of state.territoryIds) {
        const t = state.territories[id];
        if (t.isWater || t.cityId) continue;
        ctx.font = '500 9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(232, 238, 247, 0.65)';
        ctx.fillText(t.name, t.center.x, t.center.y + 4);
      }
    }

    // 7. Land Armies (with Marching Arrows & Troop Counts)
    if (settings.showUnitBanners) {
      for (const army of Object.values(state.armies)) {
        if (army.embarkedFleetId) continue;
        const nation = state.nations[army.nationId];
        if (!nation) continue;
        const pos = getInterpolatedPos(army.path, army.territoryId, army.moveProgress);

        // Draw movement path
        if (army.path.length > 1) {
          ctx.save();
          ctx.setLineDash([4, 4]);
          ctx.strokeStyle = nation.color;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(pos.x, pos.y);
          for (let i = 1; i < army.path.length; i++) {
            const pt = state.territories[army.path[i]]?.center;
            if (pt) ctx.lineTo(pt.x, pt.y);
          }
          ctx.stroke();
          ctx.restore();
        }

        const ax = pos.x - 16;
        const ay = pos.y - 24;
        const isSel = selectedArmyId === army.id;
        const count = getArmyTotalUnitCount(army);
        const pow = Math.round(computeArmyPower(army, false, state));

        ctx.fillStyle = '#0a0f18';
        ctx.fillRect(ax - 17, ay - 9, 34, 17);
        ctx.fillStyle = nation.color;
        ctx.fillRect(ax - 17, ay - 9, 5, 17);
        ctx.strokeStyle = isSel ? '#f2cb77' : 'rgba(255,255,255,0.4)';
        ctx.lineWidth = isSel ? 2.2 : 1;
        ctx.strokeRect(ax - 17, ay - 9, 34, 17);

        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 9.5px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`${count}⚔`, ax + 2, ay);
        if (camera.zoom > 0.75) {
          ctx.fillStyle = '#94a3b8';
          ctx.font = '8px monospace';
          ctx.fillText(`${pow}`, ax, ay + 14);
        }
      }

      // 8. Naval Fleets (Era-Specific Ship Silhouettes + Carried Troops Indicator!)
      for (const fleet of Object.values(state.fleets)) {
        const nation = state.nations[fleet.nationId];
        if (!nation) continue;
        const pos = getInterpolatedPos(fleet.path, fleet.territoryId, fleet.moveProgress);

        if (fleet.path.length > 1) {
          ctx.save();
          ctx.setLineDash([5, 4]);
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(pos.x, pos.y);
          for (let i = 1; i < fleet.path.length; i++) {
            const pt = state.territories[fleet.path[i]]?.center;
            if (pt) ctx.lineTo(pt.x, pt.y);
          }
          ctx.stroke();
          ctx.restore();
        }

        const fx = pos.x + 14;
        const fy = pos.y - 14;
        const isSel = selectedFleetId === fleet.id;
        const shipCount = fleet.ships.reduce((s, x) => s + x.count, 0);

        ctx.save();
        ctx.translate(fx, fy);
        // Ship hull icon scaling across eras
        ctx.fillStyle = nation.color;
        ctx.strokeStyle = isSel ? '#f2cb77' : '#e2e8f0';
        ctx.lineWidth = isSel ? 2.2 : 1.1;

        ctx.beginPath();
        if (nation.era === 'ancient' || nation.era === 'classical') {
          // Trireme hull + sail
          ctx.moveTo(-14, 2);
          ctx.lineTo(14, 2);
          ctx.lineTo(9, 8);
          ctx.lineTo(-10, 8);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(-3, -9, 8, 9);
        } else if (nation.era === 'medieval' || nation.era === 'renaissance') {
          // High-stern Galleon
          ctx.moveTo(-15, 0);
          ctx.lineTo(15, 1);
          ctx.lineTo(10, 8);
          ctx.lineTo(-11, 8);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = '#fef3c7';
          ctx.beginPath();
          ctx.moveTo(-6, -1);
          ctx.lineTo(0, -12);
          ctx.lineTo(6, -1);
          ctx.closePath();
          ctx.fill();
        } else {
          // Modern / Industrial / Future Steel Warship / Carrier
          ctx.moveTo(-16, 2);
          ctx.lineTo(17, 2);
          ctx.lineTo(12, 8);
          ctx.lineTo(-13, 8);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(-7, -4, 11, 5);
          ctx.fillRect(0, -8, 3, 4);
        }

        // Badge count & embarked troop tag
        ctx.fillStyle = '#090d14';
        ctx.fillRect(-14, 10, 28, 12);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(
          `${shipCount}${fleet.carriedArmyIds.length > 0 ? '+⚔' : '⚓'}`,
          0,
          19
        );
        ctx.restore();
      }
    }

    // 9. Active Battles (Animated Clash & Momentum Bar)
    for (const battle of Object.values(state.battles)) {
      const t = state.territories[battle.territoryId];
      if (!t) continue;
      const bx = t.center.x;
      const by = t.center.y + 8;

      ctx.save();
      ctx.fillStyle = 'rgba(239, 68, 68, 0.88)';
      ctx.beginPath();
      ctx.arc(bx, by, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f2cb77';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = '#fff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(battle.kind === 'naval' ? '⛵' : '⚔', bx, by);

      // Battle momentum bar
      ctx.fillStyle = '#090d14';
      ctx.fillRect(bx - 22, by + 15, 44, 6);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(bx - 21, by + 16, 42, 4);
      ctx.fillStyle = '#34d399';
      ctx.fillRect(bx - 21, by + 16, (42 * battle.progress) / 100, 4);
      ctx.restore();
    }

    ctx.restore();

    // Render Minimap
    const mini = minimapRef.current;
    if (mini) {
      const mctx = mini.getContext('2d');
      if (mctx) {
        mctx.clearRect(0, 0, mini.width, mini.height);
        mctx.fillStyle = '#071426';
        mctx.fillRect(0, 0, mini.width, mini.height);
        const sx = mini.width / state.worldWidth;
        const sy = mini.height / state.worldHeight;

        for (const id of state.territoryIds) {
          const t = state.territories[id];
          if (t.isWater || t.polygon.length < 3) continue;
          mctx.beginPath();
          mctx.moveTo(t.polygon[0].x * sx, t.polygon[0].y * sy);
          for (let i = 1; i < t.polygon.length; i++) {
            mctx.lineTo(t.polygon[i].x * sx, t.polygon[i].y * sy);
          }
          mctx.closePath();
          mctx.fillStyle = t.ownerId && state.nations[t.ownerId] ? state.nations[t.ownerId].color : '#3c4e3d';
          mctx.fill();
        }

        // Viewport frame
        const vx = (camera.x - w / (2 * camera.zoom)) * sx;
        const vy = (camera.y - h / (2 * camera.zoom)) * sy;
        const vw = (w / camera.zoom) * sx;
        const vh = (h / camera.zoom) * sy;
        mctx.strokeStyle = '#f2cb77';
        mctx.lineWidth = 1.4;
        mctx.strokeRect(vx, vy, vw, vh);
      }
    }
  }, [
    camera,
    hoverTid,
    maxPop,
    overlay,
    selectedArmyId,
    selectedFleetId,
    selectedTerritoryId,
    settings.showResourceBadges,
    settings.showTerritoryLabels,
    settings.showTradeRoutes,
    settings.showUnitBanners,
    state,
  ]);

  const screenToWorld = useCallback(
    (clientX: number, clientY: number): Point2D => {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return { x: 0, y: 0 };
      const sx = clientX - rect.left;
      const sy = clientY - rect.top;
      return {
        x: (sx - rect.width * 0.5) / camera.zoom + camera.x,
        y: (sy - rect.height * 0.5) / camera.zoom + camera.y,
      };
    },
    [camera]
  );

  const hitTestWorld = useCallback(
    (wx: number, wy: number): { territoryId: string | null; armyId: string | null; fleetId: string | null } => {
      // Check armies/fleets near click first
      for (const army of Object.values(state.armies)) {
        if (army.embarkedFleetId) continue;
        const pos = getInterpolatedPos(army.path, army.territoryId, army.moveProgress);
        if (Math.abs(wx - (pos.x - 16)) < 20 && Math.abs(wy - (pos.y - 24)) < 14) {
          return { territoryId: army.territoryId, armyId: army.id, fleetId: null };
        }
      }
      for (const fleet of Object.values(state.fleets)) {
        const pos = getInterpolatedPos(fleet.path, fleet.territoryId, fleet.moveProgress);
        if (Math.abs(wx - (pos.x + 14)) < 22 && Math.abs(wy - (pos.y - 10)) < 18) {
          return { territoryId: fleet.territoryId, armyId: null, fleetId: fleet.id };
        }
      }
      for (const id of state.territoryIds) {
        const t = state.territories[id];
        if (pointInPolygon(wx, wy, t.polygon)) {
          return { territoryId: id, armyId: null, fleetId: null };
        }
      }
      return { territoryId: null, armyId: null, fleetId: null };
    },
    [state]
  );

  const handleMouseDown = (e: React.MouseEvent) => {
    dragRef.current = {
      active: true,
      moved: false,
      startX: e.clientX,
      startY: e.clientY,
      camX: camera.x,
      camY: camera.y,
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
    if (dragRef.current.active) {
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      if (Math.hypot(dx, dy) > 4) dragRef.current.moved = true;
      setCamera((c) => ({
        ...c,
        x: Math.max(0, Math.min(state.worldWidth, dragRef.current.camX - dx / c.zoom)),
        y: Math.max(0, Math.min(state.worldHeight, dragRef.current.camY - dy / c.zoom)),
      }));
      return;
    }
    const wp = screenToWorld(e.clientX, e.clientY);
    const hit = hitTestWorld(wp.x, wp.y);
    setHoverTid(hit.territoryId);
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    const wasDrag = dragRef.current.moved;
    dragRef.current.active = false;
    if (wasDrag) return;
    const wp = screenToWorld(e.clientX, e.clientY);
    const hit = hitTestWorld(wp.x, wp.y);
    if (hit.armyId) {
      onSelectArmy(hit.armyId);
      onSelectFleet(null);
      if (hit.territoryId) onSelectTerritory(hit.territoryId);
    } else if (hit.fleetId) {
      onSelectFleet(hit.fleetId);
      onSelectArmy(null);
      if (hit.territoryId) onSelectTerritory(hit.territoryId);
    } else if (hit.territoryId) {
      onSelectTerritory(hit.territoryId);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.14 : 0.88;
    setCamera((c) => ({
      ...c,
      zoom: Math.max(0.28, Math.min(2.6, c.zoom * factor)),
    }));
  };

  const handleMinimapClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rx = (e.clientX - rect.left) / rect.width;
    const ry = (e.clientY - rect.top) / rect.height;
    setCamera((c) => ({
      ...c,
      x: rx * state.worldWidth,
      y: ry * state.worldHeight,
    }));
  };

  const hoveredTerritory: Territory | null = hoverTid ? state.territories[hoverTid] : null;
  const hoveredOwner = hoveredTerritory?.ownerId ? state.nations[hoveredTerritory.ownerId] : null;

  return (
    <div ref={containerRef} className="dom-map-stage">
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          dragRef.current.active = false;
          setHoverTid(null);
        }}
        onWheel={handleWheel}
        style={{ width: '100%', height: '100%', display: 'block', cursor: dragRef.current.active ? 'grabbing' : 'grab' }}
      />

      {/* 7 Map Overlay Modes */}
      <div className="dom-overlay-bar">
        <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#8a9bb3', padding: '0 6px' }}>
          <Layers size={12} /> Map Mode:
        </span>
        {OVERLAY_OPTIONS.map((opt) => (
          <button
            key={opt.id}
            className={`dom-overlay-btn ${overlay === opt.id ? 'active' : ''}`}
            onClick={() => onChangeOverlay(opt.id)}
          >
            {opt.icon}
            {opt.label}
          </button>
        ))}
      </div>

      {/* Hover Tooltip */}
      {hoveredTerritory && !dragRef.current.active && (
        <div
          style={{
            position: 'fixed',
            left: Math.min(window.innerWidth - 230, mousePos.x + 16),
            top: Math.min(window.innerHeight - 130, mousePos.y + 16),
            pointerEvents: 'none',
            background: 'rgba(10, 15, 24, 0.94)',
            border: '1px solid rgba(212, 168, 79, 0.45)',
            borderRadius: 6,
            padding: '7px 10px',
            minWidth: 185,
            zIndex: 40,
            boxShadow: '0 8px 24px rgba(0,0,0,0.65)',
          }}
        >
          <div style={{ fontWeight: 700, fontSize: 12, color: '#f2cb77', display: 'flex', justifyContent: 'space-between', gap: 8 }}>
            <span>{hoveredTerritory.name}</span>
            <span style={{ fontSize: 10, color: '#9fb0c7' }}>{TERRAINS[hoveredTerritory.terrain].name}</span>
          </div>
          <div style={{ fontSize: 11, color: hoveredOwner ? hoveredOwner.color : '#8fa2bc', marginTop: 2 }}>
            {hoveredTerritory.isWater
              ? hoveredTerritory.weatherStorm
                ? 'Stormy Sea Zone (Slowed Transit)'
                : 'Navigable Sea Zone'
              : hoveredOwner
                ? `Controlled by ${hoveredOwner.name}`
                : `Unclaimed Wilderness (Garrison ~${hoveredTerritory.wildernessGarrison})`}
          </div>
          {!hoveredTerritory.isWater && (
            <div style={{ fontSize: 10.5, color: '#9fb0c7', marginTop: 3, display: 'flex', gap: 8 }}>
              <span>Def +{Math.round(TERRAINS[hoveredTerritory.terrain].defenseBonus * 100)}%</span>
              {hoveredTerritory.isCoastal && <span style={{ color: '#38bdf8' }}>Coastal</span>}
              {hoveredTerritory.hasRiver && <span style={{ color: '#60a5fa' }}>River</span>}
              {hoveredTerritory.deposits.length > 0 && (
                <span style={{ color: '#34d399' }}>
                  {hoveredTerritory.deposits.map((d) => d.resource).join(', ')}
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {/* Map Controls + Minimap */}
      <div
        style={{
          position: 'absolute',
          bottom: 10,
          right: 10,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-end',
          gap: 6,
          zIndex: 10,
        }}
      >
        <div style={{ display: 'flex', gap: 4 }}>
          <button
            className="dom-btn"
            title="Zoom In"
            onClick={() => setCamera((c) => ({ ...c, zoom: Math.min(2.6, c.zoom * 1.2) }))}
          >
            <Plus size={13} />
          </button>
          <button
            className="dom-btn"
            title="Zoom Out"
            onClick={() => setCamera((c) => ({ ...c, zoom: Math.max(0.28, c.zoom / 1.2) }))}
          >
            <Minus size={13} />
          </button>
          <button className="dom-btn" title="Center on Capital" onClick={centerOnCapital}>
            <Crosshair size={13} /> Capital
          </button>
          <button className="dom-btn" title="Fit Entire World" onClick={resetView}>
            <Maximize2 size={13} /> World
          </button>
        </div>

        <div
          style={{
            background: 'rgba(9, 14, 22, 0.9)',
            border: '1px solid rgba(212, 168, 79, 0.4)',
            borderRadius: 6,
            padding: 4,
            boxShadow: '0 8px 24px rgba(0,0,0,0.6)',
          }}
        >
          <div style={{ fontSize: 10, color: '#9fb0c7', display: 'flex', alignItems: 'center', gap: 4, marginBottom: 3, paddingLeft: 2 }}>
            <Compass size={11} color="#d4a84f" /> Strategic Atlas
          </div>
          <canvas
            ref={minimapRef}
            width={186}
            height={108}
            onClick={handleMinimapClick}
            style={{ display: 'block', borderRadius: 3, cursor: 'pointer' }}
          />
        </div>
      </div>
    </div>
  );
};
