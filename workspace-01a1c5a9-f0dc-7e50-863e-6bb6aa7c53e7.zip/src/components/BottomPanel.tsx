import React from 'react';
import { Atom, Bell, Flame, Hammer, Navigation, Swords } from 'lucide-react';
import { BUILDING_BY_ID } from '../data/buildings';
import { TECH_BY_ID } from '../data/technologies';
import { UNIT_BY_ID } from '../data/units';
import { getEffectiveTechCost } from '../engine/tech';
import { GameState } from '../types/game';

interface Props {
  state: GameState;
  onFocusTerritory: (tid: string) => void;
  onOpenTechTree: () => void;
}

export const BottomPanel: React.FC<Props> = ({ state, onFocusTerritory, onOpenTechTree }) => {
  const player = state.nations[state.playerNationId];
  const battles = Object.values(state.battles);
  const currentTech = player?.currentTechId ? TECH_BY_ID[player.currentTechId] : null;
  const activeBuilds = Object.values(state.cities)
    .filter((c) => c.nationId === state.playerNationId && c.queue.length > 0)
    .map((c) => ({ city: c, item: c.queue[0] }));
  const activeRecruits = state.recruitmentQueue.filter((r) => r.nationId === state.playerNationId);

  const movingArmies = Object.values(state.armies).filter(
    (a) => a.nationId === state.playerNationId && a.path.length > 1
  );
  const activeFleets = Object.values(state.fleets).filter(
    (f) => f.nationId === state.playerNationId && (f.path.length > 1 || f.mission !== 'idle')
  );

  return (
    <section className="dom-bottom-panel">
      {/* 1. Active Battles */}
      <div className="dom-panel" style={{ padding: '7px 9px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#ef4444', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
          <Swords size={13} /> Active Battles ({battles.length})
        </div>
        <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
          {battles.length === 0 ? (
            <div style={{ fontSize: 11, color: '#667892' }}>No active engagements. Select a territory to attack.</div>
          ) : (
            battles.map((b) => {
              const terr = state.territories[b.territoryId];
              const att = state.nations[b.attackerNationId];
              const def = b.defenderNationId ? state.nations[b.defenderNationId] : null;
              return (
                <div
                  key={b.id}
                  onClick={() => onFocusTerritory(b.territoryId)}
                  style={{
                    background: '#131d2d',
                    border: '1px solid #2c3e58',
                    borderRadius: 4,
                    padding: '4px 7px',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 3 }}>
                    <span style={{ fontWeight: 700, color: '#f8fafc' }}>
                      {b.kind.toUpperCase()}: {terr?.name}
                    </span>
                    <span className="font-mono-num" style={{ color: '#f2cb77', fontSize: 10 }}>
                      {b.attackerCurrentPower} vs {b.defenderCurrentPower}
                    </span>
                  </div>
                  <div className="dom-progress">
                    <div
                      className="dom-progress-fill"
                      style={{
                        width: `${b.progress}%`,
                        background: att?.id === state.playerNationId ? '#34d399' : '#ef4444',
                      }}
                    />
                  </div>
                  <div style={{ fontSize: 9.5, color: '#9fb0c7', marginTop: 2 }}>
                    {att?.adjective} vs {def ? def.adjective : 'Wilderness'} (Terrain x{b.terrainModifier})
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 2. Research & Construction Progress */}
      <div className="dom-panel" style={{ padding: '7px 9px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
          <Atom size={13} /> Research &amp; Construction
        </div>
        <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div
            onClick={onOpenTechTree}
            style={{
              background: '#131d2d',
              border: '1px solid #233349',
              borderRadius: 4,
              padding: '5px 7px',
              cursor: 'pointer',
            }}
          >
            {currentTech && player ? (
              <>
                {(() => {
                  const effCost = getEffectiveTechCost(currentTech, player);
                  return (
                    <>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 3 }}>
                        <span style={{ color: '#38bdf8', fontWeight: 700 }}>{currentTech.name}</span>
                        <span className="font-mono-num" style={{ fontSize: 10 }}>
                          {Math.floor(player.techProgress)}/{effCost}
                        </span>
                      </div>
                      <div className="dom-progress">
                        <div
                          className="dom-progress-fill"
                          style={{
                            width: `${Math.min(100, (player.techProgress / effCost) * 100)}%`,
                            background: '#38bdf8',
                          }}
                        />
                      </div>
                    </>
                  );
                })()}
              </>
            ) : (
              <div style={{ fontSize: 11, color: '#f59e0b', fontWeight: 600 }}>
                No technology researching — Click to open Tech Tree!
              </div>
            )}
          </div>

          {activeBuilds.map(({ city, item }) => (
            <div key={item.id} style={{ background: '#131d2d', borderRadius: 4, padding: '4px 7px', fontSize: 10.5 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                <span style={{ color: '#f2cb77' }}>
                  <Hammer size={10} style={{ verticalAlign: 'middle' }} /> {city.name}: {BUILDING_BY_ID[item.buildingId]?.name}
                </span>
                <span className="font-mono-num">{Math.round((item.progress / item.totalTime) * 100)}%</span>
              </div>
              <div className="dom-progress">
                <div
                  className="dom-progress-fill"
                  style={{ width: `${Math.min(100, (item.progress / item.totalTime) * 100)}%`, background: '#f59e0b' }}
                />
              </div>
            </div>
          ))}

          {activeRecruits.map((r) => (
            <div key={r.id} style={{ background: '#131d2d', borderRadius: 4, padding: '4px 7px', fontSize: 10.5 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                <span style={{ color: '#34d399' }}>
                  Training {r.count}x {UNIT_BY_ID[r.unitId]?.name}
                </span>
                <span className="font-mono-num">{Math.round((r.progress / r.totalTime) * 100)}%</span>
              </div>
              <div className="dom-progress">
                <div
                  className="dom-progress-fill"
                  style={{ width: `${Math.min(100, (r.progress / r.totalTime) * 100)}%`, background: '#34d399' }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Military & Naval Activity */}
      <div className="dom-panel" style={{ padding: '7px 9px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
          <Navigation size={13} /> Military &amp; Naval Activity
        </div>
        <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 4, fontSize: 11 }}>
          {movingArmies.length === 0 && activeFleets.length === 0 ? (
            <div style={{ color: '#667892' }}>All armies and fleets standing by at garrison posts.</div>
          ) : (
            <>
              {movingArmies.map((a) => (
                <div
                  key={a.id}
                  onClick={() => onFocusTerritory(a.territoryId)}
                  style={{ padding: '4px 6px', background: '#131d2d', borderRadius: 4, cursor: 'pointer' }}
                >
                  <b style={{ color: '#34d399' }}>{a.name}</b> marching to{' '}
                  <b>{state.territories[a.targetTerritoryId ?? '']?.name}</b>
                </div>
              ))}
              {activeFleets.map((f) => (
                <div
                  key={f.id}
                  onClick={() => onFocusTerritory(f.territoryId)}
                  style={{ padding: '4px 6px', background: '#131d2d', borderRadius: 4, cursor: 'pointer' }}
                >
                  <b style={{ color: '#38bdf8' }}>{f.name}</b> ({f.mission}) at{' '}
                  <b>{state.territories[f.territoryId]?.name}</b>
                </div>
              ))}
            </>
          )}
        </div>
      </div>

      {/* 4. Notifications & World Events */}
      <div className="dom-panel" style={{ padding: '7px 9px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#a78bfa', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
          <Bell size={13} /> World Events &amp; Intelligence
        </div>
        <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {state.notifications.slice(0, 12).map((n) => {
            const col =
              n.severity === 'success'
                ? '#34d399'
                : n.severity === 'danger'
                  ? '#ef4444'
                  : n.severity === 'warning'
                    ? '#f59e0b'
                    : '#38bdf8';
            return (
              <div
                key={n.id}
                onClick={() => n.territoryId && onFocusTerritory(n.territoryId)}
                style={{
                  padding: '4px 7px',
                  background: '#131d2d',
                  borderLeft: `3px solid ${col}`,
                  borderRadius: 4,
                  fontSize: 11,
                  cursor: n.territoryId ? 'pointer' : 'default',
                }}
              >
                <div style={{ fontWeight: 700, color: col }}>{n.title}</div>
                <div style={{ color: '#cbd5e1', fontSize: 10.5 }}>{n.message}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
