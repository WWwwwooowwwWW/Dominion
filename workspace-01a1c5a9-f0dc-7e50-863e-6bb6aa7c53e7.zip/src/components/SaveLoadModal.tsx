import React, { useEffect, useState } from 'react';
import { FolderOpen, Save, Trash2, X } from 'lucide-react';
import { ERA_BY_ID, formatYear } from '../data/eras';
import { apiDeleteSave, apiListSaves, apiLoadGame, apiSaveGame } from '../services/api';
import { GameState, SaveSlotSummary } from '../types/game';

interface Props {
  currentState: GameState | null;
  onLoadedGame: (state: GameState) => void;
  onClose: () => void;
}

export const SaveLoadModal: React.FC<Props> = ({ currentState, onLoadedGame, onClose }) => {
  const [slots, setSlots] = useState<SaveSlotSummary[]>([]);
  const [slotName, setSlotName] = useState<string>(
    currentState ? `${currentState.nations[currentState.playerNationId]?.name ?? 'Dominion'} Save` : 'Imperial Campaign'
  );
  const [loading, setLoading] = useState(false);

  const refresh = async () => {
    const list = await apiListSaves();
    setSlots(list);
  };

  useEffect(() => {
    refresh();
  }, []);

  const handleSave = async () => {
    if (!currentState) return;
    setLoading(true);
    await apiSaveGame(currentState, slotName.trim() || 'Campaign Save');
    await refresh();
    setLoading(false);
  };

  const handleLoad = async (id: string) => {
    setLoading(true);
    const loaded = await apiLoadGame(id);
    setLoading(false);
    if (loaded) {
      onLoadedGame(loaded);
      onClose();
    }
  };

  const handleDelete = async (id: string) => {
    await apiDeleteSave(id);
    await refresh();
  };

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" style={{ width: 'min(680px, 94vw)' }} onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <FolderOpen size={20} color="#d4a84f" />
            <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
              Campaign Archives — Save &amp; Load
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {currentState && currentState.config.mode !== 'multiplayer' && (
            <div className="dom-card-gold" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input
                className="dom-input"
                style={{ flex: 1 }}
                value={slotName}
                onChange={(e) => setSlotName(e.target.value)}
                placeholder="Enter save slot name..."
              />
              <button className="dom-btn dom-btn-gold" disabled={loading} onClick={handleSave}>
                <Save size={14} /> Save Current Campaign
              </button>
            </div>
          )}

          {slots.length === 0 ? (
            <div className="dom-card" style={{ color: '#9fb0c7', fontSize: 12.5, textAlign: 'center', padding: 24 }}>
              No saved campaigns found yet. Start a campaign and save your progress at any time!
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {slots.map((slot) => (
                <div
                  key={slot.id}
                  className="dom-card"
                  style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13, color: '#f2cb77' }}>
                      {slot.name}{' '}
                      {slot.isAutosave && (
                        <span className="dom-badge" style={{ color: '#38bdf8', fontSize: 9.5, marginLeft: 5 }}>
                          AUTOSAVE
                        </span>
                      )}
                    </div>
                    <div style={{ fontSize: 11.5, color: '#cbd5e1', marginTop: 2 }}>
                      {slot.nationName} • {ERA_BY_ID[slot.era]?.shortName ?? slot.era} ({formatYear(slot.year)}) •{' '}
                      <b className="font-mono-num">{slot.territoriesOwned}/{slot.totalLandTerritories}</b> Territories •{' '}
                      <span style={{ textTransform: 'capitalize' }}>{slot.difficulty}</span>
                    </div>
                    <div style={{ fontSize: 10, color: '#667892', marginTop: 2 }}>
                      Saved: {new Date(slot.updatedAt).toLocaleString()}
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="dom-btn dom-btn-emerald" disabled={loading} onClick={() => handleLoad(slot.id)}>
                      Load
                    </button>
                    <button className="dom-btn dom-btn-danger" onClick={() => handleDelete(slot.id)}>
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
