import React, { useEffect, useRef, useState } from 'react';
import {
  Award,
  BookOpen,
  ChevronRight,
  FolderOpen,
  Globe,
  Play,
  RotateCcw,
  Settings,
  Sliders,
  Sparkles,
  Users,
  X,
} from 'lucide-react';
import { apiGetLeaderboard, apiGetMatchHistory, apiListSaves, apiLoadGame } from '../services/api';
import { GameState, PlayerAccount, SaveSlotSummary } from '../types/game';

interface Props {
  hasActiveSession: boolean;
  onResumeActiveSession: () => void;
  onOpenNewGame: (mode: 'singleplayer' | 'custom') => void;
  onQuickNewGame: () => void;
  onOpenLoad: () => void;
  onLoadedGame: (state: GameState) => void;
  onOpenMultiplayer: () => void;
  onOpenEncyclopedia: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<Props> = ({
  hasActiveSession,
  onResumeActiveSession,
  onOpenNewGame,
  onQuickNewGame,
  onOpenLoad,
  onLoadedGame,
  onOpenMultiplayer,
  onOpenEncyclopedia,
  onOpenSettings,
}) => {
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  const [latestSave, setLatestSave] = useState<SaveSlotSummary | null>(null);
  const [showStatsModal, setShowStatsModal] = useState(false);
  const [showCreditsModal, setShowCreditsModal] = useState(false);
  const [history, setHistory] = useState<Array<Record<string, unknown>>>([]);
  const [leaderboard, setLeaderboard] = useState<PlayerAccount[]>([]);

  useEffect(() => {
    apiListSaves().then((list) => {
      setLatestSave(list[0] ?? null);
    });
  }, []);

  // Animated Grand-Strategy Living World Background Canvas
  useEffect(() => {
    const canvas = bgCanvasRef.current;
    if (!canvas) return;
    let animId = 0;
    let t = 0;

    const render = () => {
      t += 0.012;
      const w = (canvas.width = window.innerWidth);
      const h = (canvas.height = window.innerHeight);
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Abyssal Ocean Gradient
      const ocean = ctx.createRadialGradient(w * 0.65, h * 0.48, 80, w * 0.55, h * 0.5, w * 0.8);
      ocean.addColorStop(0, '#133759');
      ocean.addColorStop(0.55, '#0b223a');
      ocean.addColorStop(1, '#060c16');
      ctx.fillStyle = ocean;
      ctx.fillRect(0, 0, w, h);

      // Cartographic Grid
      ctx.strokeStyle = 'rgba(212, 168, 79, 0.05)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 90) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 90) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Stylized Developing Civilization Continents & National Borders
      const ox = w * 0.36;
      const oy = h * 0.14;
      const cw = w * 0.62;
      const ch = h * 0.76;

      // Continent 1 (Imperial Heartland)
      const territories = [
        {
          color: 'rgba(45, 212, 191, 0.28)',
          border: '#2dd4bf',
          pts: [
            [ox + cw * 0.12, oy + ch * 0.3],
            [ox + cw * 0.34, oy + ch * 0.18],
            [ox + cw * 0.44, oy + ch * 0.42],
            [ox + cw * 0.25, oy + ch * 0.56],
            [ox + cw * 0.08, oy + ch * 0.48],
          ],
          city: [ox + cw * 0.26, oy + ch * 0.37, 'Aurelia Prime'],
        },
        {
          color: 'rgba(212, 168, 79, 0.26)',
          border: '#d4a84f',
          pts: [
            [ox + cw * 0.34, oy + ch * 0.18],
            [ox + cw * 0.62, oy + ch * 0.15],
            [ox + cw * 0.68, oy + ch * 0.38],
            [ox + cw * 0.44, oy + ch * 0.42],
          ],
          city: [ox + cw * 0.52, oy + ch * 0.28, 'Solari Bastion'],
        },
        {
          color: 'rgba(201, 76, 76, 0.25)',
          border: '#c94c4c',
          pts: [
            [ox + cw * 0.44, oy + ch * 0.42],
            [ox + cw * 0.68, oy + ch * 0.38],
            [ox + cw * 0.74, oy + ch * 0.66],
            [ox + cw * 0.48, oy + ch * 0.72],
            [ox + cw * 0.25, oy + ch * 0.56],
          ],
          city: [ox + cw * 0.54, oy + ch * 0.55, 'Drakor Citadel'],
        },
        {
          color: 'rgba(56, 189, 248, 0.24)',
          border: '#38bdf8',
          pts: [
            [ox + cw * 0.78, oy + ch * 0.45],
            [ox + cw * 0.94, oy + ch * 0.4],
            [ox + cw * 0.96, oy + ch * 0.65],
            [ox + cw * 0.81, oy + ch * 0.7],
          ],
          city: [ox + cw * 0.87, oy + ch * 0.55, 'Thalassia Port'],
        },
      ];

      // Coastline Glow
      for (const ter of territories) {
        ctx.beginPath();
        ter.pts.forEach(([px, py], i) => (i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)));
        ctx.closePath();
        ctx.fillStyle = ter.color;
        ctx.fill();
        ctx.strokeStyle = ter.border;
        ctx.lineWidth = 2.4;
        ctx.stroke();
      }

      // Winding River across heartland
      ctx.beginPath();
      ctx.moveTo(ox + cw * 0.4, oy + ch * 0.16);
      ctx.bezierCurveTo(
        ox + cw * 0.46,
        oy + ch * 0.35,
        ox + cw * 0.33,
        oy + ch * 0.5,
        ox + cw * 0.22,
        oy + ch * 0.62
      );
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3.2;
      ctx.stroke();

      // Mountain Range Silhouette
      for (let m = 0; m < 6; m++) {
        const mx = ox + cw * 0.35 + m * 24;
        const my = oy + ch * 0.4 + Math.sin(m) * 14;
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.moveTo(mx, my - 18);
        ctx.lineTo(mx - 15, my + 8);
        ctx.lineTo(mx + 15, my + 8);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.moveTo(mx, my - 18);
        ctx.lineTo(mx - 6, my - 7);
        ctx.lineTo(mx + 6, my - 7);
        ctx.closePath();
        ctx.fill();
      }

      // Maritime Trade Route Arc + Animated Naval Vessel
      ctx.save();
      ctx.setLineDash([7, 7]);
      ctx.strokeStyle = 'rgba(242, 203, 119, 0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      const sX = ox + cw * 0.54;
      const sY = oy + ch * 0.55;
      const eX = ox + cw * 0.87;
      const eY = oy + ch * 0.55;
      ctx.quadraticCurveTo((sX + eX) * 0.5, sY + 55, eX, eY);
      ctx.stroke();
      ctx.restore();

      const u = (Math.sin(t * 0.6) + 1) * 0.5;
      const bx = (1 - u) * (1 - u) * sX + 2 * (1 - u) * u * ((sX + eX) * 0.5) + u * u * eX;
      const by = (1 - u) * (1 - u) * sY + 2 * (1 - u) * u * (sY + 55) + u * u * eY;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(bx, by, 5, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Cities
      for (const ter of territories) {
        const [cx, cy, label] = ter.city as [number, number, string];
        const pulse = 8 + Math.sin(t * 2.5) * 2.5;
        ctx.fillStyle = 'rgba(242, 203, 119, 0.22)';
        ctx.beginPath();
        ctx.arc(cx, cy, pulse + 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f2cb77';
        ctx.beginPath();
        ctx.arc(cx, cy, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = 'bold 11px sans-serif';
        ctx.fillStyle = '#e2e8f0';
        ctx.fillText(label, cx + 10, cy + 4);
      }

      // Soft left-side vignette for crisp menu contrast
      const vig = ctx.createLinearGradient(0, 0, w * 0.55, 0);
      vig.addColorStop(0, 'rgba(6, 10, 16, 0.92)');
      vig.addColorStop(1, 'rgba(6, 10, 16, 0.15)');
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, w, h);

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  const handleContinue = async () => {
    if (hasActiveSession) {
      onResumeActiveSession();
      return;
    }
    if (latestSave) {
      const loaded = await apiLoadGame(latestSave.id);
      if (loaded) onLoadedGame(loaded);
    }
  };

  const openStats = async () => {
    setShowStatsModal(true);
    const [h, l] = await Promise.all([apiGetMatchHistory(), apiGetLeaderboard()]);
    setHistory(h);
    setLeaderboard(l);
  };

  return (
    <div className="dom-menu-screen">
      <canvas ref={bgCanvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />

      <div className="dom-menu-card">
        {/* DOMINION Heraldic Crest & Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid rgba(212, 168, 79, 0.35)' }}>
          <svg width="52" height="52" viewBox="0 0 64 64" style={{ flexShrink: 0 }}>
            <rect width="64" height="64" rx="12" fill="#0b111c" stroke="#d4a84f" strokeWidth="2.5" />
            <path d="M32 9L50 19v18c0 11.5-7.6 19.5-18 22.8C21.6 56.5 14 48.5 14 37V19L32 9z" fill="rgba(212,168,79,0.12)" stroke="#f2cb77" strokeWidth="2" />
            <path d="M32 16l9 14-9 19-9-19 9-14z" fill="#d4a84f" />
            <circle cx="32" cy="30" r="3.5" fill="#0b111c" />
          </svg>
          <div>
            <h1 className="font-display" style={{ margin: 0, fontSize: 28, fontWeight: 800, color: '#f2cb77', letterSpacing: '0.16em' }}>
              DOMINION
            </h1>
            <div style={{ fontSize: 11.5, color: '#9fb0c7', letterSpacing: '0.06em', marginTop: 2 }}>
              WORLD CIVILIZATION &amp; GRAND STRATEGY
            </div>
          </div>
        </div>

        {/* All 10 Required Main Menu Actions */}
        <div>
          <button className="dom-menu-btn primary" onClick={onQuickNewGame}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Play size={16} /> New Game
            </span>
            <ChevronRight size={16} />
          </button>

          <button
            className="dom-menu-btn"
            disabled={!hasActiveSession && !latestSave}
            onClick={handleContinue}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <RotateCcw size={15} color="#34d399" /> Continue Game
            </span>
            <span style={{ fontSize: 10.5, color: '#9fb0c7' }}>
              {hasActiveSession ? 'Resume' : latestSave ? latestSave.nationName : 'No Save'}
            </span>
          </button>

          <button className="dom-menu-btn" onClick={onOpenLoad}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <FolderOpen size={15} color="#d4a84f" /> Load Game
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={() => onOpenNewGame('singleplayer')}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Globe size={15} color="#38bdf8" /> Single Player
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={onOpenMultiplayer}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Users size={15} color="#38bdf8" /> Multiplayer
            </span>
            <span className="dom-badge" style={{ color: '#34d399', fontSize: 9.5 }}>ONLINE WS</span>
          </button>

          <button className="dom-menu-btn" onClick={() => onOpenNewGame('custom')}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Sliders size={15} color="#a78bfa" /> Custom Game
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={onOpenEncyclopedia}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <BookOpen size={15} color="#f2cb77" /> Civilization Encyclopedia
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={openStats}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Award size={15} color="#f59e0b" /> Statistics
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={onOpenSettings}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Settings size={15} color="#9fb0c7" /> Settings
            </span>
            <ChevronRight size={15} />
          </button>

          <button className="dom-menu-btn" onClick={() => setShowCreditsModal(true)}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <Sparkles size={15} color="#e879f9" /> Credits
            </span>
            <ChevronRight size={15} />
          </button>
        </div>
      </div>

      {/* Career Statistics & Hall of Fame Modal */}
      {showStatsModal && (
        <div className="dom-modal-backdrop" onClick={() => setShowStatsModal(false)}>
          <div className="dom-modal" style={{ width: 'min(760px, 94vw)' }} onClick={(e) => e.stopPropagation()}>
            <div className="dom-modal-header">
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Global Hall of Fame &amp; Match History
              </div>
              <button className="dom-btn" onClick={() => setShowStatsModal(false)}>
                <X size={15} /> Close
              </button>
            </div>
            <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div className="dom-card">
                <div style={{ fontWeight: 700, color: '#38bdf8', marginBottom: 8 }}>Commander ELO Rankings</div>
                {leaderboard.map((a, i) => (
                  <div key={a.id} className="dom-panel" style={{ padding: 7, marginBottom: 5, display: 'flex', justifyContent: 'space-between' }}>
                    <span>#{i + 1} <b>{a.username}</b> ({a.wins}W/{a.gamesPlayed}G)</span>
                    <span className="font-mono-num" style={{ color: '#f2cb77' }}>{a.elo}</span>
                  </div>
                ))}
              </div>
              <div className="dom-card">
                <div style={{ fontWeight: 700, color: '#f2cb77', marginBottom: 8 }}>Completed Campaigns</div>
                {history.length === 0 ? (
                  <div style={{ fontSize: 12, color: '#667892' }}>Complete a campaign victory to record it in the Hall of Fame!</div>
                ) : (
                  history.map((h) => (
                    <div key={String(h.id)} className="dom-panel" style={{ padding: 7, marginBottom: 5, fontSize: 11.5 }}>
                      <b style={{ color: '#34d399' }}>{String(h.winner_name)}</b> — {String(h.victory_type)} victory ({String(h.mode)})
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Credits Modal */}
      {showCreditsModal && (
        <div className="dom-modal-backdrop" onClick={() => setShowCreditsModal(false)}>
          <div className="dom-modal" style={{ width: 'min(480px, 92vw)' }} onClick={(e) => e.stopPropagation()}>
            <div className="dom-modal-header">
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                DOMINION Credits &amp; Architecture
              </div>
              <button className="dom-btn" onClick={() => setShowCreditsModal(false)}>
                <X size={15} /> Close
              </button>
            </div>
            <div className="dom-modal-body" style={{ fontSize: 12.5, color: '#cbd5e1', lineHeight: 1.6 }}>
              <p><b style={{ color: '#f2cb77' }}>DOMINION — Complete World Civilization &amp; Grand Strategy</b></p>
              <p>Built with a modular React + TypeScript + HTML5 Canvas procedural cartography engine, isomorphic real-time simulation loop, SQLite persistence, and authoritative WebSocket multiplayer.</p>
              <p style={{ color: '#9fb0c7' }}>Systems: Irregular Terrain-Driven Geography • Manual Conquest &amp; Gradual Resource Scaling • Terrain &amp; Naval Warfare • Amphibious Invasions • 7-Era Technology Tree • Diplomacy, Trade &amp; Government Simulation.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
