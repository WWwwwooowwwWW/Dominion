import React, { useMemo, useState } from 'react';
import {
  Anchor,
  Building2,
  Compass,
  Crosshair,
  Flame,
  Hammer,
  Navigation,
  PlusCircle,
  Shield,
  Ship,
  Swords,
  Users,
  Waves,
} from 'lucide-react';
import { BUILDING_BY_ID, BUILDINGS } from '../data/buildings';
import { TERRAINS } from '../data/terrains';
import { UNIT_BY_ID, UNITS } from '../data/units';
import {
  computeArmyPower,
  computeFleetPower,
  estimateCombatOdds,
  getArmyTotalUnitCount,
  getFleetTransportCapacity,
} from '../engine/combat';
import { canAfford } from '../engine/economy';
import { BuildingCategory, Fleet, GameState } from '../types/game';
import { NationFlag } from './NationFlag';

interface Props {
  state: GameState;
  selectedTerritoryId: string | null;
  selectedArmyId: string | null;
  selectedFleetId: string | null;
  onSelectArmy: (id: string | null) => void;
  onSelectFleet: (id: string | null) => void;
  onAttackOrMoveArmy: (armyId: string, targetTerritoryId: string) => void;
  onMoveFleet: (fleetId: string, targetTerritoryId: string, mission?: Fleet['mission']) => void;
  onAttackEnemyFleet: (fleetId: string, enemyFleetId: string) => void;
  onEmbarkArmy: (armyId: string, fleetId: string) => void;
  onLaunchAmphibious: (fleetId: string, targetTerritoryId: string) => void;
  onEstablishCity: (territoryId: string) => void;
  onBuildStructure: (cityId: string, buildingId: string) => void;
  onRecruitUnits: (cityId: string, unitId: string, count?: number) => void;
  onOpenFullCity: (cityId: string) => void;
  onOpenDiplomacy: () => void;
}

export const RightInfoPanel: React.FC<Props> = ({
  state,
  selectedTerritoryId,
  selectedArmyId,
  selectedFleetId,
  onSelectArmy,
  onSelectFleet,
  onAttackOrMoveArmy,
  onMoveFleet,
  onAttackEnemyFleet,
  onEmbarkArmy,
  onLaunchAmphibious,
  onEstablishCity,
  onBuildStructure,
  onRecruitUnits,
  onOpenFullCity,
  onOpenDiplomacy,
}) => {
  const [buildCat, setBuildCat] = useState<BuildingCategory>('economic');
  const [recruitDomain, setRecruitDomain] = useState<'land' | 'naval' | 'air'>('land');

  const player = state.nations[state.playerNationId];
  const territory = selectedTerritoryId ? state.territories[selectedTerritoryId] : null;
  const owner = territory?.ownerId ? state.nations[territory.ownerId] : null;
  const city = territory?.cityId ? state.cities[territory.cityId] : null;

  const myArmies = useMemo(
    () => Object.values(state.armies).filter((a) => a.nationId === state.playerNationId && !a.inBattleId),
    [state.armies, state.playerNationId]
  );
  const myFleets = useMemo(
    () => Object.values(state.fleets).filter((f) => f.nationId === state.playerNationId && !f.inBattleId),
    [state.fleets, state.playerNationId]
  );

  // Pick best eligible attacking army (adjacent or pathable)
  const eligibleArmiesForTarget = useMemo(() => {
    if (!territory || territory.isWater) return [];
    return myArmies
      .filter((a) => !a.embarkedFleetId)
      .sort((a, b) => {
        const adjA = state.territories[a.territoryId]?.landNeighbors.includes(territory.id) ? 1 : 0;
        const adjB = state.territories[b.territoryId]?.landNeighbors.includes(territory.id) ? 1 : 0;
        if (adjA !== adjB) return adjB - adjA;
        return computeArmyPower(b, false, state) - computeArmyPower(a, false, state);
      });
  }, [myArmies, state, territory]);

  const activeAttackerArmy =
    (selectedArmyId ? eligibleArmiesForTarget.find((a) => a.id === selectedArmyId) : null) ??
    eligibleArmiesForTarget[0] ??
    null;

  // Eligible nearby amphibious fleet carrying an army
  const nearbyAmphibiousFleet = useMemo(() => {
    if (!territory || territory.isWater || !territory.isCoastal) return null;
    return myFleets.find(
      (f) =>
        f.carriedArmyIds.length > 0 &&
        (f.territoryId === territory.id || state.territories[f.territoryId]?.neighbors.includes(territory.id))
    );
  }, [myFleets, state.territories, territory]);

  const activeFleet = selectedFleetId ? state.fleets[selectedFleetId] : myFleets[0] ?? null;
  const activeArmy = selectedArmyId ? state.armies[selectedArmyId] : null;

  if (!territory) {
    return (
      <aside className="dom-right-panel" style={{ padding: 14 }}>
        <div className="font-display" style={{ color: '#d4a84f', fontSize: 14, marginBottom: 8 }}>
          Tactical Reconnaissance
        </div>
        <div className="dom-card" style={{ color: '#9fb0c7', fontSize: 12.5, lineHeight: 1.55 }}>
          Select any territory, city, sea lane, army, or naval fleet on the world map to inspect intelligence and issue commands.
        </div>
      </aside>
    );
  }

  const tDef = TERRAINS[territory.terrain];
  const adjacentFriendly = territory.landNeighbors
    .map((id) => state.territories[id])
    .filter((t) => t && t.ownerId === state.playerNationId);

  const armiesInTerritory = Object.values(state.armies).filter(
    (a) => a.territoryId === territory.id && !a.embarkedFleetId
  );
  const fleetsInTerritory = Object.values(state.fleets).filter((f) => f.territoryId === territory.id);

  // Combat preview if target is wilderness or foreign
  const combatPreview =
    !territory.isWater && territory.ownerId !== state.playerNationId && activeAttackerArmy
      ? estimateCombatOdds(state, activeAttackerArmy, territory.id)
      : null;

  return (
    <aside className="dom-right-panel" style={{ padding: 12, gap: 10 }}>
      {/* Territory Header */}
      <div className="dom-card-gold">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <div>
            <div className="font-display" style={{ fontSize: 14.5, fontWeight: 700, color: '#f2cb77' }}>
              {territory.name}
            </div>
            <div style={{ fontSize: 11.5, color: '#9fb0c7', display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 2 }}>
              <span>{tDef.name}</span>
              {territory.isCoastal && <span style={{ color: '#38bdf8' }}>• Coastal</span>}
              {territory.hasRiver && <span style={{ color: '#60a5fa' }}>• River Valley</span>}
              {territory.blockadedByNationId && <span style={{ color: '#ef4444', fontWeight: 700 }}>• BLOCKADED</span>}
            </div>
          </div>
          {owner ? (
            <NationFlag color={owner.color} secondaryColor={owner.secondaryColor} emblem={owner.emblem} size={32} />
          ) : (
            <div className="dom-badge" style={{ color: territory.isWater ? '#38bdf8' : '#34d399' }}>
              {territory.isWater ? 'SEA' : 'WILDERNESS'}
            </div>
          )}
        </div>

        {/* Terrain Tactical Stats */}
        {!territory.isWater && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginTop: 9, fontSize: 11 }}>
            <div className="dom-panel" style={{ padding: '4px 7px' }}>
              <div style={{ color: '#667892', fontSize: 10 }}>Defense</div>
              <div className="font-mono-num" style={{ color: '#38bdf8', fontWeight: 700 }}>
                +{Math.round(tDef.defenseBonus * 100 + territory.fortLevel * 35)}%
              </div>
            </div>
            <div className="dom-panel" style={{ padding: '4px 7px' }}>
              <div style={{ color: '#667892', fontSize: 10 }}>Strategic</div>
              <div className="font-mono-num" style={{ color: '#f2cb77', fontWeight: 700 }}>
                {territory.strategicValue}/10
              </div>
            </div>
            <div className="dom-panel" style={{ padding: '4px 7px' }}>
              <div style={{ color: '#667892', fontSize: 10 }}>Difficulty</div>
              <div className="font-mono-num" style={{ color: '#f59e0b', fontWeight: 700 }}>
                {territory.conquestDifficulty}/10
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Selected Army Quick Controller */}
      {activeArmy && (
        <div className="dom-card" style={{ borderColor: 'rgba(52, 211, 153, 0.45)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <div style={{ fontWeight: 700, fontSize: 12.5, color: '#34d399', display: 'flex', alignItems: 'center', gap: 5 }}>
              <Swords size={14} /> {activeArmy.name}
            </div>
            <button className="dom-btn" style={{ padding: '2px 7px', fontSize: 10 }} onClick={() => onSelectArmy(null)}>
              Deselect
            </button>
          </div>
          <div style={{ fontSize: 11.5, color: '#cbd5e1', marginBottom: 6 }}>
            Location: <b>{state.territories[activeArmy.territoryId]?.name}</b> • Power{' '}
            <span className="font-mono-num" style={{ color: '#f2cb77' }}>
              {Math.round(computeArmyPower(activeArmy, false, state))}
            </span>{' '}
            ({getArmyTotalUnitCount(activeArmy)} units)
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 7 }}>
            {activeArmy.units.map((u) => (
              <span key={u.unitId} className="dom-badge" style={{ fontSize: 10.5 }}>
                {u.count}x {UNIT_BY_ID[u.unitId]?.name ?? u.unitId}
              </span>
            ))}
          </div>
          {/* Move / Attack / Embark actions */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {territory.id !== activeArmy.territoryId && !territory.isWater && activeArmy.nationId === state.playerNationId && (
              <button
                className={territory.ownerId === state.playerNationId ? 'dom-btn dom-btn-emerald' : 'dom-btn dom-btn-danger'}
                style={{ flex: 1 }}
                onClick={() => onAttackOrMoveArmy(activeArmy.id, territory.id)}
              >
                <Crosshair size={13} />
                {territory.ownerId === state.playerNationId ? 'March Army Here' : 'Order Army to Attack'}
              </button>
            )}
            {state.territories[activeArmy.territoryId]?.isCoastal &&
              !activeArmy.embarkedFleetId &&
              myFleets
                .filter(
                  (f) =>
                    getFleetTransportCapacity(f) > 0 &&
                    (f.territoryId === activeArmy.territoryId ||
                      state.territories[activeArmy.territoryId]?.neighbors.includes(f.territoryId))
                )
                .map((f) => (
                  <button
                    key={f.id}
                    className="dom-btn dom-btn-cobalt"
                    style={{ width: '100%' }}
                    onClick={() => onEmbarkArmy(activeArmy.id, f.id)}
                  >
                    <Ship size={13} /> Embark onto {f.name}
                  </button>
                ))}
          </div>
        </div>
      )}

      {/* Selected Fleet Quick Controller */}
      {activeFleet && (territory.isWater || territory.isCoastal) && (
        <div className="dom-card" style={{ borderColor: 'rgba(56, 189, 248, 0.45)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
            <div style={{ fontWeight: 700, fontSize: 12.5, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 5 }}>
              <Anchor size={14} /> {activeFleet.name}
            </div>
            <span className="dom-badge" style={{ fontSize: 10 }}>
              Pow {Math.round(computeFleetPower(activeFleet, false, state))} • Cap {getFleetTransportCapacity(activeFleet)}
            </span>
          </div>
          <div style={{ fontSize: 11, color: '#9fb0c7', marginBottom: 6 }}>
            Stationed: <b>{state.territories[activeFleet.territoryId]?.name}</b> • Mission:{' '}
            <b style={{ color: '#e2e8f0', textTransform: 'capitalize' }}>{activeFleet.mission}</b>
            {activeFleet.carriedArmyIds.length > 0 && (
              <span style={{ color: '#34d399', display: 'block', marginTop: 2 }}>
                Carrying embarked army ({activeFleet.carriedArmyIds.length}) — ready for coastal landing!
              </span>
            )}
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {(territory.isWater || (territory.isCoastal && territory.ownerId === state.playerNationId)) &&
              territory.id !== activeFleet.territoryId && (
                <>
                  <button
                    className="dom-btn dom-btn-cobalt"
                    style={{ flex: 1 }}
                    onClick={() => onMoveFleet(activeFleet.id, territory.id, 'idle')}
                  >
                    <Navigation size={12} /> Sail Here
                  </button>
                  {territory.isWater && (
                    <>
                      <button
                        className="dom-btn"
                        onClick={() => onMoveFleet(activeFleet.id, territory.id, 'patrol')}
                      >
                        Patrol
                      </button>
                      <button
                        className="dom-btn dom-btn-danger"
                        onClick={() => onMoveFleet(activeFleet.id, territory.id, 'blockade')}
                      >
                        Blockade
                      </button>
                    </>
                  )}
                </>
              )}
          </div>
        </div>
      )}

      {/* ==================== CASE 1: SEA ZONE ==================== */}
      {territory.isWater && (
        <div className="dom-card">
          <div style={{ fontWeight: 700, fontSize: 12.5, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
            <Waves size={14} /> Maritime Sector
          </div>
          <p style={{ fontSize: 11.5, color: '#9fb0c7', margin: '0 0 8px' }}>{tDef.description}</p>
          {territory.weatherStorm && (
            <div className="dom-badge" style={{ color: '#f59e0b', marginBottom: 8 }}>
              Active Ocean Storm — Naval speed reduced by 38%
            </div>
          )}
          {fleetsInTerritory.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {fleetsInTerritory.map((fl) => {
                const fn = state.nations[fl.nationId];
                const isMine = fl.nationId === state.playerNationId;
                return (
                  <div key={fl.id} className="dom-panel" style={{ padding: 7, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12, color: fn?.color }}>{fl.name}</div>
                      <div style={{ fontSize: 10.5, color: '#9fb0c7' }}>
                        {fn?.name} • Power {Math.round(computeFleetPower(fl, false, state))}
                      </div>
                    </div>
                    {isMine ? (
                      <button className="dom-btn" onClick={() => onSelectFleet(fl.id)}>
                        Command
                      </button>
                    ) : (
                      activeFleet && (
                        <button
                          className="dom-btn dom-btn-danger"
                          onClick={() => onAttackEnemyFleet(activeFleet.id, fl.id)}
                        >
                          Attack Fleet
                        </button>
                      )
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ fontSize: 11.5, color: '#667892' }}>No fleets currently positioned in these waters.</div>
          )}
        </div>
      )}

      {/* ==================== CASE 2: UNCLAIMED WILDERNESS ==================== */}
      {!territory.isWater && !owner && (
        <>
          <div className="dom-card">
            <div style={{ fontSize: 12, fontWeight: 700, color: '#34d399', marginBottom: 6 }}>
              Unclaimed Wilderness Intelligence
            </div>
            <div style={{ fontSize: 11.5, color: '#cbd5e1', display: 'flex', flexDirection: 'column', gap: 4 }}>
              <div>
                Population Capacity:{' '}
                <span className="font-mono-num" style={{ color: '#f2cb77' }}>
                  {territory.populationCapacity.toLocaleString()}
                </span>
              </div>
              <div>
                Wilderness Resistance:{' '}
                <span className="font-mono-num" style={{ color: '#f59e0b' }}>
                  ~{Math.round(territory.wildernessGarrison)} Defenders
                </span>
              </div>
              <div>
                Available Deposits:{' '}
                {territory.deposits.length > 0 ? (
                  <span style={{ color: '#34d399', fontWeight: 600 }}>
                    {territory.deposits.map((d) => `${d.resource.toUpperCase()} (${d.richness}x)`).join(', ')}
                  </span>
                ) : (
                  <span style={{ color: '#667892' }}>Standard terrain yields only</span>
                )}
              </div>
              <div>
                Adjacent Friendly Regions:{' '}
                <span style={{ color: adjacentFriendly.length > 0 ? '#34d399' : '#ef4444', fontWeight: 600 }}>
                  {adjacentFriendly.length > 0
                    ? adjacentFriendly.map((t) => t.name).join(', ')
                    : 'None (requires land route or naval landing)'}
                </span>
              </div>
            </div>
          </div>

          <div className="dom-card-gold">
            <div style={{ fontSize: 12, fontWeight: 700, color: '#f2cb77', marginBottom: 6 }}>
              Conquest Command
            </div>
            {eligibleArmiesForTarget.length > 0 && combatPreview ? (
              <>
                <label style={{ fontSize: 11, color: '#9fb0c7', display: 'block', marginBottom: 4 }}>
                  Commit Army:
                </label>
                <select
                  className="dom-select"
                  style={{ width: '100%', marginBottom: 8 }}
                  value={activeAttackerArmy?.id ?? ''}
                  onChange={(e) => onSelectArmy(e.target.value)}
                >
                  {eligibleArmiesForTarget.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({state.territories[a.territoryId]?.name} • Pow {Math.round(computeArmyPower(a, false, state))})
                    </option>
                  ))}
                </select>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, marginBottom: 6 }}>
                  <span>Attacker: <b className="font-mono-num" style={{ color: '#34d399' }}>{combatPreview.attackerPower}</b></span>
                  <span>Win Odds: <b className="font-mono-num" style={{ color: '#f2cb77' }}>{combatPreview.winProbability}%</b></span>
                  <span>Defender: <b className="font-mono-num" style={{ color: '#ef4444' }}>{combatPreview.defenderPower}</b></span>
                </div>
                {combatPreview.riverPenalty && (
                  <div style={{ fontSize: 10.5, color: '#f59e0b', marginBottom: 6 }}>
                    Warning: River crossing reduces attacker power (-25%) without a Bridge.
                  </div>
                )}
                <button
                  className="dom-btn dom-btn-danger"
                  style={{ width: '100%', padding: '9px 12px', fontSize: 12.5 }}
                  onClick={() => activeAttackerArmy && onAttackOrMoveArmy(activeAttackerArmy.id, territory.id)}
                >
                  <Swords size={15} /> ATTACK TERRITORY
                </button>
              </>
            ) : (
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Recruit or station an army nearby to conquer this wilderness.
              </div>
            )}

            {nearbyAmphibiousFleet && (
              <button
                className="dom-btn dom-btn-cobalt"
                style={{ width: '100%', marginTop: 7, padding: '9px 12px' }}
                onClick={() => onLaunchAmphibious(nearbyAmphibiousFleet.id, territory.id)}
              >
                <Anchor size={14} /> LAUNCH AMPHIBIOUS INVASION
              </button>
            )}
          </div>
        </>
      )}

      {/* ==================== CASE 3: FOREIGN AI / PLAYER NATION ==================== */}
      {!territory.isWater && owner && owner.id !== state.playerNationId && (
        <>
          <div className="dom-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: owner.color }}>{owner.name}</div>
                <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                  Leader: {owner.leaderName} • {owner.aiPersonality}
                </div>
              </div>
              <button className="dom-btn" style={{ padding: '4px 8px', fontSize: 11 }} onClick={onOpenDiplomacy}>
                Diplomacy
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, fontSize: 11.5, marginTop: 6 }}>
              <div className="dom-panel" style={{ padding: 6 }}>
                <div style={{ color: '#667892', fontSize: 10 }}>Est. Nation Strength</div>
                <div className="font-mono-num" style={{ color: '#ef4444', fontWeight: 700 }}>{owner.stats.militaryPower}</div>
              </div>
              <div className="dom-panel" style={{ padding: 6 }}>
                <div style={{ color: '#667892', fontSize: 10 }}>Local Garrisons</div>
                <div className="font-mono-num" style={{ color: '#f59e0b', fontWeight: 700 }}>
                  {armiesInTerritory.length > 0
                    ? `${armiesInTerritory.reduce((s, a) => s + getArmyTotalUnitCount(a), 0)} units`
                    : 'Light Garrison'}
                </div>
              </div>
            </div>

            <div style={{ fontSize: 11, color: '#9fb0c7', marginTop: 7 }}>
              Resources:{' '}
              <span style={{ color: '#34d399' }}>
                {territory.deposits.length > 0 ? territory.deposits.map((d) => d.resource).join(', ') : 'Regional Agriculture'}
              </span>
              <div style={{ marginTop: 3 }}>
                Neighbors: {territory.landNeighbors.map((id) => state.territories[id]?.name).slice(0, 4).join(', ')}
              </div>
            </div>
          </div>

          <div className="dom-card-gold">
            <div style={{ fontSize: 12, fontWeight: 700, color: '#ef4444', marginBottom: 6 }}>
              Military Operations vs {owner.adjective}
            </div>
            {eligibleArmiesForTarget.length > 0 && combatPreview ? (
              <>
                <select
                  className="dom-select"
                  style={{ width: '100%', marginBottom: 7 }}
                  value={activeAttackerArmy?.id ?? ''}
                  onChange={(e) => onSelectArmy(e.target.value)}
                >
                  {eligibleArmiesForTarget.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} (Pow {Math.round(computeArmyPower(a, false, state))})
                    </option>
                  ))}
                </select>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, marginBottom: 7 }}>
                  <span>Ours: <b className="font-mono-num" style={{ color: '#34d399' }}>{combatPreview.attackerPower}</b></span>
                  <span>Win Odds: <b className="font-mono-num" style={{ color: '#f2cb77' }}>{combatPreview.winProbability}%</b></span>
                  <span>Def: <b className="font-mono-num" style={{ color: '#ef4444' }}>{combatPreview.defenderPower}</b></span>
                </div>
                <button
                  className="dom-btn dom-btn-danger"
                  style={{ width: '100%', padding: '9px 12px', fontSize: 12.5 }}
                  onClick={() => activeAttackerArmy && onAttackOrMoveArmy(activeAttackerArmy.id, territory.id)}
                >
                  <Swords size={15} /> ATTACK NATION
                </button>
              </>
            ) : (
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>No land armies available to strike overland.</div>
            )}

            {nearbyAmphibiousFleet && (
              <button
                className="dom-btn dom-btn-cobalt"
                style={{ width: '100%', marginTop: 7, padding: '9px 12px' }}
                onClick={() => onLaunchAmphibious(nearbyAmphibiousFleet.id, territory.id)}
              >
                <Anchor size={14} /> LAUNCH AMPHIBIOUS INVASION
              </button>
            )}
          </div>
        </>
      )}

      {/* ==================== CASE 4: PLAYER-OWNED TERRITORY & CITY ==================== */}
      {!territory.isWater && owner && owner.id === state.playerNationId && (
        <>
          {/* Stationed Armies & Fleets */}
          {(armiesInTerritory.length > 0 || fleetsInTerritory.length > 0) && (
            <div className="dom-card">
              <div style={{ fontSize: 11.5, fontWeight: 700, color: '#d4a84f', marginBottom: 6 }}>
                Stationed Forces
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                {armiesInTerritory.map((a) => (
                  <div key={a.id} className="dom-panel" style={{ padding: '5px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 11.5, fontWeight: 700 }}>{a.name}</div>
                      <div style={{ fontSize: 10, color: '#9fb0c7' }}>
                        {getArmyTotalUnitCount(a)} units • Pow {Math.round(computeArmyPower(a, false, state))}
                      </div>
                    </div>
                    <button
                      className={`dom-btn ${selectedArmyId === a.id ? 'dom-btn-gold' : ''}`}
                      style={{ padding: '3px 8px', fontSize: 10.5 }}
                      onClick={() => {
                        onSelectArmy(a.id);
                        onSelectFleet(null);
                      }}
                    >
                      {selectedArmyId === a.id ? 'Selected' : 'Select'}
                    </button>
                  </div>
                ))}
                {fleetsInTerritory.map((fl) => (
                  <div key={fl.id} className="dom-panel" style={{ padding: '5px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 11.5, fontWeight: 700, color: '#38bdf8' }}>{fl.name}</div>
                      <div style={{ fontSize: 10, color: '#9fb0c7' }}>
                        {fl.ships.reduce((s, x) => s + x.count, 0)} ships • Cap {getFleetTransportCapacity(fl)}
                      </div>
                    </div>
                    <button
                      className={`dom-btn ${selectedFleetId === fl.id ? 'dom-btn-cobalt' : ''}`}
                      style={{ padding: '3px 8px', fontSize: 10.5 }}
                      onClick={() => {
                        onSelectFleet(fl.id);
                        onSelectArmy(null);
                      }}
                    >
                      {selectedFleetId === fl.id ? 'Selected' : 'Select'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* City Management or Establish City */}
          {!city ? (
            <div className="dom-card">
              <div style={{ fontWeight: 700, fontSize: 12.5, color: '#f2cb77', marginBottom: 5 }}>
                Provincial Territory
              </div>
              <p style={{ fontSize: 11.5, color: '#9fb0c7', margin: '0 0 9px' }}>
                This conquered province produces natural resources ({territory.deposits.map((d) => d.resource).join(', ') || tDef.name}). Develop a city here to construct buildings, recruit armies, and grow your population.
              </p>
              <button className="dom-btn dom-btn-gold" style={{ width: '100%' }} onClick={() => onEstablishCity(territory.id)}>
                <PlusCircle size={14} /> Establish City (90 Gold, 60 Wood, 35 Stone)
              </button>
            </div>
          ) : (
            <>
              <div className="dom-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 7 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <Building2 size={14} /> {city.name} {city.isCapital && <span className="dom-badge" style={{ color: '#f2cb77' }}>Capital</span>}
                    </div>
                    <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                      Tier {city.tier} City • Pop{' '}
                      <span className="font-mono-num" style={{ color: '#f8fafc' }}>{city.population.toLocaleString()}</span> / {city.housing.toLocaleString()}
                    </div>
                  </div>
                  <button className="dom-btn" style={{ padding: '4px 8px', fontSize: 11 }} onClick={() => onOpenFullCity(city.id)}>
                    Manage
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 5, fontSize: 10.5 }}>
                  <div className="dom-panel" style={{ padding: '4px 6px' }}>
                    <span style={{ color: '#667892' }}>Happy</span>{' '}
                    <b className="font-mono-num" style={{ color: '#34d399' }}>{city.happiness}%</b>
                  </div>
                  <div className="dom-panel" style={{ padding: '4px 6px' }}>
                    <span style={{ color: '#667892' }}>Health</span>{' '}
                    <b className="font-mono-num" style={{ color: '#38bdf8' }}>{city.health}%</b>
                  </div>
                  <div className="dom-panel" style={{ padding: '4px 6px' }}>
                    <span style={{ color: '#667892' }}>Infra</span>{' '}
                    <b className="font-mono-num" style={{ color: '#f2cb77' }}>{city.infrastructure}%</b>
                  </div>
                </div>

                {city.queue.length > 0 && (
                  <div style={{ marginTop: 8, paddingTop: 7, borderTop: '1px solid #223044' }}>
                    <div style={{ fontSize: 10.5, color: '#f59e0b', marginBottom: 3 }}>
                      Building: {BUILDING_BY_ID[city.queue[0].buildingId]?.name} Lv.{city.queue[0].targetLevel}
                    </div>
                    <div className="dom-progress">
                      <div
                        className="dom-progress-fill"
                        style={{
                          width: `${Math.min(100, (city.queue[0].progress / city.queue[0].totalTime) * 100)}%`,
                          background: '#f59e0b',
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Quick Construct Buildings */}
              <div className="dom-card">
                <div style={{ fontSize: 12, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 6 }}>
                  <Hammer size={13} /> Construct Infrastructure
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, marginBottom: 8 }}>
                  {(['economic', 'agricultural', 'industrial', 'residential', 'scientific', 'infrastructure', 'government', 'military'] as BuildingCategory[]).map(
                    (cat) => (
                      <button
                        key={cat}
                        className={`dom-overlay-btn ${buildCat === cat ? 'active' : ''}`}
                        style={{ padding: '3px 6px', fontSize: 10, textTransform: 'capitalize' }}
                        onClick={() => setBuildCat(cat)}
                      >
                        {cat}
                      </button>
                    )
                  )}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5, maxHeight: 190, overflowY: 'auto' }}>
                  {BUILDINGS.filter((b) => b.category === buildCat).map((b) => {
                    const cur = city.buildings.find((x) => x.buildingId === b.id);
                    const lvl = cur?.level ?? 0;
                    const lockedTech = b.requiredTech && !player.unlockedTechs.includes(b.requiredTech);
                    const lockedCoast = b.coastalOnly && !territory.isCoastal;
                    const maxed = lvl >= b.maxLevel;
                    const affordable = canAfford(player, b.cost);
                    const costStr = Object.entries(b.cost)
                      .map(([k, v]) => `${v} ${k}`)
                      .join(', ');
                    return (
                      <div
                        key={b.id}
                        className="dom-panel"
                        style={{ padding: '6px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6 }}
                      >
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: 11.5, fontWeight: 700, color: '#e2e8f0' }}>
                            {b.name} {lvl > 0 && <span style={{ color: '#34d399' }}>Lv.{lvl}</span>}
                          </div>
                          <div style={{ fontSize: 10, color: '#9fb0c7' }}>{costStr}</div>
                          {lockedTech && <div style={{ fontSize: 9.5, color: '#ef4444' }}>Needs Tech: {b.requiredTech}</div>}
                          {lockedCoast && <div style={{ fontSize: 9.5, color: '#38bdf8' }}>Coastal cities only</div>}
                        </div>
                        <button
                          className="dom-btn dom-btn-gold"
                          style={{ padding: '4px 8px', fontSize: 10.5 }}
                          disabled={Boolean(lockedTech || lockedCoast || maxed || !affordable)}
                          onClick={() => onBuildStructure(city.id, b.id)}
                        >
                          {maxed ? 'Max' : lvl > 0 ? 'Upgrade' : 'Build'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Recruit Land / Naval / Air */}
              <div className="dom-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 5 }}>
                    <Shield size={13} /> Recruit Forces
                  </span>
                  <div style={{ display: 'flex', gap: 3 }}>
                    {(['land', 'naval', 'air'] as const).map((dom) => (
                      <button
                        key={dom}
                        className={`dom-overlay-btn ${recruitDomain === dom ? 'active' : ''}`}
                        style={{ padding: '2px 6px', fontSize: 10, textTransform: 'capitalize' }}
                        onClick={() => setRecruitDomain(dom)}
                      >
                        {dom}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5, maxHeight: 165, overflowY: 'auto' }}>
                  {UNITS.filter((u) => u.domain === recruitDomain).map((u) => {
                    const lockedTech = u.requiredTech && !player.unlockedTechs.includes(u.requiredTech);
                    const needsHarbor =
                      u.domain === 'naval' &&
                      !city.buildings.some((b) => b.buildingId === 'ports' || b.buildingId === 'naval_bases');
                    const needsAir =
                      u.domain === 'air' &&
                      !city.buildings.some((b) => b.buildingId === 'airbases' || b.buildingId === 'airports');
                    const affordable = canAfford(player, u.cost);
                    return (
                      <div
                        key={u.id}
                        className="dom-panel"
                        style={{ padding: '6px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6 }}
                      >
                        <div>
                          <div style={{ fontSize: 11.5, fontWeight: 700 }}>
                            {u.name}{' '}
                            <span className="font-mono-num" style={{ fontSize: 10, color: '#38bdf8' }}>
                              Str {u.strength}
                            </span>
                          </div>
                          <div style={{ fontSize: 10, color: '#9fb0c7' }}>
                            {Object.entries(u.cost)
                              .map(([k, v]) => `${v} ${k}`)
                              .join(', ')}
                          </div>
                          {lockedTech && <div style={{ fontSize: 9.5, color: '#ef4444' }}>Needs: {u.requiredTech}</div>}
                          {needsHarbor && <div style={{ fontSize: 9.5, color: '#38bdf8' }}>Build Port / Naval Base</div>}
                          {needsAir && <div style={{ fontSize: 9.5, color: '#38bdf8' }}>Build Airbase / Airport</div>}
                        </div>
                        <button
                          className="dom-btn dom-btn-emerald"
                          style={{ padding: '4px 8px', fontSize: 10.5 }}
                          disabled={Boolean(lockedTech || needsHarbor || needsAir || !affordable)}
                          onClick={() => onRecruitUnits(city.id, u.id, 1)}
                        >
                          Train +1
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </>
      )}
    </aside>
  );
};
