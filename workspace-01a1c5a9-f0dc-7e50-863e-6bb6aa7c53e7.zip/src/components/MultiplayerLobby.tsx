import React, { useEffect, useState } from 'react';
import { Award, Globe, KeyRound, MessageSquare, Play, Plus, Users, Wifi, X } from 'lucide-react';
import { ERAS } from '../data/eras';
import { apiAuth, apiGetLeaderboard } from '../services/api';
import { wsClient } from '../services/wsClient';
import { EraId, GameState, MapSize, MultiplayerLobby as LobbyType, PlayerAccount } from '../types/game';
import { NationFlag } from './NationFlag';

interface Props {
  onMatchStarted: (state: GameState) => void;
  onClose: () => void;
}

export const MultiplayerLobby: React.FC<Props> = ({ onMatchStarted, onClose }) => {
  const [account, setAccount] = useState<PlayerAccount | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');

  const [wsStatus, setWsStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [lobbies, setLobbies] = useState<LobbyType[]>([]);
  const [currentLobby, setCurrentLobby] = useState<LobbyType | null>(null);
  const [leaderboard, setLeaderboard] = useState<PlayerAccount[]>([]);

  const [matchName, setMatchName] = useState('Grand World Campaign');
  const [isPublic, setIsPublic] = useState(true);
  const [mapSize, setMapSize] = useState<MapSize>('medium');
  const [aiCount, setAiCount] = useState(4);
  const [startingEra, setStartingEra] = useState<EraId>('ancient');
  const [inviteInput, setInviteInput] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [nationName, setNationName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    apiGetLeaderboard().then(setLeaderboard);
  }, []);

  useEffect(() => {
    const unsub = wsClient.subscribe((msg) => {
      if (msg.type === 'hello' || msg.type === 'identified' || msg.type === 'lobbies_list') {
        if (msg.lobbies) setLobbies(msg.lobbies);
      } else if (msg.type === 'lobby_joined' || msg.type === 'lobby_updated' || msg.type === 'lobby_chat') {
        if (msg.lobby) setCurrentLobby(msg.lobby);
      } else if (msg.type === 'lobby_left') {
        setCurrentLobby(null);
        if (msg.lobbies) setLobbies(msg.lobbies);
      } else if (msg.type === 'match_started' && msg.state) {
        onMatchStarted(msg.state);
      } else if (msg.type === 'error' && msg.message) {
        setErrorMsg(msg.message);
      }
    });
    return unsub;
  }, [onMatchStarted]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    const res = await apiAuth(username, password);
    if (!res.ok || !res.account) {
      setAuthError(res.error ?? 'Authentication failed.');
      return;
    }
    setAccount(res.account);
    setNationName(`${res.account.username} Empire`);
    setWsStatus('connecting');
    try {
      await wsClient.connect(res.account.username);
      setWsStatus('connected');
      wsClient.send({ type: 'list_lobbies' });
    } catch (err) {
      setWsStatus('disconnected');
      setErrorMsg((err as Error).message);
    }
  };

  const createLobby = () => {
    if (!account) return;
    setErrorMsg('');
    wsClient.send({
      type: 'create_lobby',
      name: matchName,
      isPublic,
      mapSize,
      aiCount,
      startingEra,
      nationName: nationName || `${account.username} Empire`,
      color: account.preferredColor,
      emblem: account.preferredEmblem,
    });
  };

  const joinById = (lobbyId: string) => {
    setErrorMsg('');
    wsClient.send({
      type: 'join_lobby',
      lobbyId,
      nationName: nationName || `${account?.username} Realm`,
    });
  };

  const joinByCode = () => {
    if (!inviteInput.trim()) return;
    setErrorMsg('');
    wsClient.send({
      type: 'join_lobby',
      inviteCode: inviteInput.trim().toUpperCase(),
      nationName: nationName || `${account?.username} Realm`,
    });
  };

  const sendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    wsClient.send({ type: 'chat', message: chatInput });
    setChatInput('');
  };

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" style={{ width: 'min(1040px, 95vw)' }} onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Wifi size={20} color="#38bdf8" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                DOMINION Online Multiplayer Network
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Authoritative WebSocket Matches • Public &amp; Private Invite Rooms • Global Player Rankings
              </div>
            </div>
          </div>
          <button
            className="dom-btn"
            onClick={() => {
              if (currentLobby) wsClient.send({ type: 'leave_lobby' });
              onClose();
            }}
          >
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 16 }}>
          {/* Left Column: Auth OR Lobby Browser OR Active Room */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {errorMsg && (
              <div className="dom-card" style={{ borderColor: '#ef4444', color: '#fca5a5', fontSize: 12 }}>
                {errorMsg}
              </div>
            )}

            {!account ? (
              <form className="dom-card" onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#f2cb77' }}>
                  Player Account Sign-In / Registration
                </div>
                <p style={{ fontSize: 12, color: '#9fb0c7', margin: 0 }}>
                  Enter a username and password to sign in or automatically create a persistent ranked DOMINION account.
                </p>
                {authError && <div style={{ fontSize: 12, color: '#ef4444' }}>{authError}</div>}
                <input
                  className="dom-input"
                  placeholder="Commander Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
                <input
                  className="dom-input"
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button className="dom-btn dom-btn-gold" type="submit" style={{ padding: '9px 14px' }}>
                  Connect to Multiplayer Server
                </button>
              </form>
            ) : currentLobby ? (
              <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div className="font-display" style={{ fontSize: 15, fontWeight: 700, color: '#f2cb77' }}>
                      {currentLobby.name}
                    </div>
                    <div style={{ fontSize: 11.5, color: '#38bdf8' }}>
                      Invite Code: <b className="font-mono-num" style={{ color: '#f2cb77' }}>{currentLobby.inviteCode}</b> •{' '}
                      {currentLobby.isPublic ? 'Public Match' : 'Private Match'} • {currentLobby.mapSize.toUpperCase()} Map
                    </div>
                  </div>
                  <button className="dom-btn dom-btn-danger" onClick={() => wsClient.send({ type: 'leave_lobby' })}>
                    Leave Room
                  </button>
                </div>

                {/* Human Player Slots */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                  <div style={{ fontSize: 11.5, fontWeight: 700, color: '#9fb0c7' }}>
                    Connected Human Commanders ({currentLobby.players.length}/{currentLobby.maxPlayers}) + {currentLobby.aiCount} AI Fill Nations
                  </div>
                  {currentLobby.players.map((pl) => (
                    <div
                      key={pl.username}
                      className="dom-panel"
                      style={{ padding: '6px 9px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <NationFlag color={pl.color} emblem={pl.emblem} size={24} />
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 12 }}>
                            {pl.username}{' '}
                            {pl.username === currentLobby.hostUsername && (
                              <span className="dom-badge" style={{ color: '#f2cb77', fontSize: 9.5 }}>HOST</span>
                            )}
                          </div>
                          <div style={{ fontSize: 10.5, color: '#9fb0c7' }}>{pl.nationName}</div>
                        </div>
                      </div>
                      <span className="dom-badge" style={{ color: pl.ready ? '#34d399' : '#f59e0b' }}>
                        {pl.ready ? 'READY' : 'WAITING'}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Live Chat */}
                <div className="dom-panel" style={{ padding: 8 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#9fb0c7', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
                    <MessageSquare size={12} /> Lobby Chat
                  </div>
                  <div style={{ maxHeight: 130, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 3, fontSize: 11.5, marginBottom: 7 }}>
                    {currentLobby.chat.map((c) => (
                      <div key={c.id}>
                        <b style={{ color: c.username === 'SYSTEM' ? '#38bdf8' : '#f2cb77' }}>{c.username}:</b>{' '}
                        <span style={{ color: '#cbd5e1' }}>{c.message}</span>
                      </div>
                    ))}
                  </div>
                  <form onSubmit={sendChat} style={{ display: 'flex', gap: 6 }}>
                    <input
                      className="dom-input"
                      style={{ flex: 1 }}
                      placeholder="Send message to lobby..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                    />
                    <button className="dom-btn" type="submit">Send</button>
                  </form>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                  <button
                    className="dom-btn"
                    onClick={() => wsClient.send({ type: 'toggle_ready', nationName })}
                  >
                    Toggle Ready
                  </button>
                  {currentLobby.hostUsername === account.username && (
                    <button
                      className="dom-btn dom-btn-gold"
                      style={{ padding: '8px 18px' }}
                      onClick={() => wsClient.send({ type: 'start_match' })}
                    >
                      <Play size={14} /> Launch Authoritative Match
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* Signed-in Status + Create Match */}
                <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: 700, color: '#34d399', fontSize: 12.5 }}>
                      Connected as {account.username} ({wsStatus})
                    </div>
                    <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                      ELO: <b className="font-mono-num" style={{ color: '#f2cb77' }}>{account.elo}</b> • Wins: {account.wins} / {account.gamesPlayed}
                    </div>
                  </div>
                  <input
                    className="dom-input"
                    value={nationName}
                    onChange={(e) => setNationName(e.target.value)}
                    placeholder="Your Nation Name"
                    style={{ width: 175 }}
                  />
                </div>

                <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Plus size={14} /> Host New Online Match
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                    <input className="dom-input" value={matchName} onChange={(e) => setMatchName(e.target.value)} placeholder="Lobby Name" />
                    <select className="dom-select" value={isPublic ? 'pub' : 'priv'} onChange={(e) => setIsPublic(e.target.value === 'pub')}>
                      <option value="pub">Public Lobby</option>
                      <option value="priv">Private (Invite Code Only)</option>
                    </select>
                    <select className="dom-select" value={mapSize} onChange={(e) => setMapSize(e.target.value as MapSize)}>
                      <option value="small">Small Map</option>
                      <option value="medium">Medium Map</option>
                      <option value="large">Large Map</option>
                    </select>
                    <select className="dom-select" value={startingEra} onChange={(e) => setStartingEra(e.target.value as EraId)}>
                      {ERAS.map((e) => (
                        <option key={e.id} value={e.id}>Start: {e.name}</option>
                      ))}
                    </select>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                      Optional AI Backfill Nations: <b>{aiCount}</b> (clearly labeled AI)
                      <input
                        type="range"
                        min={0}
                        max={8}
                        value={aiCount}
                        onChange={(e) => setAiCount(Number(e.target.value))}
                        style={{ marginLeft: 8, verticalAlign: 'middle', accentColor: '#d4a84f' }}
                      />
                    </span>
                    <button className="dom-btn dom-btn-gold" onClick={createLobby}>
                      <Globe size={13} /> Create Lobby
                    </button>
                  </div>
                </div>

                {/* Join via Invite Code + Public Match Browser */}
                <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <Users size={14} /> Open Public Lobbies ({lobbies.length})
                    </span>
                    <div style={{ display: 'flex', gap: 5 }}>
                      <input
                        className="dom-input font-mono-num"
                        style={{ width: 120 }}
                        placeholder="DOM-XXXX"
                        value={inviteInput}
                        onChange={(e) => setInviteInput(e.target.value)}
                      />
                      <button className="dom-btn" onClick={joinByCode}>
                        <KeyRound size={12} /> Join Code
                      </button>
                    </div>
                  </div>
                  {lobbies.length === 0 ? (
                    <div style={{ fontSize: 11.5, color: '#667892', padding: 8 }}>
                      No public lobbies open yet — create one above and invite friends using the generated Invite Code!
                    </div>
                  ) : (
                    lobbies.map((l) => (
                      <div key={l.id} className="dom-panel" style={{ padding: '7px 10px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 12.5 }}>{l.name}</div>
                          <div style={{ fontSize: 10.5, color: '#9fb0c7' }}>
                            Host: {l.hostUsername} • {l.players.length}/{l.maxPlayers} Players • {l.mapSize}
                          </div>
                        </div>
                        <button className="dom-btn dom-btn-emerald" onClick={() => joinById(l.id)}>
                          Join Match
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>

          {/* Right Column: Global ELO Leaderboard */}
          <div className="dom-card" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 13.5, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Award size={16} /> Global Commander Rankings
            </div>
            <div style={{ fontSize: 11, color: '#9fb0c7' }}>
              Live SQLite player accounts ranked by competitive multiplayer ELO rating
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 4 }}>
              {leaderboard.map((acc, idx) => (
                <div
                  key={acc.id}
                  className="dom-panel"
                  style={{ padding: '7px 9px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span className="font-mono-num" style={{ color: idx < 3 ? '#f2cb77' : '#667892', fontWeight: 700, width: 18 }}>
                      #{idx + 1}
                    </span>
                    <NationFlag color={acc.preferredColor} emblem={acc.preferredEmblem} size={22} />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12 }}>{acc.username}</div>
                      <div style={{ fontSize: 10, color: '#9fb0c7' }}>
                        {acc.wins} Wins / {acc.gamesPlayed} Matches
                      </div>
                    </div>
                  </div>
                  <span className="font-mono-num dom-badge" style={{ color: '#38bdf8' }}>
                    {acc.elo} ELO
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
