import React, { useState } from 'react';
import { BookOpen, Search, X } from 'lucide-react';
import { BUILDINGS } from '../data/buildings';
import { BUILDING_BY_ID } from '../data/buildings';
import { ENCYCLOPEDIA_TOPICS } from '../data/encyclopedia';
import { ERAS } from '../data/eras';
import { GOVERNMENTS } from '../data/governments';
import { TECHNOLOGIES } from '../data/technologies';
import { TERRAINS } from '../data/terrains';
import { UNITS } from '../data/units';

interface Props {
  onClose: () => void;
}

type EncTab = 'guides' | 'eras' | 'buildings' | 'units' | 'terrains' | 'governments';

export const EncyclopediaModal: React.FC<Props> = ({ onClose }) => {
  const [tab, setTab] = useState<EncTab>('guides');
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <BookOpen size={20} color="#38bdf8" />
            <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
              Civilization Encyclopedia
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
              <Search size={13} color="#667892" style={{ position: 'absolute', left: 9 }} />
              <input
                className="dom-input"
                placeholder="Search codex..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                style={{ paddingLeft: 28, width: 200 }}
              />
            </div>
            <button className="dom-btn" onClick={onClose}>
              <X size={15} /> Close
            </button>
          </div>
        </div>

        <div className="dom-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {([
              ['guides', 'Strategic Guides'],
              ['eras', `Eras & Techs (${TECHNOLOGIES.length})`],
              ['buildings', `Buildings (${BUILDINGS.length})`],
              ['units', `Land & Naval Units (${UNITS.length})`],
              ['terrains', 'Terrains & Combat'],
              ['governments', 'Governments'],
            ] as Array<[EncTab, string]>).map(([id, label]) => (
              <button
                key={id}
                className={`dom-overlay-btn ${tab === id ? 'active' : ''}`}
                onClick={() => setTab(id)}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === 'guides' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {ENCYCLOPEDIA_TOPICS.filter(
                (t) => !q || t.title.toLowerCase().includes(q) || t.summary.toLowerCase().includes(q)
              ).map((t) => (
                <div key={t.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#f2cb77', marginBottom: 4 }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: '#38bdf8', marginBottom: 6 }}>{t.summary}</div>
                  <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: '#cbd5e1', lineHeight: 1.55 }}>
                    {t.details.map((d, idx) => (
                      <li key={idx}>{d}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {tab === 'eras' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {ERAS.map((era) => (
                <div key={era.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 13.5, color: era.badgeColor }}>{era.name} ({era.yearSpan})</div>
                  <p style={{ fontSize: 11.5, color: '#cbd5e1', margin: '4px 0 8px' }}>{era.description}</p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {TECHNOLOGIES.filter((t) => t.era === era.id && (!q || t.name.toLowerCase().includes(q))).map((t) => {
                      const resList = t.resourceCost
                        ? Object.entries(t.resourceCost)
                            .map(([k, v]) => `${v} ${k}`)
                            .join(', ')
                        : 'None';
                      const bName = t.requiredBuilding ? BUILDING_BY_ID[t.requiredBuilding]?.name ?? t.requiredBuilding : null;
                      return (
                        <span
                          key={t.id}
                          className="dom-badge"
                          title={`${t.description}\nResources: ${resList}${bName ? `\nRequires Building: ${bName}` : ''}`}
                        >
                          {t.name} ({t.cost} Sci{bName ? ` • ${bName}` : ''})
                        </span>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'buildings' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {BUILDINGS.filter((b) => !q || b.name.toLowerCase().includes(q) || b.category.includes(q)).map((b) => (
                <div key={b.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 12.5, color: '#f2cb77' }}>
                    {b.name}{' '}
                    <span className="dom-badge" style={{ textTransform: 'capitalize', fontSize: 10 }}>{b.category}</span>
                  </div>
                  <div style={{ fontSize: 11.5, color: '#cbd5e1', margin: '3px 0' }}>{b.description}</div>
                  <div style={{ fontSize: 10.5, color: '#9fb0c7' }}>
                    Era: {b.era} • Tech: {b.requiredTech ?? 'None'} • Upkeep: {b.upkeepGold}G
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'units' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {UNITS.filter((u) => !q || u.name.toLowerCase().includes(q) || u.domain.includes(q)).map((u) => (
                <div key={u.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 12.5, color: u.domain === 'naval' ? '#38bdf8' : '#f2cb77' }}>
                    {u.name} <span className="dom-badge">{u.domain.toUpperCase()}</span>
                  </div>
                  <div style={{ fontSize: 11.5, color: '#cbd5e1', margin: '3px 0' }}>{u.description}</div>
                  <div className="font-mono-num" style={{ fontSize: 10.5, color: '#34d399' }}>
                    Str {u.strength} • Def {u.defense} • Speed {u.speed} • Era: {u.era}
                    {u.transportCapacity ? ` • Transport Cap ${u.transportCapacity}` : ''}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'terrains' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {Object.values(TERRAINS).filter((t) => !q || t.name.toLowerCase().includes(q)).map((t) => (
                <div key={t.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#f2cb77' }}>{t.name}</div>
                  <div style={{ fontSize: 11.5, color: '#cbd5e1', margin: '4px 0' }}>{t.description}</div>
                  <div className="font-mono-num" style={{ fontSize: 11, color: '#38bdf8' }}>
                    Defense +{Math.round(t.defenseBonus * 100)}% • Move Cost {t.movementCost}x • Pop Cap {t.basePopulationCap.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'governments' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {Object.values(GOVERNMENTS).map((g) => (
                <div key={g.id} className="dom-card">
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#f2cb77' }}>{g.name}</div>
                  <div style={{ fontSize: 11.5, color: '#cbd5e1', margin: '3px 0 5px' }}>{g.description}</div>
                  <div style={{ fontSize: 11, color: '#34d399' }}>Pros: {g.advantages.join(', ')}</div>
                  <div style={{ fontSize: 11, color: '#f59e0b' }}>Cons: {g.disadvantages.join(', ')}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
