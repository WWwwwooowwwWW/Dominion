import React from 'react';
import {
  Anchor,
  Atom,
  BarChart3,
  BookOpen,
  Building2,
  Coins,
  FolderOpen,
  Handshake,
  HelpCircle,
  Landmark,
  Swords,
} from 'lucide-react';
import { TECHNOLOGIES } from '../data/technologies';
import { GameState, LeftNavTab } from '../types/game';

interface Props {
  state: GameState;
  activeTab: LeftNavTab | null;
  onSelectTab: (tab: LeftNavTab | null) => void;
  onOpenEncyclopedia: () => void;
  onOpenSaveLoad: () => void;
  onOpenTutorial: () => void;
}

export const LeftNavPanel: React.FC<Props> = ({
  state,
  activeTab,
  onSelectTab,
  onOpenEncyclopedia,
  onOpenSaveLoad,
  onOpenTutorial,
}) => {
  const player = state.nations[state.playerNationId];
  const cityCount = Object.values(state.cities).filter((c) => c.nationId === state.playerNationId).length;
  const armyCount = Object.values(state.armies).filter((a) => a.nationId === state.playerNationId).length;
  const fleetCount = Object.values(state.fleets).filter((f) => f.nationId === state.playerNationId).length;
  const atWarCount = player
    ? Object.values(player.relations).filter((r) => r.atWar && !state.nations[r.otherNationId]?.eliminated).length
    : 0;

  const navItems: Array<{ id: LeftNavTab; label: string; icon: React.ReactNode; badge?: string | number; badgeColor?: string }> = [
    { id: 'cities', label: 'Cities', icon: <Building2 size={16} />, badge: cityCount },
    { id: 'military', label: 'Military', icon: <Swords size={16} />, badge: armyCount, badgeColor: atWarCount > 0 ? '#ef4444' : undefined },
    { id: 'navy', label: 'Navy', icon: <Anchor size={16} />, badge: fleetCount, badgeColor: '#38bdf8' },
    { id: 'technology', label: 'Technology', icon: <Atom size={16} />, badge: `${player?.unlockedTechs.length ?? 0}/${TECHNOLOGIES.length}`, badgeColor: '#38bdf8' },
    { id: 'diplomacy', label: 'Diplomacy', icon: <Handshake size={16} />, badge: atWarCount > 0 ? `${atWarCount} War` : undefined, badgeColor: '#ef4444' },
    { id: 'economy', label: 'Economy', icon: <Coins size={16} /> },
    { id: 'government', label: 'Government', icon: <Landmark size={16} />, badge: `${Math.round(player?.resources.influence ?? 0)} Inf` },
    { id: 'statistics', label: 'Statistics', icon: <BarChart3 size={16} /> },
  ];

  return (
    <aside className="dom-left-nav">
      <div>
        <div
          className="font-display"
          style={{
            fontSize: 11,
            color: '#d4a84f',
            letterSpacing: '0.14em',
            padding: '2px 10px 8px',
            borderBottom: '1px solid #1d293b',
            marginBottom: 8,
            display: 'flex',
            justifyContent: 'space-between',
          }}
        >
          <span>STATE COMMAND</span>
          {activeTab && (
            <button
              onClick={() => onSelectTab(null)}
              style={{
                background: 'none',
                border: 'none',
                color: '#8a9bb3',
                cursor: 'pointer',
                fontSize: 10,
                padding: 0,
              }}
            >
              MAP
            </button>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {navItems.map((item) => (
            <button
              key={item.id}
              className={`dom-nav-item ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => onSelectTab(activeTab === item.id ? null : item.id)}
            >
              <span style={{ color: activeTab === item.id ? '#f2cb77' : '#8da0b8', display: 'flex' }}>
                {item.icon}
              </span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge !== undefined && (
                <span
                  className="font-mono-num"
                  style={{
                    fontSize: 10.5,
                    padding: '1px 6px',
                    borderRadius: 4,
                    background: 'rgba(255,255,255,0.06)',
                    color: item.badgeColor ?? '#9fb0c7',
                  }}
                >
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Administrative Strain & Happiness Summary */}
        {player && (
          <div className="dom-card" style={{ marginTop: 12, padding: 9 }}>
            <div style={{ fontSize: 10.5, color: '#9fb0c7', display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span>Approval</span>
              <span className="font-mono-num" style={{ color: player.overallHappiness >= 60 ? '#34d399' : '#f59e0b', fontWeight: 700 }}>
                {player.overallHappiness}%
              </span>
            </div>
            <div className="dom-progress" style={{ marginBottom: 8 }}>
              <div
                className="dom-progress-fill"
                style={{
                  width: `${player.overallHappiness}%`,
                  background: player.overallHappiness >= 60 ? '#34d399' : '#f59e0b',
                }}
              />
            </div>
            <div style={{ fontSize: 10.5, color: '#9fb0c7', display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span>Admin Strain</span>
              <span className="font-mono-num" style={{ color: player.adminStrain > 35 ? '#ef4444' : '#38bdf8', fontWeight: 700 }}>
                {Math.round(player.adminStrain)}%
              </span>
            </div>
            <div className="dom-progress">
              <div
                className="dom-progress-fill"
                style={{
                  width: `${player.adminStrain}%`,
                  background: player.adminStrain > 35 ? '#ef4444' : '#38bdf8',
                }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Utility Footer */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, paddingTop: 10, borderTop: '1px solid #1c283b' }}>
        {state.config.mode !== 'multiplayer' && (
          <button className="dom-btn" style={{ justifyContent: 'flex-start' }} onClick={onOpenSaveLoad}>
            <FolderOpen size={14} color="#d4a84f" /> Save / Load Game
          </button>
        )}
        <button className="dom-btn" style={{ justifyContent: 'flex-start' }} onClick={onOpenEncyclopedia}>
          <BookOpen size={14} color="#38bdf8" /> Encyclopedia
        </button>
        <button className="dom-btn" style={{ justifyContent: 'flex-start' }} onClick={onOpenTutorial}>
          <HelpCircle size={14} color="#34d399" /> Tactical Guide
        </button>
      </div>
    </aside>
  );
};
