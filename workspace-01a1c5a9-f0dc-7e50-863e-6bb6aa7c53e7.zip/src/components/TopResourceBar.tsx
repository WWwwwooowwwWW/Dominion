import React from 'react';
import {
  Atom,
  BookOpen,
  Coins,
  Droplets,
  FastForward,
  Flame,
  Hammer,
  Menu,
  Pause,
  Play,
  Save,
  Shield,
  Sparkles,
  Trees,
  Users,
  Wheat,
  Zap,
  Flag,
} from 'lucide-react';
import { ERA_BY_ID, formatYear } from '../data/eras';
import { GameSpeed, GameState, ResourceKey } from '../types/game';
import { NationFlag } from './NationFlag';

interface Props {
  state: GameState;
  onSetSpeed: (speed: GameSpeed) => void;
  onQuickSave: () => void;
  onOpenMenu: () => void;
  onOpenTechTree: () => void;
}

export const TopResourceBar: React.FC<Props> = ({
  state,
  onSetSpeed,
  onQuickSave,
  onOpenMenu,
  onOpenTechTree,
}) => {
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const landTerritories = state.territoryIds.filter((id) => !state.territories[id].isWater);
  const ownedCount = landTerritories.filter((id) => state.territories[id].ownerId === player.id).length;
  const totalPop = Object.values(state.cities)
    .filter((c) => c.nationId === player.id)
    .reduce((s, c) => s + c.population, 0);

  const eraDef = ERA_BY_ID[player.era];

  const primaryRes: Array<{ key: ResourceKey; label: string; icon: React.ReactNode; color: string }> = [
    { key: 'gold', label: 'Gold', icon: <Coins size={13} color="#f2cb77" />, color: '#f2cb77' },
    { key: 'food', label: 'Food', icon: <Wheat size={13} color="#84cc16" />, color: '#84cc16' },
    { key: 'wood', label: 'Wood', icon: <Trees size={13} color="#22c55e" />, color: '#22c55e' },
    { key: 'stone', label: 'Stone', icon: <Hammer size={13} color="#cbd5e1" />, color: '#cbd5e1' },
    { key: 'iron', label: 'Iron', icon: <Shield size={13} color="#94a3b8" />, color: '#94a3b8' },
    { key: 'coal', label: 'Coal', icon: <Flame size={13} color="#fb923c" />, color: '#fb923c' },
    { key: 'oil', label: 'Oil', icon: <Droplets size={13} color="#c084fc" />, color: '#c084fc' },
    { key: 'science', label: 'Sci', icon: <Atom size={13} color="#38bdf8" />, color: '#38bdf8' },
    { key: 'culture', label: 'Cult', icon: <Sparkles size={13} color="#e879f9" />, color: '#e879f9' },
    { key: 'energy', label: 'Pwr', icon: <Zap size={13} color="#facc15" />, color: '#facc15' },
  ];

  const fmtVal = (v: number) => (v >= 10000 ? `${(v / 1000).toFixed(1)}k` : Math.floor(v).toString());
  const fmtRate = (r: number) => `${r >= 0 ? '+' : ''}${Math.round(r)}`;

  return (
    <header className="dom-top-bar">
      {/* Nation Crest + Era + Year */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, flexShrink: 0 }}>
        <NationFlag color={player.color} secondaryColor={player.secondaryColor} emblem={player.emblem} size={30} />
        <div style={{ lineHeight: 1.15 }}>
          <div style={{ fontWeight: 700, fontSize: 12.5, color: '#f8fafc', maxWidth: 145, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {player.name}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5 }}>
            <span style={{ color: eraDef.badgeColor, fontWeight: 700 }}>{eraDef.shortName}</span>
            <span style={{ color: '#667892' }}>•</span>
            <span className="font-mono-num" style={{ color: '#cbd5e1' }}>{formatYear(state.year)}</span>
          </div>
        </div>
      </div>

      {/* Resource Dashboard */}
      <div className="dom-res-strip">
        {primaryRes.map((r) => {
          const amt = player.resources[r.key];
          const rate = player.ratesPerMin[r.key];
          const cap = player.storageCaps[r.key];
          const prod =
            player.territoryProductionBreakdown[r.key] +
            player.naturalDepositBreakdown[r.key] +
            player.buildingProductionBreakdown[r.key];
          const cons = player.consumptionPerMin[r.key];
          const title = `${r.label}: ${Math.floor(amt)}${cap < 900000 ? ` / ${Math.floor(cap)}` : ''}\nProduction: +${prod.toFixed(1)}/min | Consumption: -${cons.toFixed(1)}/min\nTerritory: +${player.territoryProductionBreakdown[r.key].toFixed(1)} | Deposits: +${player.naturalDepositBreakdown[r.key].toFixed(1)} | Buildings: +${player.buildingProductionBreakdown[r.key].toFixed(1)}`;
          return (
            <div
              key={r.key}
              className="dom-res-pill"
              title={title}
              onClick={r.key === 'science' ? onOpenTechTree : undefined}
              style={{ cursor: r.key === 'science' ? 'pointer' : 'default' }}
            >
              {r.icon}
              <span className="font-mono-num" style={{ fontWeight: 700, color: '#f1f5f9' }}>
                {r.key === 'science' && player.currentTechId
                  ? `${Math.floor(player.techProgress)}`
                  : fmtVal(amt)}
              </span>
              <span
                className="font-mono-num"
                style={{
                  fontSize: 10,
                  color: rate > 0.4 ? '#34d399' : rate < -0.4 ? '#ef4444' : '#9fb0c7',
                }}
              >
                {fmtRate(rate)}
              </span>
            </div>
          );
        })}

        <div className="dom-res-pill" title="Total Citizen Population">
          <Users size={13} color="#38bdf8" />
          <span className="font-mono-num" style={{ fontWeight: 700 }}>
            {totalPop >= 1000 ? `${(totalPop / 1000).toFixed(1)}k` : totalPop}
          </span>
        </div>

        <div className="dom-res-pill" title={`Territories Controlled: ${ownedCount} of ${landTerritories.length} habitable regions`}>
          <Flag size={13} color="#d4a84f" />
          <span className="font-mono-num" style={{ fontWeight: 700, color: '#f2cb77' }}>
            {ownedCount}/{landTerritories.length}
          </span>
        </div>
      </div>

      {/* Simulation Speed Controls + Save + Menu */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0 }}>
        <div style={{ display: 'flex', background: '#090d14', border: '1px solid #243247', borderRadius: 5, padding: 2, gap: 2 }}>
          <button
            className={`dom-overlay-btn ${state.speed === 0 ? 'active' : ''}`}
            onClick={() => onSetSpeed(0)}
            title="Pause Simulation"
            style={{ padding: '3px 7px' }}
          >
            <Pause size={12} />
          </button>
          <button
            className={`dom-overlay-btn ${state.speed === 1 ? 'active' : ''}`}
            onClick={() => onSetSpeed(1)}
            title="Normal Speed (1x)"
            style={{ padding: '3px 7px' }}
          >
            <Play size={12} /> 1x
          </button>
          <button
            className={`dom-overlay-btn ${state.speed === 2 ? 'active' : ''}`}
            onClick={() => onSetSpeed(2)}
            title="2x Speed"
            style={{ padding: '3px 7px' }}
          >
            <FastForward size={12} /> 2x
          </button>
          <button
            className={`dom-overlay-btn ${state.speed === 4 ? 'active' : ''}`}
            onClick={() => onSetSpeed(4)}
            title="4x Speed"
            style={{ padding: '3px 7px' }}
          >
            4x
          </button>
        </div>

        {state.config.mode !== 'multiplayer' && (
          <button className="dom-btn" onClick={onQuickSave} title="Quick Save Campaign" style={{ padding: '5px 8px' }}>
            <Save size={13} color="#d4a84f" />
          </button>
        )}
        <button className="dom-btn" onClick={onOpenMenu} title="Main Menu & Options" style={{ padding: '5px 8px' }}>
          <Menu size={13} />
        </button>
      </div>
    </header>
  );
};
