import React from 'react';
import { AlertTriangle, Sparkles } from 'lucide-react';
import { PendingEvent } from '../../types/game';

interface Props {
  event: PendingEvent;
  onChoose: (choiceId: string) => void;
}

export const EventModal: React.FC<Props> = ({ event, onChoose }) => {
  const isPositive = event.kind === 'discovery' || event.kind === 'breakthrough' || event.kind === 'boom';

  return (
    <div className="dom-modal-backdrop">
      <div className="dom-modal" style={{ width: 'min(540px, 92vw)' }}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            {isPositive ? <Sparkles size={20} color="#34d399" /> : <AlertTriangle size={20} color="#f59e0b" />}
            <div className="font-display" style={{ fontSize: 15.5, fontWeight: 700, color: '#f2cb77' }}>
              {event.title}
            </div>
          </div>
          <span className="dom-badge" style={{ textTransform: 'uppercase', color: isPositive ? '#34d399' : '#f59e0b' }}>
            World Event
          </span>
        </div>

        <div className="dom-modal-body">
          <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.55, marginTop: 0 }}>{event.description}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginTop: 14 }}>
            {event.choices.map((c) => (
              <button
                key={c.id}
                className="dom-card"
                style={{
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 3,
                  border: '1px solid rgba(212, 168, 79, 0.45)',
                }}
                onClick={() => onChoose(c.id)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: 13, color: '#f2cb77' }}>
                  <span>{c.label}</span>
                  {c.costGold && <span className="font-mono-num" style={{ color: '#f59e0b' }}>-{c.costGold} Gold</span>}
                </div>
                <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>{c.description}</div>
                <div style={{ fontSize: 11, color: '#34d399', fontWeight: 600 }}>{c.effectSummary}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
