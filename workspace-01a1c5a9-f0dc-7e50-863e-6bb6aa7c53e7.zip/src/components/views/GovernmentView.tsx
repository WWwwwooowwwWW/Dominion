import React from 'react';
import { Check, Landmark, Sliders, X } from 'lucide-react';
import { GOVERNMENTS, POLICIES } from '../../data/governments';
import { BudgetSettings, GameState, GovernmentType } from '../../types/game';

interface Props {
  state: GameState;
  onChangeGovernment: (govId: GovernmentType) => void;
  onTogglePolicy: (policyId: string) => void;
  onUpdateBudget: (patch: Partial<BudgetSettings>) => void;
  onClose: () => void;
}

export const GovernmentView: React.FC<Props> = ({
  state,
  onChangeGovernment,
  onTogglePolicy,
  onUpdateBudget,
  onClose,
}) => {
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const sliders: Array<{ key: keyof BudgetSettings; label: string; min: number; max: number; suffix: string; hint: string }> = [
    { key: 'taxRate', label: 'National Tax Rate', min: 0, max: 45, suffix: '%', hint: 'Higher taxes boost gold, reduce citizen happiness' },
    { key: 'militarySpending', label: 'Military Spending', min: 10, max: 100, suffix: '%', hint: 'Boosts army power & city security' },
    { key: 'educationFunding', label: 'Education Funding', min: 10, max: 100, suffix: '%', hint: 'Accelerates national Science output' },
    { key: 'healthcareFunding', label: 'Healthcare Funding', min: 10, max: 100, suffix: '%', hint: 'Improves Health & reduces Disease Outbreaks' },
    { key: 'infrastructureSpending', label: 'Infrastructure Spending', min: 10, max: 100, suffix: '%', hint: 'Improves city roads & logistics' },
    { key: 'tradeTariff', label: 'Trade Regulations / Tariffs', min: 0, max: 40, suffix: '%', hint: 'Increases trade route treasury yield' },
  ];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Landmark size={20} color="#d4a84f" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                State Governance, Policies &amp; National Budget
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Current System: <b style={{ color: '#f2cb77' }}>{GOVERNMENTS[player.government].name}</b> • Influence:{' '}
                <b className="font-mono-num" style={{ color: '#a78bfa' }}>{Math.floor(player.resources.influence)}</b>
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: 16 }}>
          {/* Government Types + Budget Sliders */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="dom-card">
              <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', marginBottom: 8 }}>
                Forms of Government (Reform Cost: 40 Influence)
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
                {(Object.values(GOVERNMENTS)).map((gov) => {
                  const active = player.government === gov.id;
                  const unlocked = !gov.requiredTech || player.unlockedTechs.includes(gov.requiredTech);
                  return (
                    <div
                      key={gov.id}
                      className={active ? 'dom-card-gold' : 'dom-panel'}
                      style={{ padding: 9, opacity: unlocked ? 1 : 0.55 }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                        <span style={{ fontWeight: 700, fontSize: 12, color: active ? '#f2cb77' : '#f1f5f9' }}>
                          {gov.name}
                        </span>
                        {active && <Check size={14} color="#34d399" />}
                      </div>
                      <div style={{ fontSize: 10.5, color: '#9fb0c7', marginBottom: 4 }}>{gov.description}</div>
                      <div style={{ fontSize: 10, color: '#34d399' }}>{gov.advantages.join(' • ')}</div>
                      <div style={{ fontSize: 10, color: '#f59e0b', marginBottom: 6 }}>{gov.disadvantages.join(' • ')}</div>
                      {!active && (
                        <button
                          className="dom-btn dom-btn-gold"
                          style={{ width: '100%', padding: '4px 8px', fontSize: 10.5 }}
                          disabled={!unlocked || player.resources.influence < 40}
                          onClick={() => onChangeGovernment(gov.id)}
                        >
                          {unlocked ? 'Adopt (40 Inf)' : `Needs: ${gov.requiredTech}`}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="dom-card">
              <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Sliders size={14} /> National Budget &amp; Tax Controls
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {sliders.map((s) => (
                  <div key={s.key} className="dom-panel" style={{ padding: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, marginBottom: 3 }}>
                      <span style={{ fontWeight: 600 }}>{s.label}</span>
                      <span className="font-mono-num" style={{ color: '#f2cb77', fontWeight: 700 }}>
                        {player.budget[s.key]}{s.suffix}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={s.min}
                      max={s.max}
                      value={player.budget[s.key]}
                      onChange={(e) => onUpdateBudget({ [s.key]: Number(e.target.value) })}
                      style={{ width: '100%', accentColor: '#d4a84f' }}
                    />
                    <div style={{ fontSize: 9.5, color: '#667892' }}>{s.hint}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* National Policies */}
          <div className="dom-card">
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', marginBottom: 8 }}>
              National Policies &amp; Reforms
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {POLICIES.map((pol) => {
                const active = player.activePolicies.includes(pol.id);
                return (
                  <div
                    key={pol.id}
                    className={active ? 'dom-card-gold' : 'dom-panel'}
                    style={{ padding: 9, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}
                  >
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12 }}>
                        {pol.name}{' '}
                        <span className="dom-badge" style={{ textTransform: 'uppercase', fontSize: 9.5, marginLeft: 4 }}>
                          {pol.category}
                        </span>
                      </div>
                      <div style={{ fontSize: 10.5, color: '#9fb0c7', marginTop: 2 }}>{pol.description}</div>
                    </div>
                    <button
                      className={active ? 'dom-btn dom-btn-danger' : 'dom-btn dom-btn-emerald'}
                      style={{ padding: '5px 9px', fontSize: 11 }}
                      disabled={!active && player.resources.influence < pol.costInfluence}
                      onClick={() => onTogglePolicy(pol.id)}
                    >
                      {active ? 'Repeal' : `Enact (${pol.costInfluence} Inf)`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
