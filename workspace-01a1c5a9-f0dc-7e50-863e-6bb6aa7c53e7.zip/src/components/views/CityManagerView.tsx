import React, { useState } from 'react';
import { Building2, Hammer, Heart, Home, Shield, Smile, Users, X } from 'lucide-react';
import { BUILDING_BY_ID, BUILDINGS } from '../../data/buildings';
import { canAfford } from '../../engine/economy';
import { BuildingCategory, GameState, OccupationKey } from '../../types/game';

interface Props {
  state: GameState;
  initialCityId?: string | null;
  onBuildStructure: (cityId: string, buildingId: string) => void;
  onAdjustOccupation: (cityId: string, key: OccupationKey, delta: number) => void;
  onFocusTerritory: (tid: string) => void;
  onClose: () => void;
}

const OCCUPATIONS: Array<{ key: OccupationKey; label: string; bonus: string }> = [
  { key: 'farmers', label: 'Farmers', bonus: '+Food output' },
  { key: 'miners', label: 'Miners', bonus: '+Stone, Iron, Coal, Oil' },
  { key: 'builders', label: 'Builders', bonus: '+Build speed & Wood' },
  { key: 'researchers', label: 'Researchers', bonus: '+Science output' },
  { key: 'merchants', label: 'Merchants', bonus: '+Gold & Trade' },
  { key: 'factory_workers', label: 'Factory Workers', bonus: '+Industrial output' },
  { key: 'government_workers', label: 'Gov. Workers', bonus: '+Influence & Culture' },
  { key: 'soldiers', label: 'Soldiers', bonus: '+Garrison readiness' },
];

export const CityManagerView: React.FC<Props> = ({
  state,
  initialCityId,
  onBuildStructure,
  onAdjustOccupation,
  onFocusTerritory,
  onClose,
}) => {
  const player = state.nations[state.playerNationId];
  const cities = Object.values(state.cities).filter((c) => c.nationId === state.playerNationId);
  const [selectedCityId, setSelectedCityId] = useState<string>(initialCityId || cities[0]?.id || '');
  const [category, setCategory] = useState<BuildingCategory>('economic');

  const city = cities.find((c) => c.id === selectedCityId) ?? cities[0];
  if (!player || !city) return null;
  const territory = state.territories[city.territoryId];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Building2 size={20} color="#d4a84f" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Imperial Cities &amp; Infrastructure
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Managing {cities.length} {cities.length === 1 ? 'City' : 'Cities'} • Workforce, Housing &amp; Construction
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '230px 1fr', gap: 14 }}>
          {/* Left City Selector List */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {cities.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCityId(c.id)}
                className={c.id === city.id ? 'dom-card-gold' : 'dom-card'}
                style={{ cursor: 'pointer', padding: '9px 10px' }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: 12.5 }}>
                  <span style={{ color: c.id === city.id ? '#f2cb77' : '#f1f5f9' }}>
                    {c.isCapital ? '★ ' : ''}
                    {c.name}
                  </span>
                  <span className="font-mono-num" style={{ fontSize: 11, color: '#38bdf8' }}>
                    T{c.tier}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: '#9fb0c7', marginTop: 3 }}>
                  Pop {c.population.toLocaleString()} • Happy {c.happiness}%
                </div>
              </div>
            ))}
          </div>

          {/* Right Selected City Detail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Top City Metrics */}
            <div className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
              <div>
                <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                  {city.name} {city.isCapital && '(National Capital)'}
                </div>
                <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                  Province: {territory?.name} {territory?.isCoastal ? '• Coastal Harbor' : ''}
                  {city.diseaseOutbreak && (
                    <span style={{ color: '#ef4444', fontWeight: 700, marginLeft: 8 }}>• DISEASE OUTBREAK</span>
                  )}
                </div>
              </div>
              <button
                className="dom-btn"
                onClick={() => {
                  onFocusTerritory(city.territoryId);
                  onClose();
                }}
              >
                Locate on Map
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892', display: 'flex', gap: 4 }}><Users size={11} /> Population</div>
                <div className="font-mono-num" style={{ fontSize: 13.5, fontWeight: 700 }}>{city.population.toLocaleString()}</div>
                <div style={{ fontSize: 10, color: '#34d399' }}>+{city.birthRate}/-{city.deathRate} ‰</div>
              </div>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892', display: 'flex', gap: 4 }}><Home size={11} /> Housing</div>
                <div className="font-mono-num" style={{ fontSize: 13.5, fontWeight: 700, color: city.population > city.housing ? '#ef4444' : '#38bdf8' }}>
                  {city.housing.toLocaleString()}
                </div>
                <div style={{ fontSize: 10, color: '#9fb0c7' }}>Unemp {city.unemploymentRate}%</div>
              </div>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892', display: 'flex', gap: 4 }}><Smile size={11} /> Happiness</div>
                <div className="font-mono-num" style={{ fontSize: 13.5, fontWeight: 700, color: '#34d399' }}>{city.happiness}%</div>
                <div style={{ fontSize: 10, color: '#9fb0c7' }}>Edu {city.education}%</div>
              </div>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892', display: 'flex', gap: 4 }}><Heart size={11} /> Health</div>
                <div className="font-mono-num" style={{ fontSize: 13.5, fontWeight: 700, color: '#38bdf8' }}>{city.health}%</div>
                <div style={{ fontSize: 10, color: '#9fb0c7' }}>Infra {city.infrastructure}%</div>
              </div>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892', display: 'flex', gap: 4 }}><Shield size={11} /> Security</div>
                <div className="font-mono-num" style={{ fontSize: 13.5, fontWeight: 700, color: '#f2cb77' }}>{city.security}%</div>
                <div style={{ fontSize: 10, color: '#9fb0c7' }}>Fort Lv.{territory?.fortLevel ?? 0}</div>
              </div>
              <div className="dom-card" style={{ padding: 8 }}>
                <div style={{ fontSize: 10, color: '#667892' }}>Output</div>
                <div className="font-mono-num" style={{ fontSize: 12, fontWeight: 700, color: '#f2cb77' }}>
                  {city.economicOutput}G / {city.industrialOutput}I
                </div>
                <div style={{ fontSize: 10, color: '#84cc16' }}>Food {city.foodProduction}</div>
              </div>
            </div>

            {/* Citizen Occupation Allocation */}
            <div className="dom-card">
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#f2cb77', marginBottom: 8 }}>
                Citizen Occupation Assignments (Workforce: {Math.round(city.population * 0.92).toLocaleString()})
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                {OCCUPATIONS.map((occ) => (
                  <div key={occ.key} className="dom-panel" style={{ padding: 7 }}>
                    <div style={{ fontSize: 11.5, fontWeight: 700 }}>{occ.label}</div>
                    <div style={{ fontSize: 10, color: '#667892', marginBottom: 4 }}>{occ.bonus}</div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <button
                        className="dom-btn"
                        style={{ padding: '2px 7px', fontSize: 11 }}
                        onClick={() => onAdjustOccupation(city.id, occ.key, -150)}
                      >
                        -150
                      </button>
                      <span className="font-mono-num" style={{ fontWeight: 700, color: '#38bdf8' }}>
                        {city.occupations[occ.key]}
                      </span>
                      <button
                        className="dom-btn"
                        style={{ padding: '2px 7px', fontSize: 11 }}
                        onClick={() => onAdjustOccupation(city.id, occ.key, 150)}
                      >
                        +150
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Full 8-Category Construction & Upgrades */}
            <div className="dom-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', gap: 6 }}>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Hammer size={14} /> Urban Construction &amp; Upgrades
                </span>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                  {(['residential', 'economic', 'industrial', 'agricultural', 'scientific', 'infrastructure', 'government', 'military'] as BuildingCategory[]).map(
                    (cat) => (
                      <button
                        key={cat}
                        className={`dom-overlay-btn ${category === cat ? 'active' : ''}`}
                        style={{ textTransform: 'capitalize' }}
                        onClick={() => setCategory(cat)}
                      >
                        {cat}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
                {BUILDINGS.filter((b) => b.category === category).map((b) => {
                  const inst = city.buildings.find((x) => x.buildingId === b.id);
                  const lvl = inst?.level ?? 0;
                  const queued = city.queue.filter((q) => q.buildingId === b.id).length;
                  const lockedTech = b.requiredTech && !player.unlockedTechs.includes(b.requiredTech);
                  const lockedCoast = b.coastalOnly && !territory?.isCoastal;
                  const maxed = lvl + queued >= b.maxLevel;
                  const affordable = canAfford(player, b.cost);

                  return (
                    <div key={b.id} className="dom-panel" style={{ padding: 9, display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 12, color: '#f1f5f9' }}>
                          {b.name} {lvl > 0 && <span style={{ color: '#34d399' }}>Lv.{lvl}/{b.maxLevel}</span>}
                          {queued > 0 && <span style={{ color: '#f59e0b', marginLeft: 5 }}>(Queued)</span>}
                        </div>
                        <div style={{ fontSize: 10.5, color: '#9fb0c7', margin: '2px 0 4px' }}>{b.description}</div>
                        <div style={{ fontSize: 10, color: '#d4a84f' }}>
                          Cost: {Object.entries(b.cost).map(([k, v]) => `${v} ${k}`).join(', ')} • Upkeep {b.upkeepGold}G
                        </div>
                        {lockedTech && <div style={{ fontSize: 10, color: '#ef4444' }}>Requires Tech: {b.requiredTech}</div>}
                        {lockedCoast && <div style={{ fontSize: 10, color: '#38bdf8' }}>Coastal province required</div>}
                      </div>
                      <button
                        className="dom-btn dom-btn-gold"
                        style={{ alignSelf: 'center' }}
                        disabled={Boolean(lockedTech || lockedCoast || maxed || !affordable)}
                        onClick={() => onBuildStructure(city.id, b.id)}
                      >
                        {maxed ? 'Maxed' : lvl > 0 ? 'Upgrade' : 'Construct'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
