import React, { useMemo, useState } from 'react';
import { AlertTriangle, Atom, Building2, Check, Coins, Lock, Sparkles, X } from 'lucide-react';
import { BUILDING_BY_ID } from '../../data/buildings';
import { ERA_BY_ID, ERAS } from '../../data/eras';
import { TECH_BY_ID, TECHNOLOGIES } from '../../data/technologies';
import { ALL_RESOURCE_KEYS } from '../../engine/economy';
import {
  formatTechBlockReason,
  getEffectiveTechCost,
  getTechComplexityMultiplier,
  getTechRequirementsStatus,
} from '../../engine/tech';
import { GameState, ResourceKey } from '../../types/game';

interface Props {
  state: GameState;
  onSelectTech: (techId: string) => void;
  onClose: () => void;
}

const NODE_W = 198;
const NODE_H = 98;
const COL_GAP = 236;
const ROW_GAP = 116;
const PAD_X = 28;
const PAD_Y = 56;

const RES_SHORT: Record<ResourceKey, string> = {
  gold: 'Gold',
  food: 'Food',
  wood: 'Wood',
  stone: 'Stone',
  iron: 'Iron',
  coal: 'Coal',
  oil: 'Oil',
  science: 'Sci',
  culture: 'Cult',
  influence: 'Inf',
  energy: 'Pwr',
};

const RES_ABBR: Record<ResourceKey, string> = {
  gold: 'G',
  food: 'F',
  wood: 'W',
  stone: 'S',
  iron: 'Fe',
  coal: 'C',
  oil: 'Oil',
  science: 'Sci',
  culture: 'Cul',
  influence: 'Inf',
  energy: 'Pwr',
};

const fmtCompact = (v: number): string => (v >= 1000 ? `${(v / 1000).toFixed(v % 1000 === 0 ? 0 : 1)}k` : String(v));

export const TechTreeModal: React.FC<Props> = ({ state, onSelectTech, onClose }) => {
  const player = state.nations[state.playerNationId];

  const defaultInspectedId = useMemo(() => {
    if (!player) return TECHNOLOGIES[0].id;
    if (player.currentTechId && TECH_BY_ID[player.currentTechId]) return player.currentTechId;
    const ready = TECHNOLOGIES.find((t) => getTechRequirementsStatus(state, player, t).canStart);
    if (ready) return ready.id;
    const prereqReady = TECHNOLOGIES.find(
      (t) =>
        !player.unlockedTechs.includes(t.id) &&
        t.prerequisites.every((p) => player.unlockedTechs.includes(p))
    );
    return prereqReady?.id ?? TECHNOLOGIES[0].id;
  }, [player?.id]);

  const [inspectedId, setInspectedId] = useState<string>(defaultInspectedId);

  if (!player) return null;

  const totalW = PAD_X * 2 + 14 * COL_GAP;
  const totalH = PAD_Y + 6 * ROW_GAP + 30;
  const complexityMult = getTechComplexityMultiplier(player);
  const effectiveSciRatePerMin = Math.max(4, player.ratesPerMin.science) * 1.9;

  const nodePos = (x: number, y: number) => ({
    left: PAD_X + x * COL_GAP,
    top: PAD_Y + y * ROW_GAP,
  });

  const inspectedTech = TECH_BY_ID[inspectedId] ?? TECHNOLOGIES[0];
  const inspectedStatus = getTechRequirementsStatus(state, player, inspectedTech);
  const inspectedEra = ERA_BY_ID[inspectedTech.era];
  const isInspectedActive = player.currentTechId === inspectedTech.id;
  const inspectedSavedProgress = isInspectedActive
    ? player.techProgress
    : (player.techProgressById?.[inspectedTech.id] ?? 0);
  const remainingSci = Math.max(0, inspectedStatus.effectiveSciCost - inspectedSavedProgress);
  const etaMinutes = remainingSci / effectiveSciRatePerMin;

  const resEntries = ALL_RESOURCE_KEYS.filter(
    (k) => (inspectedTech.resourceCost?.[k] ?? 0) > 0
  ).map((k) => ({
    key: k,
    need: inspectedTech.resourceCost?.[k] ?? 0,
    have: Math.floor(player.resources[k]),
  }));

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div
        className="dom-modal"
        style={{ width: 'min(1360px, 97vw)', height: 'min(860px, 92vh)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Atom size={20} color="#38bdf8" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Civilization Technology Tree
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7', display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                <span>
                  Unlocked <b style={{ color: '#e6ecf5' }}>{player.unlockedTechs.length} / {TECHNOLOGIES.length}</b> Technologies
                </span>
                <span>•</span>
                <span>
                  Science Rate:{' '}
                  <b className="font-mono-num" style={{ color: '#38bdf8' }}>
                    +{Math.round(player.ratesPerMin.science)}/min
                  </b>
                </span>
                <span>•</span>
                <span title="Each unlocked technology increases future Science requirements by +2.8%.">
                  Knowledge Complexity:{' '}
                  <b className="font-mono-num" style={{ color: '#f59e0b' }}>
                    {complexityMult.toFixed(2)}x
                  </b>
                </span>
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ padding: 0, display: 'flex', overflow: 'hidden', flex: 1 }}>
          {/* Left Scrollable Tech Graph */}
          <div style={{ flex: 1, overflow: 'auto', background: '#090e17', position: 'relative' }}>
            <div style={{ position: 'relative', width: totalW, height: totalH }}>
              {/* Era Column Banners */}
              {ERAS.map((era, idx) => (
                <div
                  key={era.id}
                  style={{
                    position: 'absolute',
                    left: PAD_X + idx * 2 * COL_GAP,
                    top: 10,
                    width: COL_GAP * 2 - 26,
                    padding: '5px 10px',
                    borderRadius: 5,
                    background: 'rgba(18, 28, 44, 0.92)',
                    border: `1px solid ${era.badgeColor}66`,
                    color: era.badgeColor,
                    fontWeight: 700,
                    fontSize: 11.5,
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                >
                  <span className="font-display">{era.name}</span>
                  <span style={{ fontSize: 10, opacity: 0.85 }}>{era.yearSpan}</span>
                </div>
              ))}

              {/* SVG Prerequisite Connection Curves */}
              <svg
                width={totalW}
                height={totalH}
                style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}
              >
                {TECHNOLOGIES.map((tech) => {
                  const to = nodePos(tech.x, tech.y);
                  const x2 = to.left;
                  const y2 = to.top + NODE_H / 2;
                  const isUnlocked = player.unlockedTechs.includes(tech.id);
                  const isResearching = player.currentTechId === tech.id;

                  return tech.prerequisites.map((pid) => {
                    const p = TECH_BY_ID[pid];
                    if (!p) return null;
                    const from = nodePos(p.x, p.y);
                    const x1 = from.left + NODE_W;
                    const y1 = from.top + NODE_H / 2;
                    const midX = (x1 + x2) * 0.5;
                    const pUnlocked = player.unlockedTechs.includes(pid);

                    const stroke = isUnlocked
                      ? '#34d399'
                      : isResearching
                        ? '#38bdf8'
                        : pUnlocked
                          ? '#d4a84f'
                          : '#26354d';

                    return (
                      <path
                        key={`${pid}_${tech.id}`}
                        d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                        fill="none"
                        stroke={stroke}
                        strokeWidth={isUnlocked || isResearching ? 2.4 : 1.5}
                        strokeDasharray={!pUnlocked ? '5 4' : undefined}
                      />
                    );
                  });
                })}
              </svg>

              {/* Technology Cards */}
              {TECHNOLOGIES.map((tech) => {
                const pos = nodePos(tech.x, tech.y);
                const status = getTechRequirementsStatus(state, player, tech);
                const unlocked = status.alreadyUnlocked;
                const active = player.currentTechId === tech.id;
                const prereqsMet = status.missingPrereqs.length === 0;
                const readyToStart = status.canStart;
                const selected = inspectedId === tech.id;
                const effectiveCost = getEffectiveTechCost(tech, player);
                const savedProg = active ? player.techProgress : (player.techProgressById?.[tech.id] ?? 0);

                const resList = tech.resourceCost
                  ? ALL_RESOURCE_KEYS.filter((k) => (tech.resourceCost?.[k] ?? 0) > 0)
                  : [];

                return (
                  <div
                    key={tech.id}
                    onClick={() => setInspectedId(tech.id)}
                    onDoubleClick={() => {
                      if (readyToStart && !active) onSelectTech(tech.id);
                    }}
                    title={`${tech.description}\nDouble-click to start if requirements are met.`}
                    style={{
                      position: 'absolute',
                      left: pos.left,
                      top: pos.top,
                      width: NODE_W,
                      height: NODE_H,
                      padding: '7px 9px',
                      borderRadius: 6,
                      cursor: 'pointer',
                      background: unlocked
                        ? 'linear-gradient(180deg, rgba(16, 185, 129, 0.2) 0%, rgba(15, 25, 38, 0.95) 100%)'
                        : active
                          ? 'linear-gradient(180deg, rgba(56, 189, 248, 0.25) 0%, rgba(15, 25, 38, 0.96) 100%)'
                          : readyToStart
                            ? 'linear-gradient(180deg, rgba(212, 168, 79, 0.18) 0%, #131c2b 100%)'
                            : prereqsMet
                              ? 'linear-gradient(180deg, rgba(245, 158, 11, 0.1) 0%, #111927 100%)'
                              : '#0e1521',
                      border: `1.5px solid ${
                        selected
                          ? '#f8fafc'
                          : unlocked
                            ? '#34d399'
                            : active
                              ? '#38bdf8'
                              : readyToStart
                                ? '#d4a84f'
                                : prereqsMet
                                  ? '#92601d'
                                  : '#233146'
                      }`,
                      boxShadow: selected
                        ? '0 0 0 2px rgba(242, 203, 119, 0.45), 0 4px 16px rgba(0, 0, 0, 0.45)'
                        : active
                          ? '0 0 18px rgba(56, 189, 248, 0.35)'
                          : undefined,
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      opacity: !unlocked && !prereqsMet ? 0.6 : 1,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 4 }}>
                      <span
                        style={{
                          fontWeight: 700,
                          fontSize: 11.5,
                          color: unlocked ? '#6ee7b7' : active ? '#7dd3fc' : '#f1f5f9',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {tech.name}
                      </span>
                      {unlocked ? (
                        <Check size={13} color="#34d399" />
                      ) : active ? (
                        <Sparkles size={13} color="#38bdf8" />
                      ) : !prereqsMet ? (
                        <Lock size={12} color="#667892" />
                      ) : !readyToStart ? (
                        <AlertTriangle size={12} color="#f59e0b" />
                      ) : null}
                    </div>

                    <div
                      style={{
                        fontSize: 9.5,
                        color: '#9fb0c7',
                        lineHeight: 1.25,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {tech.unlocksText[0]}
                    </div>

                    {active ? (
                      <div>
                        <div className="dom-progress" style={{ height: 5 }}>
                          <div
                            className="dom-progress-fill"
                            style={{
                              width: `${Math.min(100, (player.techProgress / effectiveCost) * 100)}%`,
                              background: '#38bdf8',
                            }}
                          />
                        </div>
                        <div className="font-mono-num" style={{ fontSize: 9.5, color: '#38bdf8', marginTop: 2 }}>
                          Researching: {Math.floor(player.techProgress).toLocaleString()}/{effectiveCost.toLocaleString()}
                        </div>
                      </div>
                    ) : unlocked ? (
                      <div className="font-mono-num" style={{ fontSize: 10, color: '#34d399', fontWeight: 600 }}>
                        Researched
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <div
                          className="font-mono-num"
                          style={{
                            fontSize: 9.5,
                            color: readyToStart ? '#f2cb77' : prereqsMet ? '#fbbf24' : '#7b8ca4',
                            display: 'flex',
                            justifyContent: 'space-between',
                          }}
                        >
                          <span>{effectiveCost.toLocaleString()} Sci</span>
                          {savedProg > 0 && (
                            <span style={{ color: '#38bdf8' }}>
                              {Math.round((savedProg / effectiveCost) * 100)}% saved
                            </span>
                          )}
                        </div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, alignItems: 'center' }}>
                          {status.alreadyFunded ? (
                            <span style={{ fontSize: 9, color: '#34d399', fontWeight: 600 }}>Funded</span>
                          ) : (
                            resList.slice(0, 3).map((rk) => {
                              const need = tech.resourceCost?.[rk] ?? 0;
                              const ok = player.resources[rk] >= need;
                              return (
                                <span
                                  key={rk}
                                  className="font-mono-num"
                                  style={{
                                    fontSize: 8.8,
                                    padding: '1px 4px',
                                    borderRadius: 3,
                                    background: ok ? 'rgba(52, 211, 153, 0.14)' : 'rgba(239, 68, 68, 0.14)',
                                    color: ok ? '#6ee7b7' : '#fca5a5',
                                    border: `1px solid ${ok ? 'rgba(52, 211, 153, 0.35)' : 'rgba(239, 68, 68, 0.35)'}`,
                                  }}
                                >
                                  {fmtCompact(need)} {RES_ABBR[rk]}
                                </span>
                              );
                            })
                          )}
                          {!status.alreadyFunded && resList.length > 3 && (
                            <span style={{ fontSize: 8.8, color: '#9fb0c7' }}>+{resList.length - 3}</span>
                          )}
                          {status.missingBuilding && (
                            <span
                              style={{
                                fontSize: 8.5,
                                padding: '1px 4px',
                                borderRadius: 3,
                                background: 'rgba(245, 158, 11, 0.16)',
                                color: '#fcd34d',
                                border: '1px solid rgba(245, 158, 11, 0.35)',
                              }}
                            >
                              Need {BUILDING_BY_ID[status.missingBuilding]?.name ?? status.missingBuilding}
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Technology Inspector Sidebar */}
          <aside
            style={{
              width: 345,
              flexShrink: 0,
              borderLeft: '1px solid #223044',
              background: '#0c131f',
              padding: 14,
              display: 'flex',
              flexDirection: 'column',
              gap: 11,
              overflowY: 'auto',
            }}
          >
            <div>
              <div
                style={{
                  display: 'inline-block',
                  fontSize: 10,
                  fontWeight: 700,
                  padding: '2px 7px',
                  borderRadius: 4,
                  background: `${inspectedEra.badgeColor}22`,
                  color: inspectedEra.badgeColor,
                  border: `1px solid ${inspectedEra.badgeColor}55`,
                  marginBottom: 5,
                }}
              >
                {inspectedEra.name}
              </div>
              <div className="font-display" style={{ fontSize: 17, fontWeight: 700, color: '#f8fafc' }}>
                {inspectedTech.name}
              </div>
              <p style={{ fontSize: 11.5, color: '#9fb0c7', lineHeight: 1.45, margin: '4px 0 0' }}>
                {inspectedTech.description}
              </p>
            </div>

            {/* Science Cost & Difficulty Scaling */}
            <div className="dom-card" style={{ padding: '9px 10px' }}>
              <div style={{ fontSize: 10.5, fontWeight: 700, color: '#38bdf8', marginBottom: 6 }}>
                RESEARCH REQUIREMENT
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 3 }}>
                <span style={{ color: '#9fb0c7' }}>Base Science Cost</span>
                <span className="font-mono-num">{inspectedTech.cost.toLocaleString()} Sci</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 3 }}>
                <span style={{ color: '#9fb0c7' }}>Complexity ({player.unlockedTechs.length} unlocked)</span>
                <span className="font-mono-num" style={{ color: '#f59e0b' }}>
                  ×{inspectedStatus.complexityMult.toFixed(2)}
                </span>
              </div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontSize: 12,
                  fontWeight: 700,
                  paddingTop: 4,
                  borderTop: '1px solid #1e2a3c',
                }}
              >
                <span style={{ color: '#e6ecf5' }}>Effective Cost</span>
                <span className="font-mono-num" style={{ color: '#38bdf8' }}>
                  {inspectedStatus.effectiveSciCost.toLocaleString()} Sci
                </span>
              </div>
              {!inspectedStatus.alreadyUnlocked && (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, marginTop: 4, color: '#8da2be' }}>
                  <span>Est. Completion Time (1x)</span>
                  <span className="font-mono-num">~{etaMinutes.toFixed(1)} min</span>
                </div>
              )}
              {(isInspectedActive || inspectedSavedProgress > 0) && !inspectedStatus.alreadyUnlocked && (
                <div style={{ marginTop: 7 }}>
                  <div className="dom-progress" style={{ height: 6 }}>
                    <div
                      className="dom-progress-fill"
                      style={{
                        width: `${Math.min(100, (inspectedSavedProgress / inspectedStatus.effectiveSciCost) * 100)}%`,
                        background: '#38bdf8',
                      }}
                    />
                  </div>
                  <div className="font-mono-num" style={{ fontSize: 10, color: '#7dd3fc', marginTop: 3 }}>
                    Progress: {Math.floor(inspectedSavedProgress).toLocaleString()} / {inspectedStatus.effectiveSciCost.toLocaleString()}
                  </div>
                </div>
              )}
            </div>

            {/* Prerequisites & Required Infrastructure */}
            {(inspectedTech.prerequisites.length > 0 || inspectedTech.requiredBuilding) && (
              <div className="dom-card" style={{ padding: '9px 10px' }}>
                <div style={{ fontSize: 10.5, fontWeight: 700, color: '#f2cb77', marginBottom: 6 }}>
                  PREREQUISITES &amp; INFRASTRUCTURE
                </div>
                {inspectedTech.prerequisites.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: inspectedTech.requiredBuilding ? 7 : 0 }}>
                    {inspectedTech.prerequisites.map((pid) => {
                      const p = TECH_BY_ID[pid];
                      const met = player.unlockedTechs.includes(pid);
                      return (
                        <button
                          key={pid}
                          onClick={() => setInspectedId(pid)}
                          style={{
                            fontSize: 10.5,
                            padding: '3px 7px',
                            borderRadius: 4,
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                            background: met ? 'rgba(52, 211, 153, 0.14)' : 'rgba(239, 68, 68, 0.14)',
                            color: met ? '#6ee7b7' : '#fca5a5',
                            border: `1px solid ${met ? 'rgba(52, 211, 153, 0.35)' : 'rgba(239, 68, 68, 0.35)'}`,
                          }}
                        >
                          {met ? <Check size={11} /> : <Lock size={11} />}
                          {p?.name ?? pid}
                        </button>
                      );
                    })}
                  </div>
                )}
                {inspectedTech.requiredBuilding && (
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: 11,
                      padding: '5px 7px',
                      borderRadius: 4,
                      background: inspectedStatus.missingBuilding
                        ? 'rgba(239, 68, 68, 0.12)'
                        : 'rgba(52, 211, 153, 0.12)',
                      border: `1px solid ${
                        inspectedStatus.missingBuilding ? 'rgba(239, 68, 68, 0.35)' : 'rgba(52, 211, 153, 0.35)'
                      }`,
                      color: inspectedStatus.missingBuilding ? '#fca5a5' : '#6ee7b7',
                    }}
                  >
                    <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                      <Building2 size={12} />
                      {BUILDING_BY_ID[inspectedTech.requiredBuilding]?.name ?? inspectedTech.requiredBuilding}
                    </span>
                    <span style={{ fontSize: 10, fontWeight: 700 }}>
                      {inspectedStatus.missingBuilding ? 'Not Built' : 'Built'}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Required Resources to Research */}
            {resEntries.length > 0 && (
              <div className="dom-card" style={{ padding: '9px 10px' }}>
                <div
                  style={{
                    fontSize: 10.5,
                    fontWeight: 700,
                    color: '#f2cb77',
                    marginBottom: 6,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <Coins size={12} /> REQUIRED RESOURCES
                  </span>
                  {inspectedStatus.alreadyFunded && (
                    <span style={{ fontSize: 9.5, color: '#34d399' }}>ALREADY FUNDED</span>
                  )}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
                  {resEntries.map((r) => {
                    const met = inspectedStatus.alreadyFunded || r.have >= r.need;
                    return (
                      <div
                        key={r.key}
                        style={{
                          padding: '5px 7px',
                          borderRadius: 4,
                          background: met ? 'rgba(52, 211, 153, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                          border: `1px solid ${met ? 'rgba(52, 211, 153, 0.3)' : 'rgba(239, 68, 68, 0.35)'}`,
                        }}
                      >
                        <div style={{ fontSize: 10, color: '#cbd5e1', fontWeight: 600 }}>{RES_SHORT[r.key]}</div>
                        <div
                          className="font-mono-num"
                          style={{ fontSize: 10.5, color: met ? '#6ee7b7' : '#fca5a5', fontWeight: 700 }}
                        >
                          {inspectedStatus.alreadyFunded
                            ? `${r.need.toLocaleString()} Paid`
                            : `${r.have.toLocaleString()} / ${r.need.toLocaleString()}`}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Unlocks & Bonuses */}
            <div className="dom-card" style={{ padding: '9px 10px' }}>
              <div style={{ fontSize: 10.5, fontWeight: 700, color: '#34d399', marginBottom: 5 }}>
                UNLOCKS &amp; BONUSES
              </div>
              <ul style={{ margin: 0, paddingLeft: 16, fontSize: 11, color: '#cbd5e1', lineHeight: 1.5 }}>
                {inspectedTech.unlocksText.map((txt) => (
                  <li key={txt}>{txt}</li>
                ))}
              </ul>
            </div>

            {/* Action Button */}
            <div style={{ marginTop: 'auto', paddingTop: 4 }}>
              {inspectedStatus.alreadyUnlocked ? (
                <button className="dom-btn" disabled style={{ width: '100%', justifyContent: 'center', opacity: 0.75, color: '#6ee7b7' }}>
                  <Check size={14} /> Technology Researched
                </button>
              ) : isInspectedActive ? (
                <button className="dom-btn" disabled style={{ width: '100%', justifyContent: 'center', color: '#7dd3fc', borderColor: '#38bdf8' }}>
                  <Sparkles size={14} /> Researching ({Math.round((player.techProgress / inspectedStatus.effectiveSciCost) * 100)}%)
                </button>
              ) : inspectedStatus.canStart ? (
                <button
                  className="dom-btn dom-btn-primary"
                  style={{ width: '100%', justifyContent: 'center', padding: '9px 12px', fontWeight: 700 }}
                  onClick={() => onSelectTech(inspectedTech.id)}
                >
                  <Atom size={14} />
                  {inspectedStatus.alreadyFunded
                    ? 'Resume Research'
                    : player.currentTechId
                      ? 'Fund & Switch Research (Progress Saved)'
                      : 'Fund & Start Research'}
                </button>
              ) : (
                <button
                  className="dom-btn"
                  disabled
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                    padding: '9px 12px',
                    opacity: 0.72,
                    color: '#fca5a5',
                    borderColor: 'rgba(239, 68, 68, 0.35)',
                    fontSize: 11,
                  }}
                >
                  <Lock size={13} /> {formatTechBlockReason(inspectedStatus)}
                </button>
              )}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
