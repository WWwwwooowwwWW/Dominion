import React from 'react';
import { Anchor, Atom, Building2, HelpCircle, Swords, X } from 'lucide-react';

interface Props {
  onClose: () => void;
}

export const TutorialModal: React.FC<Props> = ({ onClose }) => {
  const steps = [
    {
      icon: <Swords size={18} color="#ef4444" />,
      title: '1. Expand & Conquer Wilderness',
      body: 'Click any adjacent unclaimed wilderness or rival nation territory on the map. Review terrain defense, deposits, and win odds in the Right Inspector, then click ATTACK TERRITORY or ATTACK NATION.',
    },
    {
      icon: <Building2 size={18} color="#d4a84f" />,
      title: '2. Develop Cities & Resources',
      body: 'Select your owned provinces to construct Farms, Mines, Markets, Banks, Town Halls, and Fortresses. Assign citizen occupations in the Cities panel and watch your production grow across continents.',
    },
    {
      icon: <Atom size={18} color="#38bdf8" />,
      title: '3. Research Technologies & Eras',
      body: 'Open the Technology Tree from the left panel (or click Science in the top bar). Later eras grow significantly harder and require investing strategic resources (Gold, Iron, Coal, Oil, Energy) plus building Libraries, Universities, Labs, and Power Stations.',
    },
    {
      icon: <Anchor size={18} color="#38bdf8" />,
      title: '4. Build a Navy & Launch Amphibious Invasions',
      body: 'Build a Port or Naval Base in a coastal city, construct Transport Ships and Warships, embark an army onto the fleet, sail across the ocean, and click LAUNCH AMPHIBIOUS INVASION on an overseas shoreline!',
    },
  ];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" style={{ width: 'min(740px, 94vw)' }} onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <HelpCircle size={20} color="#34d399" />
            <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
              DOMINION Tactical Field Guide
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>
        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {steps.map((s) => (
            <div key={s.title} className="dom-card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700, fontSize: 13, color: '#f2cb77', marginBottom: 6 }}>
                {s.icon} {s.title}
              </div>
              <p style={{ fontSize: 12, color: '#cbd5e1', lineHeight: 1.5, margin: 0 }}>{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
