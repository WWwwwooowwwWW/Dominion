import React from 'react';
import { Crown, Trophy } from 'lucide-react';
import { GameState } from '../../types/game';
import { NationFlag } from '../NationFlag';

interface Props {
  state: GameState;
  onContinuePlaying: () => void;
  onReturnToMenu: () => void;
}

export const VictoryModal: React.FC<Props> = ({ state, onContinuePlaying, onReturnToMenu }) => {
  const winnerId = state.victory.winnerNationId;
  if (!winnerId || state.victory.continuedAfterVictory) return null;
  const winner = state.nations[winnerId];
  if (!winner) return null;

  const isPlayerWinner = winner.id === state.playerNationId;

  return (
    <div className="dom-modal-backdrop">
      <div className="dom-modal" style={{ width: 'min(520px, 92vw)' }}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Trophy size={22} color="#f2cb77" />
            <div className="font-display" style={{ fontSize: 17, fontWeight: 700, color: '#f2cb77' }}>
              {isPlayerWinner ? 'SUPREME DOMINION ACHIEVED' : 'A RIVAL CLAIMED VICTORY'}
            </div>
          </div>
        </div>
        <div className="dom-modal-body" style={{ textAlign: 'center', padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 12 }}>
            <NationFlag color={winner.color} secondaryColor={winner.secondaryColor} emblem={winner.emblem} size={56} />
          </div>
          <div className="font-display" style={{ fontSize: 20, fontWeight: 700, color: '#f2cb77' }}>
            {winner.name}
          </div>
          <div style={{ fontSize: 13, color: '#38bdf8', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 4 }}>
            <Crown size={14} style={{ verticalAlign: 'middle' }} /> {state.victory.victoryType} Victory
          </div>
          <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.55, marginTop: 14 }}>
            {isPlayerWinner
              ? `Your civilization has risen from a humble settlement to dominate the world across ${winner.stats.territoriesConquered} conquered territories!`
              : `${winner.name} met the ${(state.victory.victoryType ?? '').toUpperCase()} victory conditions before your empire.`}
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 20 }}>
            <button className="dom-btn dom-btn-gold" onClick={onContinuePlaying}>
              Continue Playing
            </button>
            <button className="dom-btn" onClick={onReturnToMenu}>
              Return to Main Menu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
