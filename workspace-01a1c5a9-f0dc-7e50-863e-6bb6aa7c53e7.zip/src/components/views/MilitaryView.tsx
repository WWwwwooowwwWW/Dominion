import React, { useState } from 'react';
import { Crosshair, Shield, Swords, X } from 'lucide-react';
import { UNIT_BY_ID, UNITS } from '../../data/units';
import { computeArmyPower, getArmyTotalUnitCount } from '../../engine/combat';
import { canAfford } from '../../engine/economy';
import { GameState } from '../../types/game';

interface Props {
  state: GameState;
  onRecruitUnits: (cityId: string, unitId: string, count: number) => void;
  onSelectArmyOnMap: (armyId: string, territoryId: string) => void;
  onToggleFortify: (armyId: string) => void;
  onClose: () => void;
}

export const MilitaryView: React.FC<Props> = ({
  state,
  onRecruitUnits,
  onSelectArmyOnMap,
  onToggleFortify,
  onClose,
}) => {
  const player = state.nations[state.playerNationId];
  const cities = Object.values(state.cities).filter((c) => c.nationId === state.playerNationId);
  const [recruitCityId, setRecruitCityId] = useState<string>(cities[0]?.id ?? '');
  const armies = Object.values(state.armies).filter((a) => a.nationId === state.playerNationId);

  if (!player) return null;
  const activeCity = cities.find((c) => c.id === recruitCityId) ?? cities[0];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Swords size={20} color="#ef4444" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Land Armed Forces &amp; Recruitment Command
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Total Military Power: <b className="font-mono-num" style={{ color: '#f2cb77' }}>{player.stats.militaryPower}</b> •{' '}
                Battles Won: <b style={{ color: '#34d399' }}>{player.stats.totalBattlesWon}</b> / Lost:{' '}
                <b style={{ color: '#ef4444' }}>{player.stats.totalBattlesLost}</b>
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Active Standing Armies */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77' }}>
              Standing Armies ({armies.length})
            </div>
            {armies.length === 0 ? (
              <div className="dom-card" style={{ color: '#9fb0c7', fontSize: 12 }}>
                No standing armies. Recruit forces on the right panel.
              </div>
            ) : (
              armies.map((army) => (
                <div key={army.id} className="dom-card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 13, color: '#f8fafc' }}>{army.name}</div>
                      <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                        Stationed: <b>{state.territories[army.territoryId]?.name}</b>
                        {army.embarkedFleetId && <span style={{ color: '#38bdf8' }}> (Embarked at Sea)</span>}
                        {army.inBattleId && <span style={{ color: '#ef4444', fontWeight: 700 }}> (In Combat!)</span>}
                      </div>
                    </div>
                    <span className="dom-badge" style={{ color: '#f2cb77' }}>
                      Pow {Math.round(computeArmyPower(army, false, state))}
                    </span>
                  </div>

                  <div style={{ display: 'flex', gap: 8, fontSize: 11, color: '#9fb0c7', marginBottom: 6 }}>
                    <span>Units: <b className="font-mono-num">{getArmyTotalUnitCount(army)}</b></span>
                    <span>Morale: <b className="font-mono-num" style={{ color: '#34d399' }}>{Math.round(army.morale)}%</b></span>
                    <span>Supply: <b className="font-mono-num" style={{ color: '#38bdf8' }}>{Math.round(army.supply)}%</b></span>
                  </div>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
                    {army.units.map((u) => (
                      <span key={u.unitId} className="dom-badge">
                        {u.count}x {UNIT_BY_ID[u.unitId]?.name} ({Math.round(u.hp)}% HP)
                      </span>
                    ))}
                  </div>

                  <div style={{ display: 'flex', gap: 6 }}>
                    <button
                      className="dom-btn dom-btn-gold"
                      onClick={() => {
                        onSelectArmyOnMap(army.id, army.territoryId);
                        onClose();
                      }}
                    >
                      <Crosshair size={13} /> Command on Map
                    </button>
                    <button className="dom-btn" onClick={() => onToggleFortify(army.id)}>
                      <Shield size={13} /> {army.fortified ? 'Unfortify' : 'Fortify (+20% Def)'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Recruitment Yard */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77' }}>Recruit Land &amp; Air Divisions</span>
              {cities.length > 0 && (
                <select
                  className="dom-select"
                  value={activeCity?.id ?? ''}
                  onChange={(e) => setRecruitCityId(e.target.value)}
                >
                  {cities.map((c) => (
                    <option key={c.id} value={c.id}>
                      Train in {c.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 7, maxHeight: 500, overflowY: 'auto' }}>
              {UNITS.filter((u) => u.domain !== 'naval').map((u) => {
                const lockedTech = u.requiredTech && !player.unlockedTechs.includes(u.requiredTech);
                const needsAir =
                  u.domain === 'air' &&
                  (!activeCity || !activeCity.buildings.some((b) => b.buildingId === 'airbases' || b.buildingId === 'airports'));
                const affordable1 = canAfford(player, u.cost);
                const costStr = Object.entries(u.cost)
                  .map(([k, v]) => `${v} ${k}`)
                  .join(', ');

                return (
                  <div key={u.id} className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12.5 }}>
                        {u.name}{' '}
                        <span className="dom-badge" style={{ marginLeft: 5, textTransform: 'uppercase', fontSize: 9.5 }}>
                          {u.era}
                        </span>
                      </div>
                      <div style={{ fontSize: 11, color: '#9fb0c7', marginTop: 2 }}>{u.description}</div>
                      <div style={{ fontSize: 10.5, color: '#d4a84f', marginTop: 3 }}>
                        Str {u.strength} • Def {u.defense} • Spd {u.speed} • Cost: {costStr}
                      </div>
                      {lockedTech && <div style={{ fontSize: 10, color: '#ef4444' }}>Requires Tech: {u.requiredTech}</div>}
                      {needsAir && <div style={{ fontSize: 10, color: '#38bdf8' }}>Requires Airbase or Airport in {activeCity?.name}</div>}
                    </div>
                    <div style={{ display: 'flex', gap: 5 }}>
                      <button
                        className="dom-btn dom-btn-emerald"
                        disabled={Boolean(!activeCity || lockedTech || needsAir || !affordable1)}
                        onClick={() => activeCity && onRecruitUnits(activeCity.id, u.id, 1)}
                      >
                        +1
                      </button>
                      <button
                        className="dom-btn"
                        disabled={Boolean(!activeCity || lockedTech || needsAir || !affordable1)}
                        onClick={() => activeCity && onRecruitUnits(activeCity.id, u.id, 3)}
                      >
                        +3
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
