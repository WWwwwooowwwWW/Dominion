import React, { useState } from 'react';
import { Coins, Handshake, Shield, Swords, X } from 'lucide-react';
import { ERA_BY_ID } from '../../data/eras';
import { GOVERNMENTS } from '../../data/governments';
import { GameState, ResourceKey } from '../../types/game';
import { NationFlag } from '../NationFlag';

interface Props {
  state: GameState;
  onDiplomacyAction: (
    otherId: string,
    action: 'war' | 'peace' | 'trade' | 'non_aggression' | 'defensive_pact' | 'alliance' | 'gift' | 'exchange',
    giftResource?: ResourceKey,
    giftAmount?: number
  ) => void;
  onClose: () => void;
}

export const DiplomacyView: React.FC<Props> = ({ state, onDiplomacyAction, onClose }) => {
  const player = state.nations[state.playerNationId];
  const [feedback, setFeedback] = useState<string>('');
  if (!player) return null;

  const others = Object.values(state.nations).filter((n) => n.id !== player.id);

  const runAction = (
    otherId: string,
    action: Parameters<typeof onDiplomacyAction>[1],
    res?: ResourceKey,
    amt?: number
  ) => {
    onDiplomacyAction(otherId, action, res, amt);
    setFeedback(`Diplomatic envoy dispatched to ${state.nations[otherId]?.name}.`);
  };

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Handshake size={20} color="#d4a84f" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Foreign Affairs &amp; Diplomatic Corps
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Active Trade Agreements, Alliances, Non-Aggression Pacts &amp; Coalitions
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {feedback && (
            <div className="dom-card-gold" style={{ fontSize: 12, color: '#f2cb77', padding: '8px 12px' }}>
              {feedback}
            </div>
          )}

          {others.map((other) => {
            const rel = player.relations[other.id];
            const terrCount = state.territoryIds.filter(
              (id) => !state.territories[id].isWater && state.territories[id].ownerId === other.id
            ).length;

            return (
              <div
                key={other.id}
                className="dom-card"
                style={{
                  opacity: other.eliminated ? 0.5 : 1,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 12,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 11, minWidth: 260 }}>
                  <NationFlag
                    color={other.color}
                    secondaryColor={other.secondaryColor}
                    emblem={other.emblem}
                    size={38}
                  />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: other.color }}>
                      {other.name}{' '}
                      {other.eliminated && <span className="dom-badge" style={{ color: '#ef4444' }}>ELIMINATED</span>}
                      {other.isHumanMultiplayer && <span className="dom-badge" style={{ color: '#38bdf8' }}>PLAYER</span>}
                    </div>
                    <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                      {other.leaderName} • {ERA_BY_ID[other.era].shortName} • {GOVERNMENTS[other.government].name}
                    </div>
                    <div style={{ fontSize: 11, color: '#cbd5e1', marginTop: 2 }}>
                      Territories: <b className="font-mono-num">{terrCount}</b> • Military:{' '}
                      <b className="font-mono-num" style={{ color: '#f59e0b' }}>{other.stats.militaryPower}</b> • Personality:{' '}
                      <span style={{ textTransform: 'capitalize' }}>{other.aiPersonality}</span>
                    </div>
                  </div>
                </div>

                {!other.eliminated && rel && (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 7 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      <span
                        className="dom-badge font-mono-num"
                        style={{
                          color: rel.atWar ? '#ef4444' : rel.score >= 20 ? '#34d399' : '#f59e0b',
                        }}
                      >
                        Relations: {rel.score > 0 ? `+${rel.score}` : rel.score}
                      </span>
                      {rel.atWar && <span className="dom-badge" style={{ color: '#ef4444', borderColor: '#ef4444' }}>AT WAR</span>}
                      {rel.alliance && <span className="dom-badge" style={{ color: '#34d399' }}>ALLIANCE</span>}
                      {rel.defensivePact && !rel.alliance && <span className="dom-badge" style={{ color: '#38bdf8' }}>DEFENSIVE PACT</span>}
                      {rel.tradeAgreement && <span className="dom-badge" style={{ color: '#f2cb77' }}>TRADE PACT</span>}
                      {rel.nonAggression && <span className="dom-badge">NON-AGGRESSION</span>}
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                      {rel.atWar ? (
                        <button className="dom-btn dom-btn-emerald" onClick={() => runAction(other.id, 'peace')}>
                          Negotiate Peace
                        </button>
                      ) : (
                        <>
                          <button
                            className="dom-btn"
                            disabled={rel.tradeAgreement}
                            onClick={() => runAction(other.id, 'trade')}
                          >
                            Trade Agreement
                          </button>
                          <button
                            className="dom-btn"
                            disabled={rel.nonAggression}
                            onClick={() => runAction(other.id, 'non_aggression')}
                          >
                            Non-Aggression
                          </button>
                          <button
                            className="dom-btn dom-btn-cobalt"
                            disabled={rel.defensivePact}
                            onClick={() => runAction(other.id, 'defensive_pact')}
                          >
                            <Shield size={12} /> Defensive Pact
                          </button>
                          <button
                            className="dom-btn dom-btn-emerald"
                            disabled={rel.alliance}
                            onClick={() => runAction(other.id, 'alliance')}
                          >
                            <Handshake size={12} /> Alliance
                          </button>
                          <button className="dom-btn dom-btn-gold" onClick={() => runAction(other.id, 'gift', 'gold', 75)}>
                            <Coins size={12} /> Gift 75G (+22 Rel)
                          </button>
                          <button className="dom-btn" onClick={() => runAction(other.id, 'exchange')}>
                            Barter 80G → Iron/Wood
                          </button>
                          <button className="dom-btn dom-btn-danger" onClick={() => runAction(other.id, 'war')}>
                            <Swords size={12} /> Declare War
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
