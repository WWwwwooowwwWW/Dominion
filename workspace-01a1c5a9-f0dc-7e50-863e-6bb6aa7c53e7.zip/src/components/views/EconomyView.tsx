import React from 'react';
import { ArrowDownRight, ArrowUpRight, Coins, TrendingUp, X } from 'lucide-react';
import { ALL_RESOURCE_KEYS } from '../../engine/economy';
import { GameState } from '../../types/game';

interface Props {
  state: GameState;
  onMarketTrade: (
    resource: 'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil',
    side: 'buy' | 'sell',
    amount: number
  ) => void;
  onClose: () => void;
}

export const EconomyView: React.FC<Props> = ({ state, onMarketTrade, onClose }) => {
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const ownedTerritories = state.territoryIds.filter(
    (id) => !state.territories[id].isWater && state.territories[id].ownerId === player.id
  ).length;

  const commodities: Array<'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil'> = [
    'food',
    'wood',
    'stone',
    'iron',
    'coal',
    'oil',
  ];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Coins size={20} color="#f2cb77" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                National Treasury, Market &amp; Trade Routes
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Controlled Territories: <b>{ownedTerritories}</b> (Gradual Scaling Tier:{' '}
                {ownedTerritories <= 10
                  ? '100% Full Output'
                  : ownedTerritories <= 25
                    ? '75% Marginal Scaling'
                    : ownedTerritories <= 50
                      ? '55% Marginal Scaling'
                      : '38% Imperial Scaling'}
                )
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 16 }}>
          {/* Resource Production & Consumption Ledger */}
          <div className="dom-card">
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', marginBottom: 8 }}>
              Resource Production Dashboard (per minute)
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11.5 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #243247', color: '#9fb0c7', textAlign: 'left' }}>
                  <th style={{ padding: '6px 4px' }}>Resource</th>
                  <th style={{ padding: '6px 4px' }}>Stock</th>
                  <th style={{ padding: '6px 4px' }}>Territory</th>
                  <th style={{ padding: '6px 4px' }}>Deposits</th>
                  <th style={{ padding: '6px 4px' }}>Buildings</th>
                  <th style={{ padding: '6px 4px' }}>Upkeep</th>
                  <th style={{ padding: '6px 4px' }}>Net/min</th>
                </tr>
              </thead>
              <tbody>
                {ALL_RESOURCE_KEYS.map((k) => {
                  const net = player.ratesPerMin[k];
                  return (
                    <tr key={k} style={{ borderBottom: '1px solid #182334' }}>
                      <td style={{ padding: '6px 4px', textTransform: 'capitalize', fontWeight: 700 }}>{k}</td>
                      <td className="font-mono-num" style={{ padding: '6px 4px' }}>
                        {Math.floor(player.resources[k])}
                      </td>
                      <td className="font-mono-num" style={{ padding: '6px 4px', color: '#34d399' }}>
                        +{player.territoryProductionBreakdown[k].toFixed(1)}
                      </td>
                      <td className="font-mono-num" style={{ padding: '6px 4px', color: '#38bdf8' }}>
                        +{player.naturalDepositBreakdown[k].toFixed(1)}
                      </td>
                      <td className="font-mono-num" style={{ padding: '6px 4px', color: '#f2cb77' }}>
                        +{player.buildingProductionBreakdown[k].toFixed(1)}
                      </td>
                      <td className="font-mono-num" style={{ padding: '6px 4px', color: '#ef4444' }}>
                        -{player.consumptionPerMin[k].toFixed(1)}
                      </td>
                      <td
                        className="font-mono-num"
                        style={{
                          padding: '6px 4px',
                          fontWeight: 700,
                          color: net >= 0 ? '#34d399' : '#ef4444',
                        }}
                      >
                        {net >= 0 ? `+${net.toFixed(1)}` : net.toFixed(1)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Global Commodity Market & Trade Routes */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="dom-card">
              <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <TrendingUp size={15} /> Global Commodity Exchange
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {commodities.map((c) => {
                  const price = state.market.prices[c];
                  const trend = state.market.demandTrend[c];
                  return (
                    <div
                      key={c}
                      className="dom-panel"
                      style={{ padding: '6px 9px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                    >
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 12, textTransform: 'capitalize' }}>
                          {c}{' '}
                          <span className="font-mono-num" style={{ color: '#f2cb77', marginLeft: 5 }}>
                            {price.toFixed(2)}G
                          </span>
                          {trend > 0 ? (
                            <ArrowUpRight size={12} color="#34d399" style={{ verticalAlign: 'middle' }} />
                          ) : trend < 0 ? (
                            <ArrowDownRight size={12} color="#ef4444" style={{ verticalAlign: 'middle' }} />
                          ) : null}
                        </div>
                        <div style={{ fontSize: 10, color: '#9fb0c7' }}>Owned: {Math.floor(player.resources[c])}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button
                          className="dom-btn dom-btn-emerald"
                          style={{ padding: '3px 8px', fontSize: 10.5 }}
                          disabled={player.resources.gold < Math.ceil(price * 50)}
                          onClick={() => onMarketTrade(c, 'buy', 50)}
                        >
                          Buy 50
                        </button>
                        <button
                          className="dom-btn"
                          style={{ padding: '3px 8px', fontSize: 10.5 }}
                          disabled={player.resources[c] < 50}
                          onClick={() => onMarketTrade(c, 'sell', 50)}
                        >
                          Sell 50
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="dom-card">
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#38bdf8', marginBottom: 6 }}>
                Active International Trade Routes ({state.tradeRoutes.filter((r) => r.fromNationId === player.id || r.toNationId === player.id).length})
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5, maxHeight: 155, overflowY: 'auto' }}>
                {state.tradeRoutes.filter((r) => r.fromNationId === player.id || r.toNationId === player.id).length === 0 ? (
                  <div style={{ fontSize: 11.5, color: '#667892' }}>
                    Sign Trade Agreements in Diplomacy to establish maritime &amp; overland trade corridors.
                  </div>
                ) : (
                  state.tradeRoutes
                    .filter((r) => r.fromNationId === player.id || r.toNationId === player.id)
                    .map((r) => {
                      const partnerId = r.fromNationId === player.id ? r.toNationId : r.fromNationId;
                      return (
                        <div key={r.id} className="dom-panel" style={{ padding: '5px 8px', fontSize: 11, display: 'flex', justifyContent: 'space-between' }}>
                          <span>
                            {r.isMaritime ? '⚓ Maritime' : '🐪 Overland'} with <b>{state.nations[partnerId]?.name}</b>
                          </span>
                          <span style={{ color: r.disrupted ? '#ef4444' : '#34d399', fontWeight: 700 }}>
                            {r.disrupted ? 'BLOCKADED' : `+${r.goldPerMin} G/min`}
                          </span>
                        </div>
                      );
                    })
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
