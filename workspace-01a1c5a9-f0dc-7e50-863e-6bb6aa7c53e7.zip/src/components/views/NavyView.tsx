import React, { useState } from 'react';
import { Anchor, Crosshair, Navigation, Ship, Swords, Waves, X } from 'lucide-react';
import { UNIT_BY_ID, UNITS } from '../../data/units';
import { computeFleetPower, getArmyTotalUnitCount, getFleetTransportCapacity } from '../../engine/combat';
import { canAfford } from '../../engine/economy';
import { Fleet, GameState } from '../../types/game';

interface Props {
  state: GameState;
  onRecruitUnits: (cityId: string, unitId: string, count: number) => void;
  onSelectFleetOnMap: (fleetId: string, territoryId: string) => void;
  onMoveFleet: (fleetId: string, targetTerritoryId: string, mission?: Fleet['mission']) => void;
  onEmbarkArmy: (armyId: string, fleetId: string) => void;
  onLaunchAmphibious: (fleetId: string, targetTerritoryId: string) => void;
  onClose: () => void;
}

export const NavyView: React.FC<Props> = ({
  state,
  onRecruitUnits,
  onSelectFleetOnMap,
  onMoveFleet,
  onEmbarkArmy,
  onLaunchAmphibious,
  onClose,
}) => {
  const player = state.nations[state.playerNationId];
  const coastalCities = Object.values(state.cities).filter(
    (c) =>
      c.nationId === state.playerNationId &&
      c.buildings.some((b) => b.buildingId === 'ports' || b.buildingId === 'naval_bases')
  );
  const [shipyardCityId, setShipyardCityId] = useState<string>(coastalCities[0]?.id ?? '');
  const fleets = Object.values(state.fleets).filter((f) => f.nationId === state.playerNationId);
  const armies = Object.values(state.armies).filter((a) => a.nationId === state.playerNationId && !a.embarkedFleetId);

  if (!player) return null;
  const activeYard = coastalCities.find((c) => c.id === shipyardCityId) ?? coastalCities[0];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Anchor size={20} color="#38bdf8" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Admiralty, Naval Bases &amp; Amphibious Command
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                Naval Power: <b className="font-mono-num" style={{ color: '#38bdf8' }}>{player.stats.navalPower}</b> •{' '}
                Active Fleets: <b>{fleets.length}</b> • Harbors/Naval Bases: <b>{coastalCities.length}</b>
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 16 }}>
          {/* Active Fleets & Amphibious Actions */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Waves size={15} /> Active Fleets &amp; Sea Operations
            </div>

            {fleets.length === 0 ? (
              <div className="dom-card" style={{ color: '#9fb0c7', fontSize: 12, lineHeight: 1.5 }}>
                No fleets commissioned yet. Build a <b>Port</b> or <b>Naval Base</b> in a coastal city, then construct Transport Ships and Warships on the right.
              </div>
            ) : (
              fleets.map((fl) => {
                const cap = getFleetTransportCapacity(fl);
                const curTerr = state.territories[fl.territoryId];
                const nearbyCoastalArmies = armies.filter(
                  (a) =>
                    state.territories[a.territoryId]?.isCoastal &&
                    (a.territoryId === fl.territoryId || curTerr?.neighbors.includes(a.territoryId))
                );
                const adjacentHostileCoasts = (curTerr?.landNeighbors ?? [])
                  .map((id) => state.territories[id])
                  .filter((t) => t && t.isCoastal && t.ownerId !== player.id);

                return (
                  <div key={fl.id} className="dom-card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#38bdf8' }}>{fl.name}</div>
                        <div style={{ fontSize: 11, color: '#9fb0c7' }}>
                          Position: <b>{curTerr?.name}</b> • Mission:{' '}
                          <b style={{ color: '#f2cb77', textTransform: 'capitalize' }}>{fl.mission}</b>
                        </div>
                      </div>
                      <span className="dom-badge" style={{ color: '#38bdf8' }}>
                        Pow {Math.round(computeFleetPower(fl, false, state))} • Cap {cap}
                      </span>
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 7 }}>
                      {fl.ships.map((s) => (
                        <span key={s.unitId} className="dom-badge">
                          {s.count}x {UNIT_BY_ID[s.unitId]?.name} ({Math.round(s.hp)}% HP)
                        </span>
                      ))}
                    </div>

                    {fl.carriedArmyIds.length > 0 && (
                      <div style={{ fontSize: 11, color: '#34d399', marginBottom: 7 }}>
                        Embarked Land Force:{' '}
                        {fl.carriedArmyIds.map((id) => state.armies[id]?.name).join(', ')}
                      </div>
                    )}

                    {/* Quick Embark / Amphibious Invasion / Patrol / Blockade */}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                      <button
                        className="dom-btn dom-btn-cobalt"
                        onClick={() => {
                          onSelectFleetOnMap(fl.id, fl.territoryId);
                          onClose();
                        }}
                      >
                        <Crosshair size={12} /> Command on Map
                      </button>

                      {curTerr?.isWater && (
                        <>
                          <button className="dom-btn" onClick={() => onMoveFleet(fl.id, fl.territoryId, 'patrol')}>
                            <Navigation size={12} /> Patrol Trade Lanes
                          </button>
                          <button className="dom-btn dom-btn-danger" onClick={() => onMoveFleet(fl.id, fl.territoryId, 'blockade')}>
                            Blockade Coast
                          </button>
                        </>
                      )}

                      {cap > 0 &&
                        nearbyCoastalArmies.map((army) => (
                          <button
                            key={army.id}
                            className="dom-btn dom-btn-emerald"
                            disabled={getArmyTotalUnitCount(army) > cap}
                            onClick={() => onEmbarkArmy(army.id, fl.id)}
                          >
                            <Ship size={12} /> Load {army.name}
                          </button>
                        ))}

                      {fl.carriedArmyIds.length > 0 &&
                        adjacentHostileCoasts.map((coast) => (
                          <button
                            key={coast.id}
                            className="dom-btn dom-btn-danger"
                            onClick={() => onLaunchAmphibious(fl.id, coast.id)}
                          >
                            <Swords size={12} /> Invade {coast.name}
                          </button>
                        ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Shipyards & Naval Construction */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77' }}>Shipyards &amp; Warship Construction</span>
              {coastalCities.length > 0 && (
                <select
                  className="dom-select"
                  value={activeYard?.id ?? ''}
                  onChange={(e) => setShipyardCityId(e.target.value)}
                >
                  {coastalCities.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} Harbor
                    </option>
                  ))}
                </select>
              )}
            </div>

            {!activeYard && (
              <div className="dom-card" style={{ color: '#f59e0b', fontSize: 12 }}>
                No coastal city has a Port or Naval Base yet. Select one of your coastal cities on the map and construct a Port or Naval Base!
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 7, maxHeight: 500, overflowY: 'auto' }}>
              {UNITS.filter((u) => u.domain === 'naval').map((u) => {
                const lockedTech = u.requiredTech && !player.unlockedTechs.includes(u.requiredTech);
                const affordable = canAfford(player, u.cost);
                const costStr = Object.entries(u.cost)
                  .map(([k, v]) => `${v} ${k}`)
                  .join(', ');

                return (
                  <div key={u.id} className="dom-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12.5 }}>
                        {u.name}{' '}
                        <span className="dom-badge" style={{ marginLeft: 5, textTransform: 'uppercase', fontSize: 9.5 }}>
                          {u.era}
                        </span>
                        {u.transportCapacity && (
                          <span className="dom-badge" style={{ marginLeft: 5, color: '#34d399', fontSize: 9.5 }}>
                            Transport +{u.transportCapacity}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: 11, color: '#9fb0c7', marginTop: 2 }}>{u.description}</div>
                      <div style={{ fontSize: 10.5, color: '#d4a84f', marginTop: 3 }}>
                        Str {u.strength} • Spd {u.speed} • Cost: {costStr}
                      </div>
                      {lockedTech && <div style={{ fontSize: 10, color: '#ef4444' }}>Requires Tech: {u.requiredTech}</div>}
                    </div>
                    <button
                      className="dom-btn dom-btn-cobalt"
                      disabled={Boolean(!activeYard || lockedTech || !affordable)}
                      onClick={() => activeYard && onRecruitUnits(activeYard.id, u.id, 1)}
                    >
                      Launch +1
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
