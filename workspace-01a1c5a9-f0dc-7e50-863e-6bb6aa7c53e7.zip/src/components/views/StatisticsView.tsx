import React from 'react';
import { Award, BarChart3, Clock, Trophy, X } from 'lucide-react';
import { ERA_BY_ID } from '../../data/eras';
import { GameState } from '../../types/game';
import { NationFlag } from '../NationFlag';

interface Props {
  state: GameState;
  onClose: () => void;
}

export const StatisticsView: React.FC<Props> = ({ state, onClose }) => {
  const nations = Object.values(state.nations).sort((a, b) => {
    if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
    return b.stats.economicScore + b.stats.militaryPower - (a.stats.economicScore + a.stats.militaryPower);
  });

  const landTerritories = state.territoryIds.filter((id) => !state.territories[id].isWater);
  const worldPop = Object.values(state.cities).reduce((s, c) => s + c.population, 0);

  const victories = [
    { label: 'Territorial Victory', desc: 'Control 60% of habitable land', data: state.victory.territorial, color: '#34d399' },
    { label: 'Military Victory', desc: 'Achieve overwhelming military dominance', data: state.victory.military, color: '#ef4444' },
    { label: 'Economic Victory', desc: 'Reach 20,000 Economic Power', data: state.victory.economic, color: '#f2cb77' },
    { label: 'Scientific Victory', desc: 'Unlock Space Exploration apex tech', data: state.victory.scientific, color: '#38bdf8' },
    { label: 'Cultural Victory', desc: 'Reach 8,000 Cultural Prestige', data: state.victory.cultural, color: '#e879f9' },
    { label: 'Diplomatic Victory', desc: 'Forge global alliance network', data: state.victory.diplomatic, color: '#a78bfa' },
  ];

  return (
    <div className="dom-modal-backdrop" onClick={onClose}>
      <div className="dom-modal" onClick={(e) => e.stopPropagation()}>
        <div className="dom-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <BarChart3 size={20} color="#d4a84f" />
            <div>
              <div className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#f2cb77' }}>
                Global Rankings, Victory Progress &amp; Historical Chronicle
              </div>
              <div style={{ fontSize: 11.5, color: '#9fb0c7' }}>
                World Population: <b className="font-mono-num">{worldPop.toLocaleString()}</b> • Active Nations:{' '}
                <b>{nations.filter((n) => !n.eliminated).length}</b> • Total Land Provinces: <b>{landTerritories.length}</b>
              </div>
            </div>
          </div>
          <button className="dom-btn" onClick={onClose}>
            <X size={15} /> Close
          </button>
        </div>

        <div className="dom-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Victory Progress Grid */}
          <div className="dom-card">
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 9 }}>
              <Trophy size={15} /> Paths to Global Dominion
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {victories.map((v) => (
                <div key={v.label} className="dom-panel" style={{ padding: 9 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 700 }}>
                    <span style={{ color: v.color }}>{v.label}</span>
                    <span className="font-mono-num">{v.data.pct}%</span>
                  </div>
                  <div style={{ fontSize: 10, color: '#9fb0c7', margin: '2px 0 5px' }}>{v.desc}</div>
                  <div className="dom-progress">
                    <div className="dom-progress-fill" style={{ width: `${v.data.pct}%`, background: v.color }} />
                  </div>
                  <div className="font-mono-num" style={{ fontSize: 10, color: '#cbd5e1', marginTop: 3 }}>
                    {v.data.current.toLocaleString()} / {v.data.target.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 14 }}>
            {/* Power Rankings Table */}
            <div className="dom-card">
              <div style={{ fontSize: 13, fontWeight: 700, color: '#f2cb77', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Award size={15} /> World Power Rankings
              </div>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11.5 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #243247', color: '#9fb0c7', textAlign: 'left' }}>
                    <th style={{ padding: '5px 4px' }}>Civilization</th>
                    <th style={{ padding: '5px 4px' }}>Era</th>
                    <th style={{ padding: '5px 4px' }}>Land</th>
                    <th style={{ padding: '5px 4px' }}>Pop</th>
                    <th style={{ padding: '5px 4px' }}>Military</th>
                    <th style={{ padding: '5px 4px' }}>Economy</th>
                    <th style={{ padding: '5px 4px' }}>Techs</th>
                  </tr>
                </thead>
                <tbody>
                  {nations.map((n) => {
                    const tCount = landTerritories.filter((id) => state.territories[id].ownerId === n.id).length;
                    const pop = Object.values(state.cities)
                      .filter((c) => c.nationId === n.id)
                      .reduce((s, c) => s + c.population, 0);
                    return (
                      <tr
                        key={n.id}
                        style={{
                          borderBottom: '1px solid #182334',
                          opacity: n.eliminated ? 0.45 : 1,
                          background: n.id === state.playerNationId ? 'rgba(212, 168, 79, 0.08)' : undefined,
                        }}
                      >
                        <td style={{ padding: '6px 4px', display: 'flex', alignItems: 'center', gap: 6 }}>
                          <NationFlag color={n.color} secondaryColor={n.secondaryColor} emblem={n.emblem} size={20} />
                          <span style={{ fontWeight: 700, color: n.id === state.playerNationId ? '#f2cb77' : '#e2e8f0' }}>
                            {n.name}
                          </span>
                        </td>
                        <td style={{ padding: '6px 4px' }}>{ERA_BY_ID[n.era].shortName}</td>
                        <td className="font-mono-num" style={{ padding: '6px 4px' }}>{tCount}</td>
                        <td className="font-mono-num" style={{ padding: '6px 4px' }}>{pop.toLocaleString()}</td>
                        <td className="font-mono-num" style={{ padding: '6px 4px', color: '#ef4444' }}>{n.stats.militaryPower}</td>
                        <td className="font-mono-num" style={{ padding: '6px 4px', color: '#f2cb77' }}>{n.stats.economicScore}</td>
                        <td className="font-mono-num" style={{ padding: '6px 4px', color: '#38bdf8' }}>{n.unlockedTechs.length}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Historical Timeline */}
            <div className="dom-card">
              <div style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Clock size={15} /> Historical Timeline
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 280, overflowY: 'auto' }}>
                {state.timeline.map((item) => (
                  <div key={item.id} className="dom-panel" style={{ padding: '6px 9px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, fontWeight: 700 }}>
                      <span style={{ color: '#f2cb77' }}>{item.title}</span>
                      <span className="font-mono-num" style={{ color: '#9fb0c7' }}>{item.yearLabel}</span>
                    </div>
                    <div style={{ fontSize: 10.5, color: '#cbd5e1', marginTop: 2 }}>{item.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
