export type ResourceKey =
  | 'gold'
  | 'food'
  | 'wood'
  | 'stone'
  | 'iron'
  | 'coal'
  | 'oil'
  | 'science'
  | 'culture'
  | 'influence'
  | 'energy';

export type ResourcePool = Record<ResourceKey, number>;

export type EraId =
  | 'ancient'
  | 'classical'
  | 'medieval'
  | 'renaissance'
  | 'industrial'
  | 'modern'
  | 'future';

export type LandTerrainType =
  | 'plains'
  | 'grassland'
  | 'forest'
  | 'hills'
  | 'mountains'
  | 'desert'
  | 'tundra'
  | 'snow';

export type SeaTerrainType = 'ocean' | 'coastal_water';

export type TerrainType = LandTerrainType | SeaTerrainType;

export type MapOverlayMode =
  | 'political'
  | 'terrain'
  | 'resource'
  | 'military'
  | 'naval'
  | 'population'
  | 'economic';

export type OccupationKey =
  | 'farmers'
  | 'miners'
  | 'builders'
  | 'researchers'
  | 'merchants'
  | 'factory_workers'
  | 'government_workers'
  | 'soldiers';

export type BuildingCategory =
  | 'residential'
  | 'economic'
  | 'industrial'
  | 'agricultural'
  | 'scientific'
  | 'infrastructure'
  | 'government'
  | 'military';

export type GovernmentType =
  | 'tribal'
  | 'monarchy'
  | 'republic'
  | 'democracy'
  | 'dictatorship'
  | 'constitutional_monarchy'
  | 'federal_republic';

export type AIDifficulty = 'easy' | 'normal' | 'hard';
export type AIPersonality = 'expansionist' | 'defensive' | 'economic' | 'aggressive' | 'passive';
export type VictoryType = 'territorial' | 'military' | 'economic' | 'scientific' | 'cultural' | 'diplomatic';
export type MapSize = 'small' | 'medium' | 'large';
export type GameSpeed = 0 | 1 | 2 | 4;

export type LeftNavTab =
  | 'cities'
  | 'military'
  | 'navy'
  | 'technology'
  | 'diplomacy'
  | 'economy'
  | 'government'
  | 'statistics';

export interface Point2D {
  x: number;
  y: number;
}

export interface RiverPath {
  id: string;
  name: string;
  points: Point2D[];
  width: number;
}

export interface LakeFeature {
  id: string;
  name: string;
  center: Point2D;
  polygon: Point2D[];
}

export interface ResourceDeposit {
  resource: 'iron' | 'coal' | 'oil' | 'gold' | 'stone' | 'wood' | 'food';
  richness: number; // 1 = standard, 2 = rich, 3 = abundant
}

export interface Territory {
  id: string;
  name: string;
  isWater: boolean;
  terrain: TerrainType;
  center: Point2D;
  polygon: Point2D[];
  neighbors: string[]; // All adjacent territory IDs (land + sea)
  landNeighbors: string[];
  seaNeighbors: string[];
  riverBorderNeighbors: string[]; // Neighbors separated by a river
  isCoastal: boolean;
  hasRiver: boolean;
  elevation: number;
  moisture: number;
  continentId: number;
  deposits: ResourceDeposit[];
  populationCapacity: number;
  strategicValue: number; // 1..10
  conquestDifficulty: number; // 1..10
  ownerId: string | null; // null = unclaimed wilderness (if !isWater) or international waters
  wildernessGarrison: number; // Tribal/native defenders in unclaimed land
  fortLevel: number; // 0..3
  hasBridge: boolean;
  cityId: string | null;
  blockadedByNationId: string | null;
  occupationUnrest: number; // 0..100
  weatherStorm: boolean; // Active storm in sea zone or coastal zone
}

export interface BuildingDefinition {
  id: string;
  name: string;
  category: BuildingCategory;
  era: EraId;
  requiredTech: string | null;
  cost: Partial<ResourcePool>;
  buildTime: number; // simulation seconds
  upkeepGold: number;
  upkeepEnergy?: number;
  coastalOnly?: boolean;
  maxLevel: number;
  description: string;
  effects: {
    housing?: number;
    happiness?: number;
    health?: number;
    security?: number;
    defenseBonus?: number;
    infrastructure?: number;
    storageBonus?: number;
    adminCapacity?: number;
    navalSupply?: number;
    allowsShipbuilding?: boolean;
    allowsAir?: boolean;
    negatesRiverPenalty?: boolean;
    production?: Partial<ResourcePool>;
    jobSlots?: Partial<Record<OccupationKey, number>>;
  };
}

export interface CityBuildingInstance {
  buildingId: string;
  level: number;
}

export interface ConstructionItem {
  id: string;
  cityId: string;
  territoryId: string;
  buildingId: string;
  targetLevel: number;
  progress: number;
  totalTime: number;
}

export interface City {
  id: string;
  name: string;
  territoryId: string;
  nationId: string;
  isCapital: boolean;
  tier: number; // 1 = Settlement, 2 = Town, 3 = City, 4 = Metropolis, 5 = Megacity
  population: number;
  housing: number;
  foodProduction: number;
  industrialOutput: number;
  economicOutput: number;
  happiness: number; // 0..100
  health: number; // 0..100
  education: number; // 0..100
  infrastructure: number; // 0..100
  security: number; // 0..100
  unemploymentRate: number; // 0..100
  birthRate: number; // per 1000
  deathRate: number; // per 1000
  diseaseOutbreak: boolean;
  buildings: CityBuildingInstance[];
  queue: ConstructionItem[];
  occupations: Record<OccupationKey, number>; // Assigned citizens
}

export type UnitDomain = 'land' | 'naval' | 'air';

export interface UnitDefinition {
  id: string;
  name: string;
  domain: UnitDomain;
  era: EraId;
  requiredTech: string | null;
  requiresCoastalBase?: boolean;
  cost: Partial<ResourcePool>;
  manpower: number;
  upkeepGold: number;
  upkeepOil?: number;
  strength: number;
  defense: number;
  speed: number; // map units / sec
  trainTime: number;
  transportCapacity?: number; // for naval transports
  role: 'infantry' | 'anti_cavalry' | 'ranged' | 'cavalry' | 'siege' | 'armor' | 'air' | 'robotic' | 'transport' | 'warship' | 'capital_ship' | 'submarine' | 'carrier';
  description: string;
}

export interface UnitStack {
  unitId: string;
  count: number;
  hp: number; // average 0..100
  experience: number; // 0..100
}

export interface Army {
  id: string;
  name: string;
  nationId: string;
  territoryId: string;
  targetTerritoryId: string | null;
  path: string[];
  moveProgress: number; // 0..1 along current edge
  units: UnitStack[];
  supply: number; // 0..100
  morale: number; // 0..100
  fortified: boolean;
  embarkedFleetId: string | null;
  inBattleId: string | null;
}

export interface Fleet {
  id: string;
  name: string;
  nationId: string;
  territoryId: string; // Sea zone or coastal territory port
  targetTerritoryId: string | null;
  path: string[];
  moveProgress: number;
  ships: UnitStack[];
  supply: number; // 0..100
  morale: number; // 0..100
  mission: 'idle' | 'patrol' | 'blockade' | 'transport' | 'attack';
  carriedArmyIds: string[];
  inBattleId: string | null;
}

export interface RecruitmentOrder {
  id: string;
  nationId: string;
  cityId: string;
  territoryId: string;
  unitId: string;
  count: number;
  progress: number;
  totalTime: number;
}

export interface ActiveBattle {
  id: string;
  kind: 'land' | 'naval' | 'amphibious';
  territoryId: string;
  attackerNationId: string;
  defenderNationId: string | null; // null = wilderness
  attackerArmyIds: string[];
  defenderArmyIds: string[];
  attackerFleetIds: string[];
  defenderFleetIds: string[];
  attackerInitialPower: number;
  defenderInitialPower: number;
  attackerCurrentPower: number;
  defenderCurrentPower: number;
  attackerCasualties: number;
  defenderCasualties: number;
  terrainModifier: number; // e.g. 1.65 for mountains
  riverPenaltyApplied: boolean;
  coastalSupportBonus: number;
  progress: number; // 0..100 attacker momentum
  startedAtTick: number;
  log: string[];
}

export type TreatyType = 'peace' | 'trade' | 'non_aggression' | 'defensive_pact' | 'alliance' | 'war';

export interface DiplomaticRelation {
  otherNationId: string;
  score: number; // -100 to +100
  atWar: boolean;
  tradeAgreement: boolean;
  nonAggression: boolean;
  defensivePact: boolean;
  alliance: boolean;
  coalitionId: string | null;
  truceUntilTick: number;
  lastActionTick: number;
}

export interface TradeRoute {
  id: string;
  fromNationId: string;
  toNationId: string;
  fromCityId: string;
  toCityId: string;
  isMaritime: boolean;
  goldPerMin: number;
  resourceTraded: ResourceKey;
  amountPerMin: number;
  pathTerritoryIds: string[];
  disrupted: boolean;
}

export interface BudgetSettings {
  taxRate: number; // 0..50 (%)
  militarySpending: number; // 0..100 (%)
  educationFunding: number; // 0..100 (%)
  healthcareFunding: number; // 0..100 (%)
  infrastructureSpending: number; // 0..100 (%)
  tradeTariff: number; // 0..40 (%)
}

export interface PolicyDefinition {
  id: string;
  name: string;
  category: 'economic' | 'military' | 'social' | 'environmental' | 'diplomatic';
  requiredGov?: GovernmentType[];
  costInfluence: number;
  description: string;
  effects: {
    goldMod?: number;
    scienceMod?: number;
    productionMod?: number;
    militaryCostMod?: number;
    militaryPowerMod?: number;
    happinessMod?: number;
    healthMod?: number;
    diplomacyMod?: number;
    growthMod?: number;
  };
}

export interface NationStats {
  totalBattlesWon: number;
  totalBattlesLost: number;
  territoriesConquered: number;
  nationsEliminated: number;
  peakTerritories: number;
  peakPopulation: number;
  totalGoldEarned: number;
  militaryPower: number;
  navalPower: number;
  economicScore: number;
  scienceScore: number;
  cultureScore: number;
  diplomaticScore: number;
}

export interface Nation {
  id: string;
  name: string;
  adjective: string;
  leaderName: string;
  color: string;
  secondaryColor: string;
  emblem: 'eagle' | 'crown' | 'lion' | 'star' | 'sun' | 'anchor' | 'sword' | 'dragon' | 'shield' | 'crescent';
  isPlayer: boolean;
  isHumanMultiplayer: boolean;
  accountUsername?: string;
  aiDifficulty: AIDifficulty;
  aiPersonality: AIPersonality;
  eliminated: boolean;
  era: EraId;
  government: GovernmentType;
  activePolicies: string[];
  budget: BudgetSettings;
  resources: ResourcePool;
  ratesPerMin: ResourcePool;
  consumptionPerMin: ResourcePool;
  storageCaps: ResourcePool;
  territoryProductionBreakdown: ResourcePool;
  buildingProductionBreakdown: ResourcePool;
  naturalDepositBreakdown: ResourcePool;
  unlockedTechs: string[];
  currentTechId: string | null;
  techProgress: number;
  techQueue: string[];
  techFundedIds?: string[];
  techProgressById?: Record<string, number>;
  capitalTerritoryId: string | null;
  relations: Record<string, DiplomaticRelation>;
  aiCooldownTick: number;
  adminStrain: number; // 0..100
  overallHappiness: number; // 0..100
  stats: NationStats;
}

export interface TechDefinition {
  id: string;
  name: string;
  era: EraId;
  cost: number; // Base Science points
  resourceCost?: Partial<ResourcePool>; // Resources required to initiate research
  requiredBuilding?: string; // Must have built this building in at least one city
  prerequisites: string[];
  x: number; // column inside era (0..2)
  y: number; // row inside era (0..6)
  description: string;
  unlocksText: string[];
  bonuses?: {
    foodMod?: number;
    woodMod?: number;
    stoneMod?: number;
    ironMod?: number;
    goldMod?: number;
    scienceMod?: number;
    industryMod?: number;
    energyMod?: number;
    militaryPowerMod?: number;
    navalSpeedMod?: number;
    healthMod?: number;
    adminCapBonus?: number;
  };
}

export interface GameEventChoice {
  id: string;
  label: string;
  description: string;
  costGold?: number;
  effectSummary: string;
}

export interface PendingEvent {
  id: string;
  title: string;
  kind: 'drought' | 'flood' | 'earthquake' | 'storm' | 'disease' | 'discovery' | 'recession' | 'breakthrough' | 'boom' | 'instability';
  description: string;
  targetTerritoryId?: string;
  targetNationId: string;
  choices: GameEventChoice[];
  createdAtTick: number;
}

export interface TimelineEntry {
  id: string;
  tick: number;
  yearLabel: string;
  category: 'conquest' | 'war' | 'diplomacy' | 'tech' | 'era' | 'event' | 'victory' | 'city';
  title: string;
  description: string;
  nationId?: string;
}

export interface NotificationItem {
  id: string;
  tick: number;
  severity: 'info' | 'success' | 'warning' | 'danger';
  title: string;
  message: string;
  territoryId?: string;
}

export interface MarketState {
  prices: Record<'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil', number>;
  demandTrend: Record<'food' | 'wood' | 'stone' | 'iron' | 'coal' | 'oil', number>; // -1..1
}

export interface VictoryProgress {
  territorial: { current: number; target: number; pct: number };
  military: { current: number; target: number; pct: number };
  economic: { current: number; target: number; pct: number };
  scientific: { current: number; target: number; pct: number };
  cultural: { current: number; target: number; pct: number };
  diplomatic: { current: number; target: number; pct: number };
  winnerNationId: string | null;
  victoryType: VictoryType | null;
  continuedAfterVictory: boolean;
}

export interface GameConfig {
  mode: 'singleplayer' | 'custom' | 'multiplayer';
  seed: number;
  mapSize: MapSize;
  aiCount: number;
  aiDifficulty: AIDifficulty;
  startingEra: EraId;
  resourceAbundance: 'scarce' | 'standard' | 'abundant';
  terrainStyle: 'continents' | 'archipelago' | 'pangaea';
  startingResourcesMultiplier: number;
  playerNationName: string;
  playerLeaderName: string;
  playerColor: string;
  playerEmblem: Nation['emblem'];
  speedMultiplier: number;
}

export interface GameState {
  id: string;
  name: string;
  config: GameConfig;
  tick: number;
  speed: GameSpeed;
  year: number; // starts -4000 (4000 BC)
  worldWidth: number;
  worldHeight: number;
  territories: Record<string, Territory>;
  territoryIds: string[];
  rivers: RiverPath[];
  lakes: LakeFeature[];
  nations: Record<string, Nation>;
  playerNationId: string;
  cities: Record<string, City>;
  armies: Record<string, Army>;
  fleets: Record<string, Fleet>;
  battles: Record<string, ActiveBattle>;
  recruitmentQueue: RecruitmentOrder[];
  tradeRoutes: TradeRoute[];
  market: MarketState;
  timeline: TimelineEntry[];
  notifications: NotificationItem[];
  pendingEvent: PendingEvent | null;
  victory: VictoryProgress;
  nextEntitySeq: number;
}

export interface SaveSlotSummary {
  id: string;
  name: string;
  nationName: string;
  era: EraId;
  year: number;
  territoriesOwned: number;
  totalLandTerritories: number;
  difficulty: AIDifficulty;
  isAutosave: boolean;
  updatedAt: string;
}

export interface GameSettings {
  sfxEnabled: boolean;
  sfxVolume: number;
  showTerritoryLabels: boolean;
  showResourceBadges: boolean;
  showUnitBanners: boolean;
  showTradeRoutes: boolean;
  autosaveMinutes: number;
  uiScale: 'compact' | 'standard' | 'large';
}

export interface PlayerAccount {
  id: string;
  username: string;
  elo: number;
  wins: number;
  gamesPlayed: number;
  preferredColor: string;
  preferredEmblem: Nation['emblem'];
}

export interface MultiplayerLobby {
  id: string;
  name: string;
  inviteCode: string;
  isPublic: boolean;
  hostUsername: string;
  status: 'waiting' | 'in_progress' | 'finished';
  maxPlayers: number;
  aiCount: number;
  mapSize: MapSize;
  startingEra: EraId;
  players: Array<{
    username: string;
    nationName: string;
    color: string;
    emblem: Nation['emblem'];
    ready: boolean;
    connected: boolean;
    nationId?: string;
  }>;
  chat: Array<{
    id: string;
    username: string;
    message: string;
    timestamp: string;
  }>;
}
