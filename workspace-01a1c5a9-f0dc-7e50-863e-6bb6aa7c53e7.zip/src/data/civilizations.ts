import { AIPersonality, Nation } from '../types/game';

export interface CivTemplate {
  name: string;
  adjective: string;
  leaderName: string;
  color: string;
  secondaryColor: string;
  emblem: Nation['emblem'];
  personality: AIPersonality;
  capitalName: string;
}

export const AI_CIVILIZATION_TEMPLATES: CivTemplate[] = [
  {
    name: 'Aurelian Empire',
    adjective: 'Aurelian',
    leaderName: 'Marcus Valerius',
    color: '#c94c4c',
    secondaryColor: '#f3d27a',
    emblem: 'eagle',
    personality: 'expansionist',
    capitalName: 'Aurelia',
  },
  {
    name: 'Kingdom of Vaeloria',
    adjective: 'Vaelorian',
    leaderName: 'Queen Isolde IV',
    color: '#3b82f6',
    secondaryColor: '#e2e8f0',
    emblem: 'crown',
    personality: 'defensive',
    capitalName: 'Vaelor',
  },
  {
    name: 'Kharad Sultanate',
    adjective: 'Kharadi',
    leaderName: 'Sultan Tariq Al-Mansur',
    color: '#d97706',
    secondaryColor: '#fef3c7',
    emblem: 'crescent',
    personality: 'economic',
    capitalName: 'Kharad',
  },
  {
    name: 'Drakorian Reich',
    adjective: 'Drakorian',
    leaderName: 'Marshal Viktor Kroll',
    color: '#991b1b',
    secondaryColor: '#cbd5e1',
    emblem: 'sword',
    personality: 'aggressive',
    capitalName: 'Drakor',
  },
  {
    name: 'Thalassian League',
    adjective: 'Thalassian',
    leaderName: 'Doge Lorenzo Contarini',
    color: '#0d9488',
    secondaryColor: '#fcd34d',
    emblem: 'anchor',
    personality: 'economic',
    capitalName: 'Thalassia',
  },
  {
    name: 'Solari Dynasty',
    adjective: 'Solari',
    leaderName: 'Empress Meilin Zhou',
    color: '#eab308',
    secondaryColor: '#7f1d1d',
    emblem: 'dragon',
    personality: 'expansionist',
    capitalName: 'Xianyang',
  },
  {
    name: 'Nordheim Commonwealth',
    adjective: 'Nordic',
    leaderName: 'Jarl Astrid Lindqvist',
    color: '#0284c7',
    secondaryColor: '#f8fafc',
    emblem: 'shield',
    personality: 'defensive',
    capitalName: 'Nordheim',
  },
  {
    name: 'Verdant Republic',
    adjective: 'Verdant',
    leaderName: 'Consul Elena Rostova',
    color: '#16a34a',
    secondaryColor: '#fef08a',
    emblem: 'star',
    personality: 'passive',
    capitalName: 'Veridia',
  },
  {
    name: 'Obsidian Horde',
    adjective: 'Obsidian',
    leaderName: 'Khan Temur Batu',
    color: '#7c3aed',
    secondaryColor: '#fde047',
    emblem: 'sun',
    personality: 'aggressive',
    capitalName: 'Karakorum',
  },
  {
    name: 'Caledonian Union',
    adjective: 'Caledonian',
    leaderName: 'High King Duncan MacLeod',
    color: '#db2777',
    secondaryColor: '#f1f5f9',
    emblem: 'lion',
    personality: 'defensive',
    capitalName: 'Dunmore',
  },
  {
    name: 'Marathis Confederacy',
    adjective: 'Marathi',
    leaderName: 'Peshwa Arjun Rao',
    color: '#ea580c',
    secondaryColor: '#fffbeb',
    emblem: 'sun',
    personality: 'expansionist',
    capitalName: 'Devagiri',
  },
  {
    name: 'Aethiopian Crown',
    adjective: 'Aethiopian',
    leaderName: 'Negus Solomon Dawit',
    color: '#059669',
    secondaryColor: '#fde68a',
    emblem: 'lion',
    personality: 'passive',
    capitalName: 'Axum',
  },
];

export const TERRITORY_PREFIXES = [
  'North', 'South', 'East', 'West', 'Upper', 'Lower', 'High', 'New', 'Old', 'Grand',
  'Great', 'Inner', 'Outer', 'Silver', 'Golden', 'Iron', 'Storm', 'Sun', 'Mist', 'Shadow',
];

export const TERRITORY_ROOTS = [
  'Alder', 'Belen', 'Corinth', 'Dorn', 'Eldoria', 'Frey', 'Galdor', 'Halen', 'Illyria', 'Jorvik',
  'Kaldris', 'Lothar', 'Myr', 'Norden', 'Oakhaven', 'Pelor', 'Qart', 'Riven', 'Solis', 'Thule',
  'Ulster', 'Valken', 'Wester', 'Xanthus', 'Ymir', 'Zendar', 'Aethel', 'Boreas', 'Caspia', 'Dacia',
  'Epirus', 'Flanders', 'Galia', 'Hesperia', 'Iberia', 'Jutland', 'Kiev', 'Lycia', 'Mercia', 'Navarre',
  'Ostia', 'Pontus', 'Rhone', 'Silesia', 'Thrace', 'Umbria', 'Valen', 'Wessex', 'Yara', 'Zama',
  'Arden', 'Bavaria', 'Carinth', 'Dalmat', 'Estia', 'Friuli', 'Ghent', 'Holstein', 'Istria', 'Karst',
  'Livonia', 'Moravia', 'Normand', 'Orkney', 'Picardy', 'Ravenna', 'Savoy', 'Tyrol', 'Vistula', 'Wallach',
];

export const TERRITORY_SUFFIXES_BY_TERRAIN: Record<string, string[]> = {
  plains: ['Plains', 'Steppes', 'Heartland', 'Reach', 'Downs'],
  grassland: ['Meadows', 'Vale', 'Pastures', 'Shire', 'Greenland'],
  forest: ['Woods', 'Weald', 'Timberland', 'Thicket', 'Forest'],
  hills: ['Highlands', 'Ridges', 'Uplands', 'Foothills', 'Crags'],
  mountains: ['Peaks', 'Mountains', 'Alpine Pass', 'Summits', 'Sierra'],
  desert: ['Dunes', 'Sands', 'Wastes', 'Oasis', 'Badlands'],
  tundra: ['Tundra', 'Frostlands', 'Taiga', 'Barrens', 'Moor'],
  snow: ['Glacier', 'Icefields', 'Frostpeak', 'Snowlands', 'Shelf'],
  coastal_water: ['Bay', 'Sound', 'Strait', 'Gulf', 'Sea'],
  ocean: ['Ocean', 'Deep', 'Abyss', 'Trench', 'Expanse'],
};

export const RIVER_NAMES = [
  'Aurelia River', 'Silverflow', 'Vistula', 'Thalassos', 'Rivenwater', 'Danubia',
  'Oakhaven River', 'Suncrest', 'Galdor', 'Blackwater', 'Siberian', 'Euphrate',
];
