export interface EncyclopediaTopic {
  id: string;
  category: 'Core Mechanics' | 'Warfare & Naval' | 'Economy & Cities' | 'Diplomacy & Victory';
  title: string;
  summary: string;
  details: string[];
}

export const ENCYCLOPEDIA_TOPICS: EncyclopediaTopic[] = [
  {
    id: 'territorial_expansion',
    category: 'Core Mechanics',
    title: 'Territorial Expansion & Conquest',
    summary: 'DOMINION combines real-time territorial expansion with deep civilization management.',
    details: [
      'Click any unclaimed wilderness or rival nation territory on the map to inspect its terrain, resources, defensive strength, and strategic value.',
      'Expansion is always manual: choose an eligible army or fleet and click ATTACK TERRITORY or ATTACK NATION.',
      'Adjacent land territories can be attacked overland; overseas coastal territories can be invaded via Amphibious Assault using Transport Ships.',
      'Territorial Production Scaling: Territories 1–10 yield 100% base output; 11–25 yield 75%; 26–50 yield 55%; 51+ yield 38%, ensuring steady growth while preventing runaway snowballs.',
      'Build Town Halls, Courts, and Parliament Buildings to increase Administrative Capacity and prevent Overextension strain.',
    ],
  },
  {
    id: 'terrain_combat',
    category: 'Warfare & Naval',
    title: 'Terrain-Based Combat & Rivers',
    summary: 'Geography directly shapes movement speeds, defensive advantages, and logistical attrition.',
    details: [
      'Mountains (+68% defense, 2.1x travel time) and Forests (+32% defense) heavily favor defenders — a well-fortified smaller army can defeat a larger invading force.',
      'Attacking across a river inflicts a -25% combat penalty unless a Bridge has been built in your bordering city.',
      'Deserts and Snow impose supply attrition on invading armies if campaigns drag out.',
      'Fortresses add +35% defensive bonuses per tier, while Siege Equipment, Catapults, and Artillery specialize in breaking fortified lines.',
    ],
  },
  {
    id: 'naval_warfare',
    category: 'Warfare & Naval',
    title: 'Naval Warfare & Amphibious Invasions',
    summary: 'Command the oceans with warships, blockades, maritime trade patrols, and coastal landings.',
    details: [
      'Construct a Port or Naval Base in any coastal city to build fleets and repair damaged vessels.',
      'Naval ships move across connected ocean and coastal sea zones — never overland.',
      'Amphibious Invasion workflow: (1) Station an army in a coastal city, (2) Load it onto a Fleet containing Transport Ships, (3) Sail the Fleet adjacent to an enemy or wilderness coast, (4) Click Launch Amphibious Invasion.',
      'Naval Blockades stationed off enemy coasts disrupt enemy maritime trade routes and reduce coastal income without requiring a landing.',
    ],
  },
  {
    id: 'cities_population',
    category: 'Economy & Cities',
    title: 'Cities, Occupations & Society',
    summary: 'Develop conquered land into thriving cities across 8 building categories and 8 citizen occupations.',
    details: [
      'Citizens grow naturally when Food Surplus, Housing, Health, and Happiness are healthy.',
      'Assign citizens across Farmers, Miners, Builders, Researchers, Merchants, Factory Workers, Government Workers, and Soldiers to dynamically shape national yields.',
      'Prevent overcrowding by constructing Houses, Apartments, and Residential Districts; prevent disease outbreaks with Water Systems, Irrigation, and Medicine technologies.',
    ],
  },
  {
    id: 'technology_research',
    category: 'Economy & Cities',
    title: 'Technology Tree, Complexity & Resource Funding',
    summary: 'Advancing through the 7 historical eras requires Science output, strategic resources, and research infrastructure.',
    details: [
      'Every technology requires an upfront resource investment (such as Gold, Wood, Stone, Iron, Coal, Oil, or Energy) before research can begin.',
      'Key breakthrough technologies also require scientific or industrial infrastructure — such as a Library, University, Research Laboratory, Power Station, or Advanced Research Center — built in at least one of your cities.',
      'Knowledge Complexity: each already-researched technology adds +2.8% to the Science points required for subsequent breakthroughs, making late-era Industrial, Modern, and Future research progressively more challenging.',
      'If you switch technologies mid-research, your previously invested resources and Science progress are saved so you can resume anytime.',
    ],
  },
  {
    id: 'diplomacy_victory',
    category: 'Diplomacy & Victory',
    title: 'Diplomacy & Paths to Victory',
    summary: 'Achieve supreme dominion through conquest, military hegemony, wealth, science, culture, or diplomacy.',
    details: [
      'Establish Trade Agreements, Non-Aggression Pacts, Defensive Pacts, Alliances, or Coalitions with rival powers.',
      'Six Victory Conditions: Territorial (60% of habitable world), Military (global dominance or last nation standing), Economic (financial hegemony), Scientific (Space Exploration), Cultural (dominant influence), and Diplomatic (world alliance network).',
      'After achieving any victory, you may choose Continue Playing to rule your global empire indefinitely.',
    ],
  },
];
