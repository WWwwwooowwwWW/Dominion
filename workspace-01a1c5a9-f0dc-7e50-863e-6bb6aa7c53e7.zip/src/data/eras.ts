import { EraId } from '../types/game';

export interface EraDefinition {
  id: EraId;
  order: number;
  name: string;
  shortName: string;
  yearSpan: string;
  badgeColor: string;
  requiredTechCountInEra: number; // techs needed from this/earlier eras to advance, or unlocking an era's keystone tech
  description: string;
}

export const ERAS: EraDefinition[] = [
  {
    id: 'ancient',
    order: 0,
    name: 'Ancient Age',
    shortName: 'Ancient',
    yearSpan: '4000 BC – 600 BC',
    badgeColor: '#c28f4e',
    requiredTechCountInEra: 0,
    description: 'Dawn of agriculture, early settlements, bronze weaponry, and tribal organization.',
  },
  {
    id: 'classical',
    order: 1,
    name: 'Classical Age',
    shortName: 'Classical',
    yearSpan: '600 BC – 500 AD',
    badgeColor: '#d4a84f',
    requiredTechCountInEra: 3,
    description: 'Iron legions, paved highways, grand architecture, philosophy, and codified currency.',
  },
  {
    id: 'medieval',
    order: 2,
    name: 'Medieval Age',
    shortName: 'Medieval',
    yearSpan: '500 AD – 1450 AD',
    badgeColor: '#8b9dc3',
    requiredTechCountInEra: 8,
    description: 'Feudal castles, armored knights, ocean-going galleys, universities, and guilds.',
  },
  {
    id: 'renaissance',
    order: 3,
    name: 'Renaissance',
    shortName: 'Renaissance',
    yearSpan: '1450 AD – 1760 AD',
    badgeColor: '#b97fe0',
    requiredTechCountInEra: 14,
    description: 'Cartography, gunpowder warfare, transoceanic fleets, banking houses, and scientific inquiry.',
  },
  {
    id: 'industrial',
    order: 4,
    name: 'Industrial Age',
    shortName: 'Industrial',
    yearSpan: '1760 AD – 1920 AD',
    badgeColor: '#e08b4f',
    requiredTechCountInEra: 20,
    description: 'Steam locomotives, coal-fired factories, ironclad dreadnoughts, steel, and mass production.',
  },
  {
    id: 'modern',
    order: 5,
    name: 'Modern Age',
    shortName: 'Modern',
    yearSpan: '1920 AD – 2035 AD',
    badgeColor: '#38bdf8',
    requiredTechCountInEra: 27,
    description: 'Armored divisions, carrier strike groups, aviation, oil logistics, computers, and nuclear energy.',
  },
  {
    id: 'future',
    order: 6,
    name: 'Future Age',
    shortName: 'Future',
    yearSpan: '2035 AD+',
    badgeColor: '#34d399',
    requiredTechCountInEra: 34,
    description: 'Artificial intelligence, fusion power, robotic armies, orbital infrastructure, and space exploration.',
  },
];

export const ERA_BY_ID: Record<EraId, EraDefinition> = Object.fromEntries(
  ERAS.map((e) => [e.id, e])
) as Record<EraId, EraDefinition>;

export function formatYear(year: number): string {
  const rounded = Math.round(year);
  if (rounded < 0) return `${Math.abs(rounded)} BC`;
  if (rounded === 0) return '1 AD';
  return `${rounded} AD`;
}
