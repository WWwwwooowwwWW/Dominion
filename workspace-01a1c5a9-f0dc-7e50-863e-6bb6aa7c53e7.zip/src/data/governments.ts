import { EraId, GovernmentType, PolicyDefinition } from '../types/game';

export interface GovernmentDefinition {
  id: GovernmentType;
  name: string;
  requiredEra: EraId;
  requiredTech: string | null;
  description: string;
  advantages: string[];
  disadvantages: string[];
  modifiers: {
    goldMod: number;
    scienceMod: number;
    productionMod: number;
    militaryPowerMod: number;
    militaryCostMod: number;
    adminCapBonus: number;
    happinessMod: number;
    diplomacyMod: number;
  };
}

export const GOVERNMENTS: Record<GovernmentType, GovernmentDefinition> = {
  tribal: {
    id: 'tribal',
    name: 'Tribal Government',
    requiredEra: 'ancient',
    requiredTech: null,
    description: 'Clan council and warrior chieftains suited to early wilderness expansion.',
    advantages: ['Low military upkeep (-15%)', '+10% early warrior cohesion'],
    disadvantages: ['Low administrative capacity', '-15% science output'],
    modifiers: {
      goldMod: 0,
      scienceMod: -0.15,
      productionMod: 0,
      militaryPowerMod: 0.05,
      militaryCostMod: -0.15,
      adminCapBonus: 0,
      happinessMod: 2,
      diplomacyMod: -5,
    },
  },
  monarchy: {
    id: 'monarchy',
    name: 'Monarchy',
    requiredEra: 'medieval',
    requiredTech: 'feudalism',
    description: 'Hereditary royal crown backed by feudal nobility and standing garrisons.',
    advantages: ['+12% military power', '+6 administrative capacity', '+10% gold'],
    disadvantages: ['-5% science growth'],
    modifiers: {
      goldMod: 0.1,
      scienceMod: -0.05,
      productionMod: 0.08,
      militaryPowerMod: 0.12,
      militaryCostMod: -0.05,
      adminCapBonus: 6,
      happinessMod: 0,
      diplomacyMod: 5,
    },
  },
  republic: {
    id: 'republic',
    name: 'Republic',
    requiredEra: 'classical',
    requiredTech: 'philosophy',
    description: 'Senate-governed commonwealth balancing commercial wealth, civic law, and scholarship.',
    advantages: ['+18% gold output', '+15% science output', '+12 diplomatic standing'],
    disadvantages: ['+10% military upkeep'],
    modifiers: {
      goldMod: 0.18,
      scienceMod: 0.15,
      productionMod: 0.05,
      militaryPowerMod: 0.04,
      militaryCostMod: 0.1,
      adminCapBonus: 5,
      happinessMod: 5,
      diplomacyMod: 12,
    },
  },
  democracy: {
    id: 'democracy',
    name: 'Democracy',
    requiredEra: 'industrial',
    requiredTech: 'factories_tech',
    description: 'Universal suffrage parliament maximizing citizen happiness, research, and trade.',
    advantages: ['+25% science output', '+20% gold & trade', '+12 citizen happiness', '+18 diplomacy'],
    disadvantages: ['+18% military upkeep'],
    modifiers: {
      goldMod: 0.2,
      scienceMod: 0.25,
      productionMod: 0.12,
      militaryPowerMod: 0.05,
      militaryCostMod: 0.18,
      adminCapBonus: 8,
      happinessMod: 12,
      diplomacyMod: 18,
    },
  },
  dictatorship: {
    id: 'dictatorship',
    name: 'Dictatorship',
    requiredEra: 'industrial',
    requiredTech: 'factories_tech',
    description: 'Centralized authoritarian command prioritizing rapid militarization and heavy industry.',
    advantages: ['+25% military power', '-20% military upkeep', '+20% industrial output'],
    disadvantages: ['-12 citizen happiness', '-18 diplomatic trust'],
    modifiers: {
      goldMod: 0.05,
      scienceMod: 0.04,
      productionMod: 0.2,
      militaryPowerMod: 0.25,
      militaryCostMod: -0.2,
      adminCapBonus: 10,
      happinessMod: -12,
      diplomacyMod: -18,
    },
  },
  constitutional_monarchy: {
    id: 'constitutional_monarchy',
    name: 'Constitutional Monarchy',
    requiredEra: 'renaissance',
    requiredTech: 'banking_systems',
    description: 'Crowned parliamentary state blending royal stability with maritime commerce.',
    advantages: ['+18% gold output', '+12% military power', '+10 administrative capacity', '+10 diplomacy'],
    disadvantages: ['Moderate upkeep overhead'],
    modifiers: {
      goldMod: 0.18,
      scienceMod: 0.12,
      productionMod: 0.12,
      militaryPowerMod: 0.12,
      militaryCostMod: 0,
      adminCapBonus: 10,
      happinessMod: 7,
      diplomacyMod: 10,
    },
  },
  federal_republic: {
    id: 'federal_republic',
    name: 'Federal Republic',
    requiredEra: 'modern',
    requiredTech: 'automobiles',
    description: 'Autonomous federated provinces capable of governing vast continental empires.',
    advantages: ['+18 administrative capacity', '+22% science', '+22% gold & industry', '+10 happiness'],
    disadvantages: ['+12% military upkeep'],
    modifiers: {
      goldMod: 0.22,
      scienceMod: 0.22,
      productionMod: 0.22,
      militaryPowerMod: 0.1,
      militaryCostMod: 0.12,
      adminCapBonus: 18,
      happinessMod: 10,
      diplomacyMod: 15,
    },
  },
};

export const POLICIES: PolicyDefinition[] = [
  {
    id: 'free_trade_charter',
    name: 'Free Trade Charter',
    category: 'economic',
    costInfluence: 35,
    description: 'Slashes harbor tariffs and encourages merchant fleets to expand maritime trade.',
    effects: { goldMod: 0.15, diplomacyMod: 8 },
  },
  {
    id: 'industrial_subsidies',
    name: 'Industrial Subsidies',
    category: 'economic',
    costInfluence: 40,
    description: 'Directs state treasury grants into mines, foundries, and factories.',
    effects: { productionMod: 0.18, goldMod: -0.05 },
  },
  {
    id: 'conscription_act',
    name: 'National Conscription',
    category: 'military',
    costInfluence: 45,
    description: 'Expands reserve mobilization and cuts troop recruitment expenses.',
    effects: { militaryPowerMod: 0.15, militaryCostMod: -0.15, happinessMod: -5 },
  },
  {
    id: 'maritime_supremacy',
    name: 'Maritime Supremacy Doctrine',
    category: 'military',
    costInfluence: 45,
    description: 'Prioritizes shipyards, naval gunnery, and oceanic projection.',
    effects: { militaryPowerMod: 0.1, goldMod: 0.08 },
  },
  {
    id: 'universal_education',
    name: 'Universal Public Education',
    category: 'social',
    costInfluence: 40,
    description: 'Funds literacy and research academies across every province.',
    effects: { scienceMod: 0.22, happinessMod: 4 },
  },
  {
    id: 'public_healthcare',
    name: 'Universal Healthcare Initiative',
    category: 'social',
    costInfluence: 40,
    description: 'Expands clinics and sanitation, accelerating growth and preventing outbreaks.',
    effects: { healthMod: 15, growthMod: 0.2, happinessMod: 6 },
  },
  {
    id: 'environmental_accords',
    name: 'Environmental Stewardship',
    category: 'environmental',
    costInfluence: 35,
    description: 'Protects forests and rivers, improving citizen health and global goodwill.',
    effects: { healthMod: 10, happinessMod: 5, diplomacyMod: 10, productionMod: -0.04 },
  },
  {
    id: 'diplomatic_corps',
    name: 'Imperial Diplomatic Corps',
    category: 'diplomatic',
    costInfluence: 35,
    description: 'Establishes permanent embassies and cultural envoys abroad.',
    effects: { diplomacyMod: 18, goldMod: 0.05 },
  },
];

export const POLICY_BY_ID: Record<string, PolicyDefinition> = Object.fromEntries(
  POLICIES.map((p) => [p.id, p])
);
