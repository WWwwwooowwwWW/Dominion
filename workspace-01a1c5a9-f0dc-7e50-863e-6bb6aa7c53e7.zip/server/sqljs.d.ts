declare module 'sql.js' {
  export interface SqlValueResult {
    columns: string[];
    values: unknown[][];
  }
  export interface Statement {
    bind(values?: unknown[]): boolean;
    step(): boolean;
    getAsObject(): Record<string, unknown>;
    free(): boolean;
  }
  export interface Database {
    run(sql: string, params?: unknown[]): Database;
    exec(sql: string): SqlValueResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
  }
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer) => Database;
  }
  export default function initSqlJs(): Promise<SqlJsStatic>;
}
