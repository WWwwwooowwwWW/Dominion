import crypto from 'node:crypto';
import { WebSocket } from 'ws';
import {
  cmdAdjustCityOccupation,
  cmdAttackEnemyFleet,
  cmdAttackOrMoveArmy,
  cmdBuildStructure,
  cmdChangeGovernment,
  cmdDiplomacyAction,
  cmdEmbarkArmy,
  cmdEstablishCity,
  cmdLaunchAmphibiousInvasion,
  cmdMarketTrade,
  cmdMoveFleet,
  cmdRecruitUnits,
  cmdSelectTech,
  cmdTogglePolicy,
  cmdUpdateBudget,
  stepSimulation,
} from '../src/engine/simulation';
import { generateWorld } from '../src/engine/worldGen';
import { EraId, GameState, MapSize, MultiplayerLobby, Nation } from '../src/types/game';
import { recordAccountResult, recordMatchHistory } from './db';

interface ClientConn {
  ws: WebSocket;
  username: string;
  lobbyId: string | null;
}

interface RoomInternal {
  lobby: MultiplayerLobby;
  state: GameState | null;
  interval: NodeJS.Timeout | null;
  clients: Map<string, WebSocket>; // username -> ws
}

export class MultiplayerServer {
  private connections = new Map<WebSocket, ClientConn>();
  private rooms = new Map<string, RoomInternal>();

  public handleConnection(ws: WebSocket): void {
    const conn: ClientConn = { ws, username: 'Guest_' + Math.floor(1000 + Math.random() * 9000), lobbyId: null };
    this.connections.set(ws, conn);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        this.onMessage(ws, conn, msg);
      } catch {
        this.send(ws, { type: 'error', message: 'Malformed WebSocket payload.' });
      }
    });

    ws.on('close', () => {
      this.leaveCurrentLobby(conn);
      this.connections.delete(ws);
    });

    this.send(ws, { type: 'hello', lobbies: this.getPublicLobbies() });
  }

  private send(ws: WebSocket, data: unknown): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  }

  private broadcastPublicLobbies(): void {
    const lobbies = this.getPublicLobbies();
    for (const c of this.connections.values()) {
      if (!c.lobbyId) {
        this.send(c.ws, { type: 'lobbies_list', lobbies });
      }
    }
  }

  public getPublicLobbies(): MultiplayerLobby[] {
    return Array.from(this.rooms.values())
      .map((r) => r.lobby)
      .filter((l) => l.isPublic && l.status !== 'finished');
  }

  private broadcastRoom(room: RoomInternal, payload: unknown): void {
    const text = JSON.stringify(payload);
    for (const ws of room.clients.values()) {
      if (ws.readyState === WebSocket.OPEN) ws.send(text);
    }
  }

  private onMessage(ws: WebSocket, conn: ClientConn, msg: Record<string, unknown>): void {
    const type = String(msg.type || '');

    if (type === 'identify') {
      conn.username = String(msg.username || conn.username).slice(0, 24);
      this.send(ws, { type: 'identified', username: conn.username, lobbies: this.getPublicLobbies() });
      return;
    }

    if (type === 'list_lobbies') {
      this.send(ws, { type: 'lobbies_list', lobbies: this.getPublicLobbies() });
      return;
    }

    if (type === 'create_lobby') {
      this.leaveCurrentLobby(conn);
      const lobbyId = `mp_${crypto.randomUUID().slice(0, 8)}`;
      const inviteCode = 'DOM-' + Math.random().toString(36).substring(2, 6).toUpperCase();
      const lobby: MultiplayerLobby = {
        id: lobbyId,
        name: String(msg.name || `${conn.username}'s Campaign`).slice(0, 40),
        inviteCode,
        isPublic: Boolean(msg.isPublic ?? true),
        hostUsername: conn.username,
        status: 'waiting',
        maxPlayers: Math.min(8, Math.max(2, Number(msg.maxPlayers ?? 4))),
        aiCount: Math.min(8, Math.max(0, Number(msg.aiCount ?? 4))),
        mapSize: (['small', 'medium', 'large'].includes(String(msg.mapSize)) ? msg.mapSize : 'medium') as MapSize,
        startingEra: (String(msg.startingEra || 'ancient') as EraId),
        players: [
          {
            username: conn.username,
            nationName: String(msg.nationName || `${conn.username} Empire`).slice(0, 28),
            color: String(msg.color || '#2dd4bf'),
            emblem: (String(msg.emblem || 'eagle') as Nation['emblem']),
            ready: true,
            connected: true,
          },
        ],
        chat: [
          {
            id: `chat_${Date.now()}`,
            username: 'SYSTEM',
            message: `Match lobby created. Invite code: ${inviteCode}`,
            timestamp: new Date().toISOString(),
          },
        ],
      };

      const room: RoomInternal = {
        lobby,
        state: null,
        interval: null,
        clients: new Map([[conn.username, ws]]),
      };
      this.rooms.set(lobbyId, room);
      conn.lobbyId = lobbyId;
      this.send(ws, { type: 'lobby_joined', lobby });
      this.broadcastPublicLobbies();
      return;
    }

    if (type === 'join_lobby') {
      const targetId = msg.lobbyId ? String(msg.lobbyId) : null;
      const invite = msg.inviteCode ? String(msg.inviteCode).trim().toUpperCase() : null;
      const room = Array.from(this.rooms.values()).find(
        (r) => (targetId && r.lobby.id === targetId) || (invite && r.lobby.inviteCode === invite)
      );
      if (!room) {
        this.send(ws, { type: 'error', message: 'Match lobby or invite code not found.' });
        return;
      }
      if (room.lobby.status !== 'waiting') {
        this.send(ws, { type: 'error', message: 'Match has already started.' });
        return;
      }
      if (room.lobby.players.length >= room.lobby.maxPlayers && !room.lobby.players.some((p) => p.username === conn.username)) {
        this.send(ws, { type: 'error', message: 'Lobby is full.' });
        return;
      }

      this.leaveCurrentLobby(conn);
      conn.lobbyId = room.lobby.id;
      room.clients.set(conn.username, ws);
      const existing = room.lobby.players.find((p) => p.username === conn.username);
      if (existing) {
        existing.connected = true;
      } else {
        const palette = ['#38bdf8', '#f59e0b', '#a78bfa', '#f43f5e', '#34d399', '#fb7185', '#60a5fa'];
        room.lobby.players.push({
          username: conn.username,
          nationName: String(msg.nationName || `${conn.username} Realm`).slice(0, 28),
          color: String(msg.color || palette[room.lobby.players.length % palette.length]),
          emblem: (String(msg.emblem || 'crown') as Nation['emblem']),
          ready: false,
          connected: true,
        });
      }
      room.lobby.chat.push({
        id: `chat_${Date.now()}_${Math.random()}`,
        username: 'SYSTEM',
        message: `${conn.username} joined the lobby.`,
        timestamp: new Date().toISOString(),
      });
      this.broadcastRoom(room, { type: 'lobby_updated', lobby: room.lobby });
      this.send(ws, { type: 'lobby_joined', lobby: room.lobby });
      this.broadcastPublicLobbies();
      return;
    }

    if (type === 'leave_lobby') {
      this.leaveCurrentLobby(conn);
      this.send(ws, { type: 'lobby_left', lobbies: this.getPublicLobbies() });
      return;
    }

    const room = conn.lobbyId ? this.rooms.get(conn.lobbyId) : null;
    if (!room) {
      this.send(ws, { type: 'error', message: 'Not currently inside a multiplayer room.' });
      return;
    }

    if (type === 'chat') {
      const text = String(msg.message || '').trim().slice(0, 240);
      if (!text) return;
      const chatMsg = {
        id: `chat_${Date.now()}_${Math.random()}`,
        username: conn.username,
        message: text,
        timestamp: new Date().toISOString(),
      };
      room.lobby.chat.push(chatMsg);
      if (room.lobby.chat.length > 80) room.lobby.chat.shift();
      this.broadcastRoom(room, { type: 'lobby_chat', chat: chatMsg, lobby: room.lobby });
      return;
    }

    if (type === 'toggle_ready') {
      const p = room.lobby.players.find((pl) => pl.username === conn.username);
      if (p) {
        p.ready = !p.ready;
        if (msg.nationName) p.nationName = String(msg.nationName).slice(0, 28);
        if (msg.color) p.color = String(msg.color);
        this.broadcastRoom(room, { type: 'lobby_updated', lobby: room.lobby });
      }
      return;
    }

    if (type === 'start_match') {
      if (room.lobby.hostUsername !== conn.username) {
        this.send(ws, { type: 'error', message: 'Only the lobby host can launch the match.' });
        return;
      }
      this.launchRoomMatch(room);
      return;
    }

    if (type === 'game_command' && room.state) {
      this.applyPlayerCommand(room, conn, msg);
    }
  }

  private launchRoomMatch(room: RoomInternal): void {
    const humanCount = room.lobby.players.length;
    const totalNeededAI = Math.max(0, room.lobby.aiCount) + Math.max(0, humanCount - 1);
    const seed = Math.floor(Math.random() * 900000) + 1000;

    const hostP = room.lobby.players[0];
    const state = generateWorld({
      mode: 'multiplayer',
      seed,
      mapSize: room.lobby.mapSize,
      aiCount: totalNeededAI,
      aiDifficulty: 'normal',
      startingEra: room.lobby.startingEra,
      resourceAbundance: 'standard',
      terrainStyle: 'continents',
      startingResourcesMultiplier: 1.0,
      playerNationName: hostP.nationName,
      playerLeaderName: hostP.username,
      playerColor: hostP.color,
      playerEmblem: hostP.emblem,
      speedMultiplier: 1.0,
    });

    // Assign each additional human player to one of the spawned nations cleanly
    const nationKeys = Object.keys(state.nations);
    room.lobby.players.forEach((pl, idx) => {
      const nid = nationKeys[idx];
      if (!nid) return;
      const nation = state.nations[nid];
      nation.name = pl.nationName;
      nation.adjective = pl.nationName.split(' ')[0];
      nation.leaderName = pl.username;
      nation.color = pl.color;
      nation.emblem = pl.emblem;
      nation.isHumanMultiplayer = true;
      nation.isPlayer = idx === 0;
      nation.accountUsername = pl.username;
      pl.nationId = nid;
    });

    room.lobby.status = 'in_progress';
    room.state = state;

    // Send personalized view to each connected player (setting state.playerNationId to their nation!)
    for (const pl of room.lobby.players) {
      const pws = room.clients.get(pl.username);
      if (pws && pl.nationId) {
        this.send(pws, {
          type: 'match_started',
          lobby: room.lobby,
          yourNationId: pl.nationId,
          state: { ...state, playerNationId: pl.nationId },
        });
      }
    }
    this.broadcastPublicLobbies();

    // Start authoritative 1Hz simulation loop on server
    room.interval = setInterval(() => {
      if (!room.state || room.lobby.status !== 'in_progress') return;
      stepSimulation(room.state, 1.0);

      for (const pl of room.lobby.players) {
        const pws = room.clients.get(pl.username);
        if (pws && pl.nationId) {
          this.send(pws, {
            type: 'match_state',
            state: { ...room.state, playerNationId: pl.nationId },
          });
        }
      }

      if (room.state.victory.winnerNationId) {
        room.lobby.status = 'finished';
        if (room.interval) clearInterval(room.interval);
        const winner = room.state.nations[room.state.victory.winnerNationId];
        if (winner) {
          recordMatchHistory({
            winnerName: winner.name,
            victoryType: room.state.victory.victoryType ?? 'territorial',
            era: winner.era,
            year: room.state.year,
            mode: 'multiplayer',
            mapSize: room.state.config.mapSize,
            durationTicks: room.state.tick,
          }).catch(() => {});
          for (const pl of room.lobby.players) {
            recordAccountResult(pl.username, pl.nationId === winner.id).catch(() => {});
          }
        }
      }
    }, 1000);
  }

  private applyPlayerCommand(room: RoomInternal, conn: ClientConn, msg: Record<string, unknown>): void {
    const state = room.state;
    if (!state) return;
    const player = room.lobby.players.find((p) => p.username === conn.username);
    if (!player?.nationId) return;
    const nationId = player.nationId;
    const action = String(msg.action || '');
    const payload = (msg.payload ?? {}) as Record<string, unknown>;

    switch (action) {
      case 'attack_move_army':
        cmdAttackOrMoveArmy(state, nationId, String(payload.armyId), String(payload.targetTerritoryId));
        break;
      case 'move_fleet':
        cmdMoveFleet(state, nationId, String(payload.fleetId), String(payload.targetTerritoryId), (payload.mission as 'idle' | 'patrol' | 'blockade') ?? 'idle');
        break;
      case 'attack_fleet':
        cmdAttackEnemyFleet(state, nationId, String(payload.fleetId), String(payload.enemyFleetId));
        break;
      case 'embark_army':
        cmdEmbarkArmy(state, nationId, String(payload.armyId), String(payload.fleetId));
        break;
      case 'launch_amphibious':
        cmdLaunchAmphibiousInvasion(state, nationId, String(payload.fleetId), String(payload.targetTerritoryId));
        break;
      case 'establish_city':
        cmdEstablishCity(state, nationId, String(payload.territoryId));
        break;
      case 'build_structure':
        cmdBuildStructure(state, nationId, String(payload.cityId), String(payload.buildingId));
        break;
      case 'recruit_units':
        cmdRecruitUnits(state, nationId, String(payload.cityId), String(payload.unitId), Number(payload.count ?? 1));
        break;
      case 'select_tech': {
        const res = cmdSelectTech(state, nationId, String(payload.techId));
        if (!res.ok && res.error) {
          this.send(conn.ws, { type: 'error', message: res.error });
        }
        break;
      }
      case 'adjust_occupation':
        cmdAdjustCityOccupation(state, nationId, String(payload.cityId), payload.key as never, Number(payload.delta ?? 0));
        break;
      case 'diplomacy':
        cmdDiplomacyAction(state, nationId, String(payload.otherId), payload.dipAction as never, payload.giftResource as never, Number(payload.giftAmount ?? 100));
        break;
      case 'market_trade':
        cmdMarketTrade(state, nationId, payload.resource as never, payload.side as 'buy' | 'sell', Number(payload.amount ?? 50));
        break;
      case 'change_government':
        cmdChangeGovernment(state, nationId, payload.govId as never);
        break;
      case 'toggle_policy':
        cmdTogglePolicy(state, nationId, String(payload.policyId));
        break;
      case 'update_budget':
        cmdUpdateBudget(state, nationId, payload.patch as never);
        break;
      case 'set_speed':
        if (room.lobby.hostUsername === conn.username) {
          const sp = Number(payload.speed);
          if ([0, 1, 2, 4].includes(sp)) state.speed = sp as GameState['speed'];
        }
        break;
    }

    // Immediate ack broadcast so players see responsive UI
    for (const pl of room.lobby.players) {
      const pws = room.clients.get(pl.username);
      if (pws && pl.nationId) {
        this.send(pws, {
          type: 'match_state',
          state: { ...state, playerNationId: pl.nationId },
        });
      }
    }
  }

  private leaveCurrentLobby(conn: ClientConn): void {
    if (!conn.lobbyId) return;
    const room = this.rooms.get(conn.lobbyId);
    conn.lobbyId = null;
    if (!room) return;
    room.clients.delete(conn.username);
    room.lobby.players = room.lobby.players.filter((p) => p.username !== conn.username);
    if (room.lobby.players.length === 0) {
      if (room.interval) clearInterval(room.interval);
      this.rooms.delete(room.lobby.id);
    } else {
      if (room.lobby.hostUsername === conn.username) {
        room.lobby.hostUsername = room.lobby.players[0].username;
      }
      this.broadcastRoom(room, { type: 'lobby_updated', lobby: room.lobby });
    }
    this.broadcastPublicLobbies();
  }
}
