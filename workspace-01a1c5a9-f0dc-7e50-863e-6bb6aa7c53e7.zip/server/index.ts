import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { WebSocketServer } from 'ws';
import {
  deleteGameSlot,
  getDb,
  getLeaderboard,
  getMatchHistory,
  loadGameSlot,
  recordMatchHistory,
  registerOrLoginAccount,
  saveGameSlot,
  listSaveSlots,
} from './db';
import { MultiplayerServer } from './multiplayer';

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

async function bootstrap() {
  await getDb();

  const app = express();
  app.use(express.json({ limit: '25mb' }));

  // Ensure iframe-embeddable live preview headers
  app.use((_req, res, next) => {
    res.removeHeader('X-Frame-Options');
    next();
  });

  const mpServer = new MultiplayerServer();

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'dominion-server', timestamp: new Date().toISOString() });
  });

  app.post('/api/auth', async (req, res) => {
    try {
      const { username, password, preferredColor, preferredEmblem } = req.body ?? {};
      const result = await registerOrLoginAccount(
        String(username ?? ''),
        String(password ?? ''),
        preferredColor,
        preferredEmblem
      );
      if (!result.ok) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.get('/api/leaderboard', async (_req, res) => {
    const accounts = await getLeaderboard();
    res.json({ accounts });
  });

  app.get('/api/history', async (_req, res) => {
    const history = await getMatchHistory();
    res.json({ history });
  });

  app.post('/api/history', async (req, res) => {
    const b = req.body ?? {};
    await recordMatchHistory({
      winnerName: String(b.winnerName || 'Unknown'),
      victoryType: String(b.victoryType || 'territorial'),
      era: String(b.era || 'ancient'),
      year: Number(b.year || 0),
      mode: String(b.mode || 'singleplayer'),
      mapSize: String(b.mapSize || 'medium'),
      durationTicks: Number(b.durationTicks || 0),
    });
    res.json({ ok: true });
  });

  app.get('/api/saves', async (_req, res) => {
    const saves = await listSaveSlots();
    res.json({ saves });
  });

  app.post('/api/saves', async (req, res) => {
    try {
      const b = req.body ?? {};
      const slot = await saveGameSlot({
        id: String(b.id || `save_${Date.now()}`),
        name: String(b.name || 'Campaign Save'),
        nationName: String(b.nationName || 'Dominion'),
        era: String(b.era || 'ancient'),
        year: Number(b.year || -4000),
        territoriesOwned: Number(b.territoriesOwned || 1),
        totalLandTerritories: Number(b.totalLandTerritories || 100),
        difficulty: String(b.difficulty || 'normal'),
        isAutosave: Boolean(b.isAutosave),
        stateJson: typeof b.stateJson === 'string' ? b.stateJson : JSON.stringify(b.state),
      });
      res.json({ ok: true, slot });
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.get('/api/saves/:id', async (req, res) => {
    const raw = await loadGameSlot(req.params.id);
    if (!raw) {
      res.status(404).json({ ok: false, error: 'Save slot not found.' });
      return;
    }
    res.json({ ok: true, state: JSON.parse(raw) });
  });

  app.delete('/api/saves/:id', async (req, res) => {
    await deleteGameSlot(req.params.id);
    res.json({ ok: true });
  });

  app.get('/api/lobbies', (_req, res) => {
    res.json({ lobbies: mpServer.getPublicLobbies() });
  });

  const server = http.createServer(app);

  if (IS_PROD) {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: { server, path: '/__vite_hmr' },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const pathname = request.url?.split('?')[0] ?? '';
    if (pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else if (pathname !== '/__vite_hmr') {
      socket.destroy();
    }
  });

  wss.on('connection', (ws) => {
    mpServer.handleConnection(ws);
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`DOMINION Server listening on http://0.0.0.0:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error('Failed to start DOMINION server:', err);
  process.exit(1);
});
