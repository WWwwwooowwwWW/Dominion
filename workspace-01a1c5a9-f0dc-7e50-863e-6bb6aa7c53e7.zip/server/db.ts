import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { Database } from 'sql.js';
import { PlayerAccount, SaveSlotSummary } from '../src/types/game';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'dominion.sqlite');

let dbInstance: Database | null = null;

function persistDb(): void {
  if (!dbInstance) return;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const data = dbInstance.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;
  const SQL = await initSqlJs();
  fs.mkdirSync(DATA_DIR, { recursive: true });

  if (fs.existsSync(DB_PATH)) {
    const fileBuf = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(fileBuf);
  } else {
    dbInstance = new SQL.Database();
  }

  dbInstance.run(`
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      elo INTEGER NOT NULL DEFAULT 1000,
      wins INTEGER NOT NULL DEFAULT 0,
      games_played INTEGER NOT NULL DEFAULT 0,
      preferred_color TEXT NOT NULL DEFAULT '#2dd4bf',
      preferred_emblem TEXT NOT NULL DEFAULT 'eagle',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS saves (
      id TEXT PRIMARY KEY,
      slot_name TEXT NOT NULL,
      nation_name TEXT NOT NULL,
      era TEXT NOT NULL,
      year REAL NOT NULL,
      territories_owned INTEGER NOT NULL,
      total_land INTEGER NOT NULL,
      difficulty TEXT NOT NULL,
      is_autosave INTEGER NOT NULL DEFAULT 0,
      state_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS match_history (
      id TEXT PRIMARY KEY,
      winner_name TEXT NOT NULL,
      victory_type TEXT NOT NULL,
      era TEXT NOT NULL,
      year REAL NOT NULL,
      mode TEXT NOT NULL,
      map_size TEXT NOT NULL,
      duration_ticks INTEGER NOT NULL,
      finished_at TEXT NOT NULL
    );
  `);

  // Seed initial Hall of Fame accounts if empty so rankings table isn't blank
  const countRes = dbInstance.exec('SELECT COUNT(*) FROM accounts');
  const count = Number(countRes[0]?.values[0]?.[0] ?? 0);
  if (count === 0) {
    const seedAccs = [
      ['acc_seed_1', 'Aurelius_Rex', 1280, 14, 21, '#d4a84f', 'eagle'],
      ['acc_seed_2', 'Admiral_Thalassa', 1195, 9, 16, '#38bdf8', 'anchor'],
      ['acc_seed_3', 'Imperator_Vael', 1120, 6, 14, '#c94c4c', 'crown'],
    ] as const;
    for (const [id, uname, elo, wins, gp, color, emblem] of seedAccs) {
      const salt = crypto.randomBytes(8).toString('hex');
      const hash = crypto.scryptSync('dominion-demo', salt, 32).toString('hex');
      dbInstance.run(
        `INSERT INTO accounts (id, username, password_hash, salt, elo, wins, games_played, preferred_color, preferred_emblem, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, uname, hash, salt, elo, wins, gp, color, emblem, new Date().toISOString()]
      );
    }
    persistDb();
  }

  return dbInstance;
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 32).toString('hex');
}

export async function registerOrLoginAccount(
  username: string,
  password: string,
  preferredColor = '#2dd4bf',
  preferredEmblem = 'eagle'
): Promise<{ ok: boolean; account?: PlayerAccount; error?: string }> {
  const cleanName = username.trim().slice(0, 24);
  if (cleanName.length < 2) return { ok: false, error: 'Username must be at least 2 characters.' };
  if (password.length < 3) return { ok: false, error: 'Password must be at least 3 characters.' };

  const db = await getDb();
  const stmt = db.prepare('SELECT * FROM accounts WHERE LOWER(username) = LOWER(?)');
  stmt.bind([cleanName]);
  const exists = stmt.step();

  if (exists) {
    const row = stmt.getAsObject() as Record<string, unknown>;
    stmt.free();
    const checkHash = hashPassword(password, String(row.salt));
    if (checkHash !== String(row.password_hash)) {
      return { ok: false, error: 'Incorrect password for existing account.' };
    }
    return {
      ok: true,
      account: {
        id: String(row.id),
        username: String(row.username),
        elo: Number(row.elo),
        wins: Number(row.wins),
        gamesPlayed: Number(row.games_played),
        preferredColor: String(row.preferred_color) as PlayerAccount['preferredColor'],
        preferredEmblem: String(row.preferred_emblem) as PlayerAccount['preferredEmblem'],
      },
    };
  }
  stmt.free();

  const id = `acc_${crypto.randomUUID()}`;
  const salt = crypto.randomBytes(12).toString('hex');
  const hash = hashPassword(password, salt);
  db.run(
    `INSERT INTO accounts (id, username, password_hash, salt, elo, wins, games_played, preferred_color, preferred_emblem, created_at)
     VALUES (?, ?, ?, ?, 1000, 0, 0, ?, ?, ?)`,
    [id, cleanName, hash, salt, preferredColor, preferredEmblem, new Date().toISOString()]
  );
  persistDb();

  return {
    ok: true,
    account: {
      id,
      username: cleanName,
      elo: 1000,
      wins: 0,
      gamesPlayed: 0,
      preferredColor,
      preferredEmblem: preferredEmblem as PlayerAccount['preferredEmblem'],
    },
  };
}

export async function getLeaderboard(): Promise<PlayerAccount[]> {
  const db = await getDb();
  const res = db.exec(
    'SELECT id, username, elo, wins, games_played, preferred_color, preferred_emblem FROM accounts ORDER BY elo DESC, wins DESC LIMIT 25'
  );
  if (!res[0]) return [];
  return res[0].values.map((v) => ({
    id: String(v[0]),
    username: String(v[1]),
    elo: Number(v[2]),
    wins: Number(v[3]),
    gamesPlayed: Number(v[4]),
    preferredColor: String(v[5]),
    preferredEmblem: String(v[6]) as PlayerAccount['preferredEmblem'],
  }));
}

export async function recordAccountResult(username: string, won: boolean): Promise<void> {
  const db = await getDb();
  db.run(
    `UPDATE accounts SET games_played = games_played + 1, wins = wins + ?, elo = MAX(600, elo + ?) WHERE username = ?`,
    [won ? 1 : 0, won ? 28 : -10, username]
  );
  persistDb();
}

export async function listSaveSlots(): Promise<SaveSlotSummary[]> {
  const db = await getDb();
  const res = db.exec(
    'SELECT id, slot_name, nation_name, era, year, territories_owned, total_land, difficulty, is_autosave, updated_at FROM saves ORDER BY updated_at DESC'
  );
  if (!res[0]) return [];
  return res[0].values.map((v) => ({
    id: String(v[0]),
    name: String(v[1]),
    nationName: String(v[2]),
    era: String(v[3]) as SaveSlotSummary['era'],
    year: Number(v[4]),
    territoriesOwned: Number(v[5]),
    totalLandTerritories: Number(v[6]),
    difficulty: String(v[7]) as SaveSlotSummary['difficulty'],
    isAutosave: Number(v[8]) === 1,
    updatedAt: String(v[9]),
  }));
}

export async function saveGameSlot(payload: {
  id: string;
  name: string;
  nationName: string;
  era: string;
  year: number;
  territoriesOwned: number;
  totalLandTerritories: number;
  difficulty: string;
  isAutosave: boolean;
  stateJson: string;
}): Promise<SaveSlotSummary> {
  const db = await getDb();
  const now = new Date().toISOString();
  db.run(
    `INSERT OR REPLACE INTO saves (id, slot_name, nation_name, era, year, territories_owned, total_land, difficulty, is_autosave, state_json, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      payload.id,
      payload.name,
      payload.nationName,
      payload.era,
      payload.year,
      payload.territoriesOwned,
      payload.totalLandTerritories,
      payload.difficulty,
      payload.isAutosave ? 1 : 0,
      payload.stateJson,
      now,
    ]
  );
  persistDb();
  return {
    id: payload.id,
    name: payload.name,
    nationName: payload.nationName,
    era: payload.era as SaveSlotSummary['era'],
    year: payload.year,
    territoriesOwned: payload.territoriesOwned,
    totalLandTerritories: payload.totalLandTerritories,
    difficulty: payload.difficulty as SaveSlotSummary['difficulty'],
    isAutosave: payload.isAutosave,
    updatedAt: now,
  };
}

export async function loadGameSlot(id: string): Promise<string | null> {
  const db = await getDb();
  const stmt = db.prepare('SELECT state_json FROM saves WHERE id = ?');
  stmt.bind([id]);
  if (!stmt.step()) {
    stmt.free();
    return null;
  }
  const row = stmt.getAsObject() as { state_json: string };
  stmt.free();
  return row.state_json;
}

export async function deleteGameSlot(id: string): Promise<void> {
  const db = await getDb();
  db.run('DELETE FROM saves WHERE id = ?', [id]);
  persistDb();
}

export async function recordMatchHistory(entry: {
  winnerName: string;
  victoryType: string;
  era: string;
  year: number;
  mode: string;
  mapSize: string;
  durationTicks: number;
}): Promise<void> {
  const db = await getDb();
  db.run(
    `INSERT INTO match_history (id, winner_name, victory_type, era, year, mode, map_size, duration_ticks, finished_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      `mh_${crypto.randomUUID()}`,
      entry.winnerName,
      entry.victoryType,
      entry.era,
      entry.year,
      entry.mode,
      entry.mapSize,
      entry.durationTicks,
      new Date().toISOString(),
    ]
  );
  persistDb();
}

export async function getMatchHistory(): Promise<Array<Record<string, unknown>>> {
  const db = await getDb();
  const res = db.exec(
    'SELECT id, winner_name, victory_type, era, year, mode, map_size, duration_ticks, finished_at FROM match_history ORDER BY finished_at DESC LIMIT 30'
  );
  if (!res[0]) return [];
  return res[0].values.map((v) => ({
    id: String(v[0]),
    winnerName: String(v[1]),
    victoryType: String(v[2]),
    era: String(v[3]),
    year: Number(v[4]),
    mode: String(v[5]),
    mapSize: String(v[6]),
    durationTicks: Number(v[7]),
    finishedAt: String(v[8]),
  }));
}
